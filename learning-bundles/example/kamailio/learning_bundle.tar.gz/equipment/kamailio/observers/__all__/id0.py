import hashlib
import re
from typing import Optional

def packet_observer(response: bytes) -> str:
    """
    Normalize a SIP response (bytes) for stable semantic hashing.
    Only dynamic, non-behavioral fields (e.g., tags, branch, call-id, cseq number,
    from/to tags, contact URIs, etc.) are replaced with field-specific markers.
    Status code, version, reason phrase, header names, body structure, etc. are preserved.
    """
    if not isinstance(response, bytes):
        return hashlib.sha256(b"").hexdigest()
    
    try:
        text = response.decode("utf-8", errors="replace")
    except Exception:
        return hashlib.sha256(response).hexdigest()
    
    # Split into start-line, headers, body
    # Find the blank line separating headers from body
    header_end = text.find("\r\n\r\n")
    if header_end == -1:
        # No header/body separation, try just \n\n
        header_end = text.find("\n\n")
        if header_end == -1:
            # No separation: treat entire message as flat, but still try to parse start-line
            start_line_end = text.find("\r\n")
            if start_line_end == -1:
                start_line_end = text.find("\n")
            if start_line_end == -1:
                # Single line? unlikely, but hash original
                return hashlib.sha256(response).hexdigest()
            start_line = text[:start_line_end]
            rest = text[start_line_end:]
        else:
            start_line_end = text.find("\n")
            if start_line_end == -1:
                return hashlib.sha256(response).hexdigest()
            start_line = text[:start_line_end]
            rest = text[start_line_end:]
            header_end = start_line_end + 2  # approximate
    else:
        start_line_end = text.find("\r\n")
        if start_line_end == -1:
            start_line_end = text.find("\n")
            if start_line_end == -1:
                return hashlib.sha256(response).hexdigest()
        start_line = text[:start_line_end]
        rest = text[start_line_end:]
    
    # Normalize start-line: SIP/2.0 SP Status-Code SP Reason-Phrase CRLF
    # Keep status code, normalize reason phrase (but keep it)
    # We'll keep reason phrase as is, but it's human-readable, not behavioral.
    # Replace version if needed (should be SIP/2.0)
    # Actually, we keep everything in start-line except maybe dynamic parts? None.
    # Status code is critical, keep it.
    # So start-line remains unchanged.
    
    # Now normalize headers
    # We'll split headers lines
    # Find the body after headers
    body_start = header_end + 2  # for \r\n\r\n, but we already have the index
    
    # Actually we need to handle both \r\n and \n line endings
    # Let's work with lines
    if "\r\n" in text:
        lines = text.split("\r\n")
        line_ending = "\r\n"
    else:
        lines = text.split("\n")
        line_ending = "\n"
    
    # Separate start line, headers, body
    if len(lines) < 2:
        return hashlib.sha256(response).hexdigest()
    
    start_line = lines[0]
    # Find blank line index
    blank_idx = None
    for i in range(1, len(lines)):
        if lines[i] == "":
            blank_idx = i
            break
    if blank_idx is None:
        # No body, headers go to end
        header_lines = lines[1:]
        body_lines = []
    else:
        header_lines = lines[1:blank_idx]
        body_lines = lines[blank_idx+1:]
    
    # Process header lines
    normalized_headers = []
    # Known dynamic headers and their normalization patterns
    # We'll replace specific values with markers
    for hdr in header_lines:
        if ":" not in hdr:
            # Continuation line? Not typical in SIP, but preserve
            normalized_headers.append(hdr)
            continue
        hdr_name, hdr_val = hdr.split(":", 1)
        hdr_name_lower = hdr_name.strip().lower()
        val = hdr_val.strip()
        
        if hdr_name_lower == "via":
            # Normalize branch and sent-by (host:port) but keep transport and protocol
            # Replace branch parameter value with marker
            # Also replace sent-by if it's a generic host:port? Better to keep structure.
            # We'll replace branch=... with branch=<BRANCH_MARKER>
            val = re.sub(r'([;\s]branch=)[^\s;]+', r'\1<BRANCH>', val, flags=re.IGNORECASE)
            # Also replace received parameter if present
            val = re.sub(r'([;\s]received=)[^\s;]+', r'\1<RECEIVED>', val, flags=re.IGNORECASE)
            # Replace rport value
            val = re.sub(r'([;\s]rport=)[^\s;]+', r'\1<RPORT>', val, flags=re.IGNORECASE)
            # Keep the rest (host, port, etc.) but we might want to normalize the sent-by host?
            # For stability, we leave host:port as is if it's a specific IP? But IPs can be dynamic.
            # Better to replace sent-by host:port with a marker? But that loses structure.
            # We'll replace the first occurrence of an IP address or hostname after the transport
            # Actually, Via: SIP/2.0/UDP 192.168.1.1:5060;branch=z9hG4bK...
            # We'll keep the transport part, replace the addr:port
            # But careful: the addr:port could be part of the sent-by field.
            # Pattern: after protocol, space, then sent-by (host:port) then optional params
            # Replace the sent-by host:port with a placeholder, but keep the port if present
            # We'll replace the first token after the protocol that looks like an address
            # Actually easier: replace the entire sent-by field with a placeholder
            # But we need to preserve the port number? Not necessary.
            # Let's replace the sent-by with <SENTBY>
            val = re.sub(r'(SIP/2\.0/(?:UDP|TCP|TLS|SCTP|WS|WSS)\s+)[^\s;]+', r'\1<SENTBY>', val, flags=re.IGNORECASE)
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower in ("from", "to"):
            # Replace tag parameter value
            val = re.sub(r'(;\s*tag=)[^\s;]+', r'\1<TAG>', val, flags=re.IGNORECASE)
            # Also replace the URI host:port? No, keep the URI structure.
            # But we might want to replace the specific user/host part? 
            # For SIP URIs, user and host can be dynamic. We'll replace the userinfo and hostport
            # with markers, but preserve the URI scheme and parameters.
            # However, we need to keep the structure for dialog matching.
            # Actually, from/to contain the URI of the originator/recipient.
            # These are often dynamic (IP addresses, usernames). But they are also key for routing.
            # The task says preserve status/type, framing, lengths, flags, capabilities, ordering,
            # required headers, etc. So we should not normalize the entire URI away.
            # Only normalize truly dynamic non-behavioral parts like tags.
            # So we'll only replace the tag.
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "call-id":
            # Replace entire call-id value with marker, but preserve length? 
            # Call-ID is globally unique, so replace it.
            # Keep the structure but replace the value.
            # To preserve length, we could use a fixed-length marker? But length is not critical.
            # We'll replace the entire value with "<CALLID>"
            # But we need to preserve the presence and general structure.
            # We'll replace the value with a placeholder of similar length? Not needed.
            val = "<CALLID>"
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "cseq":
            # CSeq: number method
            # Replace the number part with a marker, keep method
            parts = val.split(" ", 1)
            if len(parts) == 2:
                # Replace number with <CSEQNUM>
                val = f"<CSEQNUM> {parts[1]}"
            else:
                val = "<CSEQNUM>"
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "contact":
            # Contact URIs can contain user, host, port, parameters.
            # Replace with a generic marker but keep the structure (multiple contacts)
            # We'll replace each URI with <CONTACT_URI>
            # But preserve the number of contacts and any parameters that are not dynamic?
            # Actually, contact URIs are dynamic (IP addresses, usernames).
            # We'll replace the entire value with a single marker, but if there are multiple
            # we'll keep the comma separation.
            contacts = [c.strip() for c in val.split(",")]
            # Replace each contact with a marker
            # But we need to preserve the presence of angle brackets, etc.
            # Simpler: replace the entire value with <CONTACT> (or multiple)
            # But we want to preserve the count of contacts.
            # We'll replace each contact URI with <CONTACT_URI>
            new_contacts = []
            for c in contacts:
                # Replace the entire URI (including parameters) with <CONTACT_URI>
                # But we need to keep the <> if present? Actually, contact can be in <> or not.
                # We'll just replace the whole thing.
                new_contacts.append("<CONTACT_URI>")
            val = ", ".join(new_contacts)
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "allow":
            # Keep as is, it's capability
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "supported":
            # Keep as is
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "event":
            # Keep event package name, it's behavioral
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "subscription-state":
            # Keep state and parameters (expires, etc.) but normalize expires value?
            # Expires is a retry value, keep it. But it's dynamic? Actually, it's a timeout.
            # The task says preserve retry values. So keep expires.
            # But we might normalize the state? It's behavioral.
            # Keep as is.
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "sip-etag":
            # Replace with marker
            val = "<ETAG>"
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "rseq":
            # Replace sequence number with marker
            val = "<RSEQ>"
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "content-type":
            # Keep as is
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        elif hdr_name_lower == "content-length":
            # Keep the length value, but it might change if we modify body? 
            # We are not modifying body, so keep as is. But if we normalize body, we need to adjust.
            # We are not normalizing body content, so keep.
            normalized_headers.append(f"{hdr_name.strip()}: {val}")
            continue
            
        else:
            # Extension headers: keep as is, but we might want to normalize some?
            # For example, WWW-Authenticate: contains nonce (dynamic)
            # We'll handle a few common ones.
            if hdr_name_lower == "www-authenticate":
                # Replace nonce, opaque, etc.
                val = re.sub(r'(nonce=")[^"]*(")', r'\1<NONCE>\2', val, flags=re.IGNORECASE)
                val = re.sub(r'(opaque=")[^"]*(")', r'\1<OPAQUE>\2', val, flags=re.IGNORECASE)
                val = re.sub(r'(realm=")[^"]*(")', r'\1<REALM>\2', val, flags=re.IGNORECASE)
                # Also algorithm, qop, etc. are capabilities, keep them.
                normalized_headers.append(f"{hdr_name.strip()}: {val}")
                continue
            elif hdr_name_lower == "authorization":
                # Replace credentials
                val = re.sub(r'(response=")[^"]*(")', r'\1<AUTHRESP>\2', val, flags=re.IGNORECASE)
                val = re.sub(r'(cnonce=")[^"]*(")', r'\1<CNONCE>\2', val, flags=re.IGNORECASE)
                val = re.sub(r'(nonce=")[^"]*(")', r'\1<NONCE>\2', val, flags=re.IGNORECASE)
                normalized_headers.append(f"{hdr_name.strip()}: {val}")
                continue
            elif hdr_name_lower == "proxy-authenticate":
                val = re.sub(r'(nonce=")[^"]*(")', r'\1<NONCE>\2', val, flags=re.IGNORECASE)
                val = re.sub(r'(opaque=")[^"]*(")', r'\1<OPAQUE>\2', val, flags=re.IGNORECASE)
                normalized_headers.append(f"{hdr_name.strip()}: {val}")
                continue
            elif hdr_name_lower == "proxy-authorization":
                val = re.sub(r'(response=")[^"]*(")', r'\1<AUTHRESP>\2', val, flags=re.IGNORECASE)
                val = re.sub(r'(cnonce=")[^"]*(")', r'\1<CNONCE>\2', val, flags=re.IGNORECASE)
                normalized_headers.append(f"{hdr_name.strip()}: {val}")
                continue
            elif hdr_name_lower == "retry-after":
                # Keep the value, it's a retry value
                normalized_headers.append(f"{hdr_name.strip()}: {val}")
                continue
            else:
                # For any other header, keep as is
                normalized_headers.append(f"{hdr_name.strip()}: {val}")
                continue
    
    # Reconstruct headers
    headers_str = line_ending.join(normalized_headers)
    
    # Body: we keep as is (no normalization of payload)
    body_str = line_ending.join(body_lines)
    
    # Reconstruct the full message with start line, headers, blank line, body
    # Ensure blank line is present
    if blank_idx is not None:
        # If there was a blank line, we add it
        normalized_msg = start_line + line_ending + headers_str + line_ending + line_ending + body_str
    else:
        # No blank line, no body
        normalized_msg = start_line + line_ending + headers_str
    
    # Encode back to bytes (using original line ending)
    normalized_bytes = normalized_msg.encode("utf-8")
    
    return hashlib.sha256(normalized_bytes).hexdigest()