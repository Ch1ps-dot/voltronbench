def generate() -> bytes:
    # Build an INFO request inside an existing dialog (using the dialog from the captured BYE as base)
    # We reuse Call-ID, From tag, To tag from the BYE dialog, increment CSeq to 5 (next after 4, but we have 3 BYE, so 4 INFO)
    # Actually the previous messages: REGISTER CSeq=1, INVITE CSeq=2, ACK CSeq=2, BYE CSeq=3. Next for INFO: CSeq=4.
    # Request-Line: INFO sip:33@127.0.0.1:5068;ob SIP/2.0
    method = b"INFO"
    sp = b" "
    request_uri = b"sip:33@127.0.0.1:5068;ob"
    sip_version = b"SIP/2.0"
    crlf = b"\r\n"
    start_line = method + sp + request_uri + sp + sip_version + crlf

    # Via: topmost Via matching the UA; branch with magic cookie, unique for this transaction
    via = b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-10\r\n"
    # Max-Forwards: 70 (recommended default)
    max_forwards = b"Max-Forwards: 70\r\n"
    # From: using dialog originator (30) with tag=1
    from_hdr = b"From: <sip:30@127.0.0.1>;tag=1\r\n"
    # To: target (33) with remote tag from BYE response
    to_hdr = b"To: <sip:33@127.0.0.1>;tag=02cV-oIOVhYnZS3wEzeDPLO.u9i61mwV\r\n"
    # Call-ID: same as dialog
    call_id = b"Call-ID: 1-670@127.0.0.1\r\n"
    # CSeq: 4 INFO
    cseq = b"CSeq: 4 INFO\r\n"
    # Info-Package: optional but we include a valid Info-Package (e.g., "application/vnd.example") to test Info-Package mode
    info_package = b"Info-Package: example-package\r\n"
    # Content-Disposition: If Info-Package is present and body is associated, set to "Info-Package"
    content_disposition = b"Content-Disposition: Info-Package\r\n"
    # Content-Type: e.g., text/plain (simple MIME type)
    content_type = b"Content-Type: text/plain\r\n"
    # Content-Length: for a small body (e.g., "hello")
    body = b"hello"
    content_length = b"Content-Length: " + str(len(body)).encode() + b"\r\n"
    # Other-Headers: optional, we skip for simplicity
    # End of headers CRLF
    end_headers = b"\r\n"
    # Message-Body as above
    # EndOfMessage is implicit

    # Assemble all headers (order is not strictly mandated beyond start line, but we follow common order)
    headers = via + max_forwards + from_hdr + to_hdr + call_id + cseq + info_package + content_disposition + content_type + content_length + end_headers
    message = start_line + headers + body

    return message