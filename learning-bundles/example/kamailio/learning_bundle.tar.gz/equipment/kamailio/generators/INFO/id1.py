def generate() -> bytes:
    # Build an INFO request inside an existing dialog, reusing the dialog identifiers from the captured BYE.
    # This INFO request is sent within the established dialog (Call-ID: 1-670@127.0.0.1, From tag=1, To tag from remote).
    # The CSeq is incremented from the BYE (CSeq=3) to 4 for INFO.
    # To reach a new legal state (e.g., 200 OK), we ensure the request is well-formed and includes mandatory headers.
    # Additionally, we include a Route header as present in the ACK and BYE messages to ensure proper routing via the server.
    method = b"INFO"
    sp = b" "
    request_uri = b"sip:33@127.0.0.1:5068;ob"
    sip_version = b"SIP/2.0"
    crlf = b"\r\n"
    start_line = method + sp + request_uri + sp + sip_version + crlf

    # Via: topmost Via matching the UA; branch with magic cookie, unique for this transaction (new branch)
    via = b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-10\r\n"
    # Max-Forwards: 70 (recommended default)
    max_forwards = b"Max-Forwards: 70\r\n"
    # From: using dialog originator (30) with tag=1
    from_hdr = b"From: <sip:30@127.0.0.1>;tag=1\r\n"
    # To: target (33) with remote tag from BYE response
    to_hdr = b"To: <sip:33@127.0.0.1>;tag=02cV-oIOVhYnZS3wEzeDPLO.u9i61mwV\r\n"
    # Route: added to ensure request is routed through the proxy (as in ACK and BYE messages)
    route = b"Route: <sip:127.0.0.1;lr>\r\n"
    # Call-ID: same as dialog
    call_id = b"Call-ID: 1-670@127.0.0.1\r\n"
    # CSeq: 4 INFO (next after BYE CSeq=3)
    cseq = b"CSeq: 4 INFO\r\n"
    # Contact: header required for dialog requests (as in ACK and BYE)
    contact = b"Contact: sip:30@127.0.0.1:5061\r\n"
    # Info-Package: optional, but we include a valid Info-Package to exercise Info-Package usage
    info_package = b"Info-Package: example-package\r\n"
    # Content-Disposition: set to Info-Package if body is associated with the Info-Package
    content_disposition = b"Content-Disposition: Info-Package\r\n"
    # Content-Type: simple MIME type
    content_type = b"Content-Type: text/plain\r\n"
    # Message-Body
    body = b"hello"
    # Content-Length: must be present and accurate
    content_length = b"Content-Length: " + str(len(body)).encode() + b"\r\n"
    # End of headers CRLF
    end_headers = b"\r\n"

    # Assemble all headers (order not strictly mandated, but following common pattern)
    headers = via + max_forwards + from_hdr + to_hdr + route + call_id + cseq + contact + info_package + content_disposition + content_type + content_length + end_headers
    message = start_line + headers + body

    return message