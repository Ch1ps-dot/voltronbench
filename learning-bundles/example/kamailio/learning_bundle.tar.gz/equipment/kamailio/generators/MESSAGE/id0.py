def generate() -> bytes:
    body = b"Hello, 33!"
    headers = (
        "MESSAGE sip:33@127.0.0.1:5060 SIP/2.0\r\n"
        "Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-4\r\n"
        "Max-Forwards: 70\r\n"
        "From: sipp <sip:30@127.0.0.1>;tag=1-671\r\n"
        "To: <sip:33@127.0.0.1:5060>\r\n"
        "Call-ID: 1-671@127.0.0.1\r\n"
        "CSeq: 1 MESSAGE\r\n"
        "User-Agent: SIPp/Win32\r\n"
        "Content-Type: text/plain; charset=UTF-8\r\n"
        "Content-Length: {}\r\n"
        "\r\n"
    ).format(len(body))
    return headers.encode("ascii") + body