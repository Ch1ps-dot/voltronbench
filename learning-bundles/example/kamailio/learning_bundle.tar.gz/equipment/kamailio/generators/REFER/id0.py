import struct

def generate() -> bytes:
    # Build a valid SIP REFER request for user 30 to user 33 via Kamailio proxy
    method = b"REFER"
    sp1 = b" "
    request_uri = b"sip:33@127.0.0.1:5068"
    sp2 = b" "
    sip_version = b"SIP/2.0"
    crlf_start = b"\r\n"
    
    # Via header - using UDP transport, branch with required magic cookie
    via = b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-10\r\n"
    
    # Max-Forwards - typical default 70
    max_forwards = b"Max-Forwards: 70\r\n"
    
    # To - user 33, without tag as it's a new request (outside dialog)
    to = b"To: <sip:33@127.0.0.1:5068>\r\n"
    
    # From - user 30 with tag
    from_hdr = b"From: <sip:30@127.0.0.1>;tag=1\r\n"
    
    # Call-ID - unique identifier
    call_id = b"Call-ID: 1-670-REFER-10@127.0.0.1\r\n"
    
    # CSeq - number and method must match REFER
    cseq = b"CSeq: 10 REFER\r\n"
    
    # Contact - must be SIP URI for dialog-establishing REFER
    contact = b"Contact: <sip:30@127.0.0.1:5061>\r\n"
    
    # Refer-To - target URI for the referral
    refer_to = b"Refer-To: <sip:33@127.0.0.1:5068>\r\n"
    
    # Event header required for implicit subscription (refer event)
    event = b"Event: refer\r\n"
    
    # Require - optional, but may include event for reliability
    require = b"Require: event\r\n"
    
    # Supported - optional
    supported = b"Supported: event\r\n"
    
    # Content-Length zero (no body)
    content_length = b"Content-Length: 0\r\n"
    
    # Header terminator (empty line)
    crlf_terminator = b"\r\n"
    
    # Assemble the request in IR order as per field table
    request = (
        method +
        sp1 +
        request_uri +
        sp2 +
        sip_version +
        crlf_start +
        via +
        max_forwards +
        to +
        from_hdr +
        call_id +
        cseq +
        contact +
        refer_to +
        event +
        require +
        supported +
        content_length +
        crlf_terminator
    )
    
    return request