import random

def generate() -> bytes:
    # Generate a fresh Call-ID and CSeq sequence number
    call_id = f"{random.randint(1, 999999)}-{random.randint(100, 999)}@127.0.0.1"
    cseq_num = random.randint(1, 1000)
    
    # Build the request line
    method = b"UPDATE"
    sp1 = b" "
    request_uri = b"sip:33@127.0.0.1:5060"
    sp2 = b" "
    sip_version = b"SIP/2.0"
    start_line_crlf = b"\r\n"
    
    # Headers
    via = f"SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-{random.randint(1000, 9999)}-{random.randint(1, 10)}".encode()
    max_forwards = b"Max-Forwards: 70\r\n"
    from_header = b'From: <sip:30@127.0.0.1>;tag=1\r\n'
    to_header = b'To: <sip:33@127.0.0.1:5060>\r\n'
    call_id_header = f"Call-ID: {call_id}\r\n".encode()
    cseq_header = f"CSeq: {cseq_num} UPDATE\r\n".encode()
    contact = b"Contact: <sip:30@127.0.0.1:5061>\r\n"
    allow = b"Allow: INVITE, ACK, BYE, CANCEL, UPDATE, PRACK, INFO\r\n"
    supported = b"Supported: 100rel\r\n"
    require = b"Require: 100rel\r\n"  # optional, but valid for UPDATE
    content_type = b"Content-Type: application/sdp\r\n"
    sdp_body = (
        b"v=0\r\n"
        b"o=user30 53655765 2353687637 IN IP4 127.0.0.1\r\n"
        b"s=-\r\n"
        b"c=IN IP4 127.0.0.1\r\n"
        b"t=0 0\r\n"
        b"m=audio 6002 RTP/AVP 8 0\r\n"
        b"a=rtpmap:8 PCMA/8000\r\n"
        b"a=rtpmap:0 PCMU/8000\r\n"
    )
    content_length = len(sdp_body)
    content_length_header = f"Content-Length: {content_length}\r\n".encode()
    
    # Additional headers (optional)
    other_headers = b"User-Agent: SIPp/Win32\r\n"
    
    # Header terminator (empty line)
    header_terminator = b"\r\n"
    
    # Assemble the message
    message = (
        method + sp1 + request_uri + sp2 + sip_version + start_line_crlf +
        b"Via: " + via + b"\r\n" +
        max_forwards +
        from_header +
        to_header +
        call_id_header +
        cseq_header +
        contact +
        allow +
        supported +
        require +
        content_type +
        content_length_header +
        other_headers +
        header_terminator +
        sdp_body
    )
    
    return message