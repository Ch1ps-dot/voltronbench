def generate() -> bytes:
    return (
        b"OPTIONS sip:33@127.0.0.1:5068 SIP/2.0\r\n"
        b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-opt-1\r\n"
        b"Max-Forwards: 70\r\n"
        b"To: <sip:33@127.0.0.1:5068>\r\n"
        b"From: <sip:30@127.0.0.1>;tag=9a8b7c6d5e4f\r\n"
        b"Call-ID: opt-1-670@127.0.0.1\r\n"
        b"CSeq: 1 OPTIONS\r\n"
        b"Contact: <sip:30@127.0.0.1:5061>\r\n"
        b"Accept: application/sdp\r\n"
        b"Content-Length: 0\r\n"
        b"\r\n"
    )