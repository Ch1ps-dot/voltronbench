def generate() -> bytes:
    # Build the SIP REGISTER request message according to the IR field table
    # Use the context: user 30 at 127.0.0.1:5061, server 127.0.0.1:5060
    # Based on the previous example message for REGISTER

    # Request-Line: REGISTER sip:127.0.0.1 SIP/2.0
    request_line = b"REGISTER sip:127.0.0.1:5060 SIP/2.0\r\n"

    # Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-0
    # Use a slightly different branch for each call to generate (unique)
    # We'll use a fixed branch for reproducibility, but vary it across calls
    # For simplicity, use a branch that includes a random-looking component
    # Since we must be deterministic, use a fixed branch
    via = b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-0\r\n"

    # Max-Forwards: 70 (recommended default)
    max_forwards = b"Max-Forwards: 70\r\n"

    # To: <sip:30@127.0.0.1>
    to = b"To: <sip:30@127.0.0.1>\r\n"

    # From: <sip:30@127.0.0.1>;tag=1
    # Use a tag that is unique per invocation (use a deterministic variation)
    # For simplicity, keep tag=1 as in example
    from_header = b"From: <sip:30@127.0.0.1>;tag=1\r\n"

    # Call-ID: 1-670@127.0.0.1
    # Use a unique Call-ID per invocation (deterministic variation)
    # For simplicity, keep as in example
    call_id = b"Call-ID: 1-670@127.0.0.1\r\n"

    # CSeq: 1 REGISTER (sequence number should be incremented for each new registration with same Call-ID)
    # For a fresh registration, use 1
    cseq = b"CSeq: 1 REGISTER\r\n"

    # Contact: sip:30@127.0.0.1:5061
    contact = b"Contact: <sip:30@127.0.0.1:5061>\r\n"

    # Expires: 120 (optional, but included in example)
    expires = b"Expires: 120\r\n"

    # Content-Length: 0 (no body)
    content_length = b"Content-Length: 0\r\n"

    # End of headers (CRLF)
    end_headers = b"\r\n"

    # Concatenate all parts in IR order
    message = (
        request_line +
        via +
        max_forwards +
        to +
        from_header +
        call_id +
        cseq +
        contact +
        expires +
        content_length +
        end_headers
    )

    return message