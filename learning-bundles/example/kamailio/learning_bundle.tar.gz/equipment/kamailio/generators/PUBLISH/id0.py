def generate():
    body = (
        b'<?xml version="1.0" encoding="UTF-8"?>\r\n'
        b'<presence xmlns="urn:ietf:params:xml:ns:pidf" entity="sip:30@127.0.0.1">\r\n'
        b'  <tuple id="t1">\r\n'
        b'    <status>\r\n'
        b'      <basic>open</basic>\r\n'
        b'    </status>\r\n'
        b'    <contact>sip:30@127.0.0.1:5061</contact>\r\n'
        b'  </tuple>\r\n'
        b'</presence>\r\n'
    )
    content_length = str(len(body)).encode("ascii")
    headers = (
        b"PUBLISH sip:30@127.0.0.1 SIP/2.0\r\n"
        b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-20\r\n"
        b"From: <sip:30@127.0.0.1>;tag=1\r\n"
        b"To: <sip:30@127.0.0.1>\r\n"
        b"Call-ID: 1-671@127.0.0.1\r\n"
        b"CSeq: 1 PUBLISH\r\n"
        b"Max-Forwards: 100\r\n"
        b"Event: presence\r\n"
        b"Expires: 120\r\n"
        b"Content-Type: application/pidf+xml\r\n"
    )
    return headers + b"Content-Length: " + content_length + b"\r\n\r\n" + body