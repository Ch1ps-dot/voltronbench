def generate():
    # Build a PUBLISH request for event state removal (Expires: 0) with no body
    # This exercises the Remove protocol state transition (SIP-If-Match present, no body)
    headers = (
        b"PUBLISH sip:30@127.0.0.1 SIP/2.0\r\n"
        b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-20\r\n"
        b"From: <sip:30@127.0.0.1>;tag=1\r\n"
        b"To: <sip:30@127.0.0.1>\r\n"
        b"Call-ID: 1-671@127.0.0.1\r\n"
        b"CSeq: 1 PUBLISH\r\n"
        b"Max-Forwards: 70\r\n"
        b"Event: presence\r\n"
        b"SIP-If-Match: tag12345\r\n"
        b"Expires: 0\r\n"
        b"Content-Length: 0\r\n"
        b"\r\n"
    )
    return headers