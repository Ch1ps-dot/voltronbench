def generate() -> bytes:
    return (
        "SUBSCRIBE sip:33@127.0.0.1:5060 SIP/2.0\r\n"
        "Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-1\r\n"
        "Max-Forwards: 100\r\n"
        "From: <sip:30@127.0.0.1>;tag=1\r\n"
        "To: <sip:33@127.0.0.1:5060>\r\n"
        "Call-ID: 1-671@127.0.0.1\r\n"
        "CSeq: 1 SUBSCRIBE\r\n"
        "Contact: sip:30@127.0.0.1:5061\r\n"
        "Event: presence\r\n"
        "Expires: 600\r\n"
        "Accept: application/pidf+xml\r\n"
        "Content-Length: 0\r\n"
        "\r\n"
    ).encode("ascii")