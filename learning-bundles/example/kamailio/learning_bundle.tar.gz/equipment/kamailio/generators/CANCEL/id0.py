def generate() -> bytes:
    return (
        b"CANCEL sip:33@127.0.0.1:5060 SIP/2.0\r\n"
        b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-2\r\n"
        b"Max-Forwards: 70\r\n"
        b"To: <sip:33@127.0.0.1:5060>\r\n"
        b"From: sipp <sip:30@127.0.0.1>;tag=1\r\n"
        b"Call-ID: 1-670@127.0.0.1\r\n"
        b"CSeq: 2 CANCEL\r\n"
        b"Contact: sip:30@127.0.0.1:5061\r\n"
        b"Content-Length: 0\r\n"
        b"\r\n"
    )