def generate() -> bytes:
    cseq = getattr(generate, '_cseq', 3) + 1
    generate._cseq = cseq
    branch = getattr(generate, '_branch', 9) + 1
    generate._branch = branch
    return (
        b"BYE sip:33@127.0.0.1:5068;ob SIP/2.0\r\n"
        b'Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-' + str(branch).encode() + b'\r\n'
        b"Max-Forwards: 70\r\n"
        b"From: <sip:30@127.0.0.1>;tag=1\r\n"
        b"To: <sip:33@127.0.0.1>;tag=02cV-oIOVhYnZS3wEzeDPLO.u9i61mwV\r\n"
        b'Route: <sip:127.0.0.1;lr>\r\n'
        b'Call-ID: 1-670@127.0.0.1\r\n'
        b'CSeq: ' + str(cseq).encode() + b' BYE\r\n'
        b"Content-Length: 0\r\n"
        b"\r\n"
    )