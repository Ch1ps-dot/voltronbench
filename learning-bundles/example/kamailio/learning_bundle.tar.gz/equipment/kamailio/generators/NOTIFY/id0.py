def generate() -> bytes:
    body = b"SIP/2.0 100 Trying\r\n"
    content_length_header = b"Content-Length: " + str(len(body)).encode("ascii") + b"\r\n"

    start_line = b"NOTIFY sip:33@127.0.0.1:5068;ob SIP/2.0\r\n"
    headers = [
        b"Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-30-33-notify-1\r\n",
        b"To: <sip:33@127.0.0.1>;tag=33sub1\r\n",
        b"From: <sip:30@127.0.0.1>;tag=30notify1\r\n",
        b"Call-ID: notify-30-33-1@127.0.0.1\r\n",
        b"CSeq: 1 NOTIFY\r\n",
        b"Max-Forwards: 70\r\n",
        b"Event: refer\r\n",
        b"Subscription-State: active;expires=3600\r\n",
        b"Contact: <sip:30@127.0.0.1:5061>\r\n",
        b"Content-Type: message/sipfrag;version=2.0\r\n",
        content_length_header,
        b"Route: <sip:127.0.0.1;lr>\r\n",
        b"User-Agent: SIPp/Win32\r\n",
    ]

    return start_line + b"".join(headers) + b"\r\n" + body