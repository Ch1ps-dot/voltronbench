def generate() -> bytes:
    body = (
        "v=0\r\n"
        "o=user1 53655765 2353687637 IN IP4 127.0.0.1\r\n"
        "s=-\r\n"
        "c=IN IP4 127.0.0.1\r\n"
        "t=0 0\r\n"
        "m=audio 6000 RTP/AVP 8\r\n"
        "a=rtpmap:8 PCMA/8000\r\n"
    )
    content_length = str(len(body.encode("ascii")))

    msg = (
        "INVITE sip:33@127.0.0.1:5060 SIP/2.0\r\n"
        "Via: SIP/2.0/UDP 127.0.0.1:5061;branch=z9hG4bK-670-1-2\r\n"
        "Max-Forwards: 100\r\n"
        "To: <sip:33@127.0.0.1:5060>\r\n"
        "From: sipp <sip:30@127.0.0.1>;tag=a3f9c2e8b714d5017283c4d5e6f70819\r\n"
        "Call-ID: 1-670@127.0.0.1\r\n"
        "CSeq: 2 INVITE\r\n"
        "Contact: sip:30@127.0.0.1:5061\r\n"
        "Supported: 100rel\r\n"
        "Content-Type: application/sdp\r\n"
        "Content-Length: " + content_length + "\r\n\r\n" + body
    )

    return msg.encode("ascii")