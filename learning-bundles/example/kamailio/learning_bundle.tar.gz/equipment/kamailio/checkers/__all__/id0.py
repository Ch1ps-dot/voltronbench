import struct

def packet_checker(response: bytes) -> bool:
    # Reject non-bytes
    if not isinstance(response, bytes):
        return False

    # Must have at least minimal length for Status-Line (SIP/2.0 SP Status-Code SP Reason-Phrase CRLF)
    # Minimal: SIP/2.0(7) + SP(1) + 3 digits + SP(1) + empty Reason-Phrase(0) + CRLF(2) = 14 bytes
    if len(response) < 14:
        return False

    # Check Status-Line start: SIP/2.0
    if response[:7] != b'SIP/2.0':
        return False

    pos = 7

    # SP1
    if pos >= len(response) or response[pos] != 0x20:
        return False
    pos += 1

    # Status_Code: 3 bytes
    if pos + 3 > len(response):
        return False
    status_code = response[pos:pos+3].decode('ascii', errors='replace')
    if not status_code.isdigit():
        return False
    valid_codes = {
        "100","180","181","182","183","200","202","300","301","302","305","380",
        "400","401","402","403","404","405","406","407","408","410","412","413",
        "414","415","416","420","421","423","469","480","481","482","483","484",
        "485","486","487","488","489","491","493","500","501","502","503","504",
        "505","513","600","603","604","606"
    }
    if status_code not in valid_codes:
        return False
    pos += 3

    # SP2
    if pos >= len(response) or response[pos] != 0x20:
        return False
    pos += 1

    # Reason_Phrase: up to CRLF (0x0D 0x0A)
    crlf_pos = response.find(b'\r\n', pos)
    if crlf_pos == -1:
        return False
    reason_phrase = response[pos:crlf_pos]
    # Must not contain CR or LF inside
    if b'\r' in reason_phrase or b'\n' in reason_phrase:
        return False
    # UTF-8 text check: we accept any bytes that don't contain CR/LF, but conforming text is UTF-8
    # We'll enforce that it's valid UTF-8 (decodable)
    try:
        reason_phrase.decode('utf-8')
    except UnicodeDecodeError:
        return False
    pos = crlf_pos + 2  # skip CRLF

    # Now we need to parse headers until CRLF blank line (0x0D0A0D0A) or end of message
    # All fields are variable; we need to find the blank line separating headers from body.
    # We'll parse headers in order: Via, From, To, Call-ID, CSeq, Contact, Allow, Supported,
    # Event, Subscription-State, SIP-ETag, RSeq, Content-Type, Content-Length, then any extension headers.
    # Each header: name HCOLON (colon+space) value CRLF
    # References: RFC 3261 section 7.2

    # We'll parse by scanning for the double CRLF (blank line) that ends headers.
    headers_end = response.find(b'\r\n\r\n', pos)
    if headers_end == -1:
        # No blank line -> maybe no body? But headers section must end with CRLF blank line according to spec.
        # However, Content-Length could be 0. We'll accept if there is no CRLFCRLF and we are at end?
        # Actually, RFC 3261 section 7.2: "The header fields are followed by a CRLF." So a blank line is required.
        # But sometimes there is no body and Content-Length is absent or 0; still, the CRLF is required.
        # We'll check if remaining after pos is exactly "CRLF" (i.e., no headers) -> then blank line? No.
        # Actually if there are no headers, the Status-Line ends with CRLF, then immediately another CRLF (blank line).
        # We'll treat that as the blank line.
        # Let's see if we have at least 2 bytes left after pos? Actually, we already consumed Status-Line CRLF.
        # So now we should have headers. If no CRLFCRLF, we check if the rest is empty? But empty would mean no headers and no blank line -> invalid.
        # So we'll reject.
        return False
    # Check that headers part does not contain isolated CR or LF without CRLF.
    header_section = response[pos:headers_end]
    # Validate that header_section consists of lines separated by CRLF
    # and each line matches header syntax.
    if header_section == b'':
        # No headers, but we still need to check that the blank line is present? Actually header_section empty means pos == headers_end,
        # and then we have CRLF at headers_end? Actually headers_end is the position of first CRLF in the double CRLF.
        # So if header_section empty, the double CRLF starts at pos. That's valid.
        pass
    else:
        lines = header_section.split(b'\r\n')
        # Each line must be a header.
        for line in lines:
            if line == b'':
                # This would be the blank line before the double CRLF, but we split on CRLF, so empty line appears only if we have sequential CRLF.
                # However, we already excluded the final empty line because header_section ends before the first CRLF of the double CRLF.
                # So we shouldn't have empty lines here.
                return False
            # Check colon
            colon_pos = line.find(b':')
            if colon_pos == -1:
                return False
            header_name = line[:colon_pos]
            if not header_name:
                return False
            # Header name must be token (alphanumeric, hyphen, etc.) – we'll check it's printable ASCII and no spaces? Actually RFC allows some.
            # We'll just accept any non-empty printable ASCII.
            try:
                header_name_str = header_name.decode('ascii')
            except:
                return False
            # Check after colon: HCOLON is ":" OWS (space/tab). We'll allow optional space.
            rest = line[colon_pos+1:]
            # Must have at least one char? Actually value can be empty? Some headers allow empty (e.g., Allow with no methods).
            # We'll accept empty.
            # Check that the line does not contain CR or LF (already handled by split).
            # Additionally, check that header name is not excessively long? Not needed.
            # Also, for the specific headers, we might need to validate presence of mandatory ones.
            # According to IR table, mandatory headers: Via, From, To, Call-ID, CSeq.
            # Others optional. We'll check that these appear at least once.
            # We'll collect header names to check later.
            # We'll store in a list.
            pass

        # Now we need to ensure that the first header is Via? Actually order is not strictly enforced? The IR table lists them in order, but we can't enforce order completely because unknown ones can appear.
        # We'll check that the mandatory headers appear somewhere.
        # We'll extract all header names.
        # But we also need to check that headers are unique? Not required (except Via multiple).
        # We'll just check that the minimum set exists.
        # We'll do a second pass: parse headers into a list of (name, value).
        # But we already have lines. We'll extract names.
        # However, we also need to ensure that the header section ends exactly at the blank line, and no extra CRLF before? Already checked.
        # We'll check that the header_section fits exactly with no stray bytes.
        # We'll reconstruct header_section from lines and ensure it matches.
        # But we kept the original bytes. We'll just ensure that the header_section is valid and that the next two bytes are CRLF (the first of the double).
        # Actually we already have headers_end = position of first CRLF of the double.
        # So we need to check that response[headers_end:headers_end+2] == b'\r\n' and then again response[headers_end+2:headers_end+4] == b'\r\n' (if length allows).
        # But we found the double CRLF via find, so it's guaranteed.
        # We'll just ensure that the double CRLF exists.
        if headers_end + 4 > len(response):
            # Need at least 4 bytes for double CRLF? Actually we need at least 2 bytes for the first CRLF and then 2 more for the second.
            # But find found the first occurrence, so we need to check that there is a second CRLF immediately after.
            # Actually find returns the index of the first byte of the pattern. So if we found b'\r\n\r\n', then headers_end is the position of the first \r of that.
            # So we need response[headers_end:headers_end+4] == b'\r\n\r\n'.
            # But we already found it via find, so it's true.
            pass
        # Now move pos past the double CRLF.
        pos = headers_end + 4

    # Now we have header section parsed. We need to check Content-Length and body if present.
    # We'll extract headers from the header_section.
    # But we already have header_section bytes. We'll parse them again to extract Content-Length and other headers.
    # We'll create a dictionary for easy lookup.
    header_dict = {}
    if header_section != b'':
        lines = header_section.split(b'\r\n')
        for line in lines:
            if line == b'':
                continue
            colon_pos = line.find(b':')
            if colon_pos == -1:
                continue
            name = line[:colon_pos].decode('ascii', errors='replace').strip()
            # HCOLON: after colon optional whitespace
            value = line[colon_pos+1:].lstrip(b' \t').decode('utf-8', errors='replace')
            # Store multiple values as list for same header? We'll keep the first or last? For simplicity, we'll keep the last.
            # But Via can have multiple; we'll store as list for Via.
            # We'll handle specifically.
            if name in header_dict:
                if isinstance(header_dict[name], list):
                    header_dict[name].append(value)
                else:
                    header_dict[name] = [header_dict[name], value]
            else:
                header_dict[name] = value

    # Now check mandatory headers: Via, From, To, Call-ID, CSeq
    mandatory = ['Via', 'From', 'To', 'Call-ID', 'CSeq']
    for m in mandatory:
        if m not in header_dict:
            return False
        if isinstance(header_dict[m], list) and len(header_dict[m]) == 0:
            return False
    # Check that Via appears at least once (it's in dict)
    # Check that From, To, Call-ID, CSeq are present (already)
    # Additional checks: CSeq must match syntax: 1*DIGIT SP Method
    cseq = header_dict['CSeq'] if not isinstance(header_dict['CSeq'], list) else header_dict['CSeq'][0]
    # Parse CSeq
    cseq_parts = cseq.split(' ', 1)
    if len(cseq_parts) != 2:
        return False
    cseq_num = cseq_parts[0]
    if not cseq_num.isdigit():
        return False
    # Method token: we'll accept any token (alphanumeric, hyphen, etc.)
    method = cseq_parts[1]
    if not method:
        return False
    # Optionally, we could check that method matches the request? But we don't have request.

    # Check Content-Length if present
    content_length = 0
    if 'Content-Length' in header_dict:
        cl = header_dict['Content-Length'] if not isinstance(header_dict['Content-Length'], list) else header_dict['Content-Length'][0]
        try:
            content_length = int(cl)
        except ValueError:
            return False
        if content_length < 0:
            return False

    # Now check body length
    body = response[pos:]
    if len(body) != content_length:
        return False

    # Check that there is no trailing data after body
    # body is exactly the remainder, so we need to ensure that we consumed the whole message.
    # pos is after double CRLF, so body is the rest. We already checked length matches Content-Length.
    # So if there is any extra, it would be because content_length is less than len(body). Already checked.
    # So no trailing data.

    # Check that the header names are valid tokens (printable ASCII, no spaces, certain chars)
    # We'll skip this to keep simple.

    # Also check that the Status-Line is fully consumed correctly.
    # We already did.

    # Note: The type rule is empty, so we rely on primary field (Status-Code). We already checked that.
    # Since the rule is unusable (empty), we use primary field only.

    return True