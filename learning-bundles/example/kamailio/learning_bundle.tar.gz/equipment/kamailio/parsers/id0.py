def packet_parser(response: bytes) -> bytes:
    try:
        text = response.decode('utf-8')
    except (UnicodeDecodeError, AttributeError):
        return b""
    # sip response line: SIP/2.0 <status-code> <reason>
    # Protocol: SIP, status-code is first token after version
    lines = text.split('\r\n')
    if not lines:
        return b""
    first_line = lines[0].strip()
    # Expected format: SIP/2.0 <status-code> ...
    parts = first_line.split()
    if len(parts) < 2:
        return b""
    # The first part should be SIP version, second the status code
    version_part = parts[0]
    if not version_part.startswith("SIP/"):
        return b""
    candidate = parts[1]
    # Validate it's a known status code from the list
    valid_codes = {"100", "180", "181", "182", "183", "200", "202", "300", "301", "302", "305", "380", "400", "401", "402", "403", "404", "405", "406", "407", "408", "410", "412", "413", "414", "415", "416", "420", "421", "423", "469", "480", "481", "482", "483", "484", "485", "486", "487", "488", "489", "491", "493", "500", "501", "502", "503", "504", "505", "513", "600", "603", "604", "606"}
    if candidate in valid_codes:
        return candidate.encode('utf-8')
    return b""