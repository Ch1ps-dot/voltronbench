def packet_parser(response: bytes) -> bytes:
    """
    Parse an FTP response to extract the 3-digit Reply-Code.
    Returns the code as UTF-8 bytes, or b"" if not found.
    """
    if not isinstance(response, bytes):
        return b""
    try:
        text = response.decode("utf-8", errors="replace")
    except Exception:
        return b""
    # The reply code is the first three characters, which must be digits.
    # According to RFC 959, the first three characters of the response line
    # are the three-digit reply code.
    if len(text) < 3:
        return b""
    code = text[:3]
    if not code.isdigit():
        return b""
    # Validate that the code is in the allowed list (from RESPONSE_FIELDS_JSON)
    valid_codes = {
        110, 120, 125, 150, 200, 202, 211, 212, 213, 214, 215, 220,
        221, 225, 226, 227, 229, 230, 232, 234, 235, 250, 257, 331,
        332, 334, 335, 336, 350, 421, 425, 426, 431, 450, 451, 452,
        500, 501, 502, 503, 504, 522, 530, 532, 533, 534, 535, 536,
        537, 550, 551, 552, 553, 631, 632, 633
    }
    try:
        code_int = int(code)
    except ValueError:
        return b""
    if code_int not in valid_codes:
        return b""
    return code.encode("utf-8")