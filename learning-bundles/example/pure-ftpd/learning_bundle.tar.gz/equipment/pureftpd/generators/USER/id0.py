def generate() -> bytes:
    # Build the USER request according to the IR field table and account info.
    # Fields: CommandCode (4B "USER"), Whitespace (1B 0x20), Username (variable), EndOfLine (2B 0x0D0A)
    username = "fuzzing"  # Use the provided user name from SUT context
    request = b"USER" + b" " + username.encode("ascii") + b"\r\n"
    return request