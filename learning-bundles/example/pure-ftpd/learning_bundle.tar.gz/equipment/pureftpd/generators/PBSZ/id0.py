from itertools import cycle

_SIZES = cycle((1, 1048576, 4294967295))

def generate() -> bytes:
    return b"PBSZ " + str(next(_SIZES)).encode("ascii") + b"\r\n"