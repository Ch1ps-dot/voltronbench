def generate() -> bytes:
    # Build the RNFR command according to the IR field table
    command_code = b"RNFR"
    whitespace = b"\x20"
    # Pathname: use a valid ASCII pathname (no CR/LF) - "testfile.txt" is a reasonable choice
    pathname = b"testfile.txt"
    end_of_line = b"\x0D\x0A"
    return command_code + whitespace + pathname + end_of_line