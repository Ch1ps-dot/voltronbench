import base64
import random

def generate() -> bytes:
    # CommandCode: "ADAT" (4 bytes, ASCII)
    cmd = b"ADAT"
    # Whitespace: 0x20 (1 byte)
    ws = b"\x20"
    # SecurityData: variable-length base64 encoded string
    # For valid state exploration, generate a random base64 string of moderate length
    # Use a random bytes payload, then encode to base64 (ASCII)
    payload_len = random.randint(4, 16)  # vary length for fuzzing
    payload = bytes(random.getrandbits(8) for _ in range(payload_len))
    security_data = base64.b64encode(payload)  # bytes, ASCII characters
    # EndOfLine: CRLF (2 bytes)
    eol = b"\r\n"
    # Concatenate in IR order
    return cmd + ws + security_data + eol