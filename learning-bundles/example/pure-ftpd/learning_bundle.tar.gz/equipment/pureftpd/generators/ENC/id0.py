def generate() -> bytes:
    import base64
    return b"ENC " + base64.b64encode(b"USER fuzzing") + b"\r\n"