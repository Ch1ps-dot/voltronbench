def generate() -> bytes:
    """
    Generate a valid ACCT (account) command for FTP.
    Uses the account information "fuzzing" as per the SUT context.
    """
    # Build the command parts in IR order:
    # 1. CommandCode: constant "ACCT"
    command_code = b"ACCT"
    # 2. Whitespace: constant 0x20 (space)
    whitespace = b"\x20"
    # 3. AccountInformation: variable length ASCII string, non-empty, no CR/LF
    # Use the SUT-provided account information: "fuzzing"
    account_info = b"fuzzing"
    # 4. EndOfLine: constant 0x0D0A (CRLF)
    eol = b"\r\n"
    
    return command_code + whitespace + account_info + eol