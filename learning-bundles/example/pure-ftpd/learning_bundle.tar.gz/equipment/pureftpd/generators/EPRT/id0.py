def generate() -> bytes:
    return b"EPRT |1|132.235.1.2|6275|\r\n"