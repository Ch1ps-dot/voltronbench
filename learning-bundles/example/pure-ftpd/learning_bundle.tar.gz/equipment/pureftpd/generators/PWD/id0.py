def generate() -> bytes:
    # Command code: "PWD" in ASCII uppercase
    command_code = b"PWD"
    # End-of-line: CRLF (0x0D 0x0A)
    crlf = b"\r\n"
    # Concatenate in IR order: command code followed by CRLF
    return command_code + crlf