def generate() -> bytes:
    return b"MKD fuzzing\r\n"