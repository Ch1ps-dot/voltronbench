def generate() -> bytes:
    # FEAT command: constant 4-byte ASCII command code "FEAT" followed by CRLF (0x0D 0x0A)
    command = b"FEAT"
    crlf = b"\r\n"
    return command + crlf