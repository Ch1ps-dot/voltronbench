def generate() -> bytes:
    # Build the OPTS command according to the field table
    # Constant fields
    command_code = b"OPTS"
    whitespace1 = b"\x20"  # space
    # Choose a variable command name: MLST is a common semantic value
    command_name = b"MLST"
    # Optional space and options: for MLST, provide a semicolon-separated list of facts
    # Use a common valid list: Type;Size;Modify;Perm
    options = b"\x20" + b"Type;Size;Modify;Perm"
    end_of_line = b"\x0D\x0A"
    # Assemble in order: CommandCode, Whitespace1, CommandName, OptionalSpaceAndOptions, EndOfLine
    return command_code + whitespace1 + command_name + options + end_of_line