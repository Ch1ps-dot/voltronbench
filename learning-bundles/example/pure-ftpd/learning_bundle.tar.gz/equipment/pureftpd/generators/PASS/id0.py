def generate() -> bytes:
    # Build the PASS command message according to the protocol definition
    # Fields in order: CommandCode, Whitespace, Password, EndOfLine
    
    # CommandCode: constant "PASS" (3 bytes)
    command_code = b"PASS"
    
    # Whitespace: constant 0x20 (1 byte space)
    whitespace = b"\x20"
    
    # Password: variable length, ASCII characters except CR (0x0D) and LF (0x0A)
    # Use the known password for the user "fuzzing" from the SUT context: "fuzzing"
    password = b"fuzzing"
    
    # EndOfLine: constant CR LF (0x0D 0x0A)
    end_of_line = b"\x0D\x0A"
    
    # Concatenate all fields in order
    message = command_code + whitespace + password + end_of_line
    
    return message