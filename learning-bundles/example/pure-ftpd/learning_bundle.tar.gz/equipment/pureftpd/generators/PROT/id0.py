def generate() -> bytes:
    return b"PROT C\r\n"