def generate() -> bytes:
    # Build the MLSD command with a valid pathname for fuzzing
    # Using the user's home directory "fuzzing" as a valid path for state exploration
    command_code = b"MLSD"
    whitespace = b" "  # Space between command and pathname
    pathname = b"fuzzing"  # Valid directory name, ASCII printable
    eol = b"\r\n"  # CRLF termination
    
    # Concatenate in specified order: CommandCode, Whitespace, Pathname, EndOfLine
    return command_code + whitespace + pathname + eol