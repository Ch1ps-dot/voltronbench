def generate() -> bytes:
    return b"RETR fuzzing\r\n"