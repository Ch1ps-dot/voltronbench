def generate() -> bytes:
    # Build the MLST command with no pathname argument (just listing current directory)
    # Fields in IR order: CommandCode (constant "MLST"), EndOfLine (constant CRLF)
    # When no pathname given, the Whitespace field is omitted per protocol specification.
    command = b"MLST"
    eol = b"\r\n"
    return command + eol