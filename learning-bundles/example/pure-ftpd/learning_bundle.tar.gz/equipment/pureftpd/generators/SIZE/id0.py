def generate() -> bytes:
    # Constants from IR
    command_code = b"SIZE"
    whitespace = b"\x20"
    # Variable pathname: choose a valid common file for state exploration
    pathname = b"/pub/test.txt"
    # End of line: CRLF
    eol = b"\r\n"
    
    # Assemble the complete SIZE request
    return command_code + whitespace + pathname + eol