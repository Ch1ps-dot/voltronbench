def generate() -> bytes:
    # Command code "STOU" in ASCII, 3 bytes as specified
    command_code = b"STOU"
    # End-of-line sequence: CR (0x0D) + LF (0x0A), 2 bytes
    eol = b"\x0D\x0A"
    # Concatenate in the order defined by the IR table: CommandCode then EndOfLine
    return command_code + eol