import base64

def generate() -> bytes:
    protected_command = b"USER fuzzing"
    mic_argument = base64.b64encode(protected_command)
    return b"MIC " + mic_argument + b"\r\n"