def generate() -> bytes:
    command_code = b"RNTO"
    whitespace = b"\x20"
    pathname = b"fuzzing_renamed_file"
    end_of_line = b"\r\n"
    return command_code + whitespace + pathname + end_of_line