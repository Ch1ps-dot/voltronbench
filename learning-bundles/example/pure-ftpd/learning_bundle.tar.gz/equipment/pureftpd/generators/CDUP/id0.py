def generate() -> bytes:
    # Command code "CDUP" in ASCII uppercase
    command = b"CDUP"
    # End-of-line marker: CRLF
    eol = b"\r\n"
    # Concatenate in IR order: CommandCode then EndOfLine
    return command + eol