def generate() -> bytes:
    # Build a DELE request with a valid pathname
    # Fields in IR order: CommandCode (4B constant "DELE"),
    # Whitespace (1B constant 0x20),
    # Pathname (variable length, printable ASCII except CR/LF),
    # EndOfLine (2B constant 0x0D0A)
    
    # Choose a concrete valid pathname: common file name for fuzzing
    pathname = "testfile.txt"
    
    # Construct the message
    request = b"DELE" + b" " + pathname.encode("ascii") + b"\r\n"
    return request