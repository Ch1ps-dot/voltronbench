def generate() -> bytes:
    if not hasattr(generate, "_variants"):
        generate._variants = (
            (None, None),
            (b" ", b"1"),
            (b" ", b"ALL"),
            (b" ", b"2"),
            (b" ", b"255"),
        )
        generate._idx = 0

    ws, arg = generate._variants[generate._idx % len(generate._variants)]
    generate._idx += 1

    if ws is None:
        return b"EPSV\r\n"
    return b"EPSV" + ws + arg + b"\r\n"