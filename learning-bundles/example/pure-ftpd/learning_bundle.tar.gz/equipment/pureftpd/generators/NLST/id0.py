def generate() -> bytes:
    # Command code: constant "NLST" (4 bytes)
    command = b"NLST"
    
    # Separator: at least one space (0x20) is valid; use one space for simplicity
    # This satisfies the "variable, undefined length" rule with a single space.
    separator = b" "
    
    # Pathname: optional; for valid request, we can omit it (empty) or provide a simple path.
    # To maximize state exploration, we provide a simple pathname like "/home/fuzzing" or keep empty.
    # Using an empty pathname (omit) is valid per RFC (if pathname is absent, current directory is used).
    # However, the protocol allows zero or more spaces for separator; if pathname is omitted, separator should also be omitted.
    # According to IR table: Separator is "zero or more spaces" and "omitted if no pathname is provided".
    # So for valid request with no pathname, we should omit separator as well.
    # But the contract says "concrete valid variable values" and "vary valid boundary/common values".
    # Let's provide a valid pathname to exercise the pathname field.
    pathname = b"/home/fuzzing"
    
    # EndOfLine: constant 0x0D0A (CRLF)
    eol = b"\r\n"
    
    # Construct request: Command + Separator + Pathname + EndOfLine
    # Ensure separator is present if pathname is non-empty.
    if pathname:
        request = command + separator + pathname + eol
    else:
        # If no pathname, separator is omitted per IR note.
        request = command + eol
    
    return request