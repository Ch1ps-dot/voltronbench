def generate() -> bytes:
    # Command code: "REIN" as ASCII bytes
    command_code = b"REIN"
    # End-of-line marker: CR LF (0x0D, 0x0A)
    eol = b"\r\n"
    # Build the complete REIN request: command code followed by end-of-line
    request = command_code + eol
    return request