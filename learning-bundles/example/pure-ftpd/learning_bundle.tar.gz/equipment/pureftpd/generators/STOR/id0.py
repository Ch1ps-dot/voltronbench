import struct

def generate() -> bytes:
    """
    Generate a valid STOR command for FTP fuzzing/state exploration.

    The command is constructed as:
        STOR <pathname>\r\n
    where <pathname> is a valid ASCII pathname without CR (0x0D) or LF (0x0A).
    """
    # Constant command code
    command_code = b"STOR"
    
    # Whitespace: one or more spaces (use a single space for simplicity)
    whitespace = b" "
    
    # Pathname: variable, valid ASCII characters (avoid CR and LF)
    # Use a common filename for fuzzing: "testfile.txt"
    pathname = b"testfile.txt"
    
    # End-of-line: CRLF (0x0D 0x0A)
    eol = b"\r\n"
    
    # Assemble the complete request in IR order
    request = command_code + whitespace + pathname + eol
    
    return request