import struct

def generate() -> bytes:
    # Build the MDTM command according to the IR field order
    # Fields: CommandCode (4B), Whitespace (1B), Pathname (variable), EndOfLine (2B)
    
    # CommandCode: "MDTM" in ASCII, uppercase as per note
    command_code = b"MDTM"
    
    # Whitespace: single space (0x20)
    whitespace = b"\x20"
    
    # Pathname: choose a valid existing file path for the fuzzing user's home directory
    # Use a common test file name in ASCII, no CR or LF
    pathname = b"/home/fuzzing/test.txt"
    
    # EndOfLine: CRLF (0x0D 0x0A)
    eol = b"\r\n"
    
    # Concatenate in IR order
    request = command_code + whitespace + pathname + eol
    return request