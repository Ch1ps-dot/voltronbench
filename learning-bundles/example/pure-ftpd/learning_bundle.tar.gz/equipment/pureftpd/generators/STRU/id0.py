def generate() -> bytes:
    # IR field order: CommandCode, Whitespace, StructureCode, EndOfLine
    # CommandCode constant: "STRU"
    # Whitespace constant: 0x20
    # StructureCode: "F" (as specified in type rule)
    # EndOfLine constant: 0x0D0A
    command = b"STRU"
    whitespace = b"\x20"
    structure_code = b"F"
    eol = b"\x0D\x0A"
    return command + whitespace + structure_code + eol