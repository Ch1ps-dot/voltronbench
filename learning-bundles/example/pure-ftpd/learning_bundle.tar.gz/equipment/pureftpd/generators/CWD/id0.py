import random

def generate() -> bytes:
    """
    Generates a valid FTP CWD (Change Working Directory) request.
    
    The message structure is:
    - CommandCode: "CWD" (3 bytes, ASCII, constant)
    - Whitespace: " " (1 byte, ASCII, constant)
    - Pathname: a variable-length ASCII path (no CR or LF)
    - EndOfLine: "\r\n" (2 bytes, constant)
    
    Returns:
        bytes: The complete CWD request.
    """
    # Constant parts
    command_code = b"CWD"         # 3 bytes, ASCII
    space = b" "                  # 1 byte, ASCII
    eol = b"\r\n"                 # 2 bytes, Carriage Return + Line Feed
    
    # Generate a valid pathname (variable length, ASCII, no CR/LF)
    # Choose a typical path: either a relative path or an absolute path
    # Use the known user "fuzzing" with home directory "/home/fuzzing"
    # Also vary with common root paths for state exploration
    paths = [
        "/home/fuzzing",
        "/home/fuzzing/documents",
        "/home/fuzzing/downloads",
        "/tmp",
        "/var/log",
        "/",
        "fuzzing",
        "test",
        "a",
        "/home/fuzzing/very_long_path_name_" + "x" * 50
    ]
    pathname = random.choice(paths).encode("ascii")
    
    # Ensure no CR (0x0D) or LF (0x0A) in pathname
    # (They are already not present in the chosen paths, but just in case)
    assert all(b not in pathname for b in (0x0D, 0x0A))
    
    # Assemble the request
    request = command_code + space + pathname + eol
    
    return request