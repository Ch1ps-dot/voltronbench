def generate() -> bytes:
    # Serialize the REST request per the IR field table for the REST command.
    # Fields in order: CommandCode, Whitespace, Marker, EndOfLine.
    # Use a valid marker value: "123" (decimal digits, in STREAM mode)
    command_code = b"REST"
    whitespace = b"\x20"
    marker = b"123"  # printable ASCII, decimal digits
    end_of_line = b"\x0D\x0A"
    return command_code + whitespace + marker + end_of_line