def generate() -> bytes:
    # Command code: "ABOR" in ASCII, 4 bytes
    command_code = b"ABOR"
    # End of line: CRLF, 2 bytes (0x0D 0x0A)
    end_of_line = b"\x0D\x0A"
    # Concatenate in IR order: CommandCode followed by EndOfLine
    return command_code + end_of_line