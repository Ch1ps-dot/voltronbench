def generate() -> bytes:
    # Build the ALLO command with the first argument (required) and optional second argument omitted
    command_code = b"ALLO"
    separator1 = b"\x20"  # space
    # Choose a valid decimal integer for the number of bytes to allocate
    first_argument = b"1024"  # decimal digits
    # Omit optional separator and second argument for simplicity, just end with CRLF
    end_of_line = b"\x0D\x0A"
    return command_code + separator1 + first_argument + end_of_line