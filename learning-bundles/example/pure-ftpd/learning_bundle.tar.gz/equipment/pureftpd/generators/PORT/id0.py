def generate() -> bytes:
    # Build the PORT command as per IR field table:
    # CommandCode: constant "PORT" (3 bytes ASCII)
    # Whitespace: constant 0x20 (space)
    # HostOctet1,2,3,4: decimal integers 0-255 each, separated by commas
    # PortOctet1,2: decimal integers 0-255 each, separated by commas
    # EndOfLine: constant 0x0D0A (CRLF)
    
    host_octets = [127, 0, 0, 1]  # localhost; valid IP octets
    # Use port 20 (0x14,0x00) -> PortOctet1=0, PortOctet2=20? Actually port 20 = 0x14 -> high=0, low=20
    port_high = 0
    port_low = 20   # FTP data port
    
    # Build argument string: "127,0,0,1,0,20"
    arg = f"{host_octets[0]},{host_octets[1]},{host_octets[2]},{host_octets[3]},{port_high},{port_low}"
    
    # Full command: "PORT " + arg + CRLF
    command = "PORT " + arg + "\r\n"
    
    return command.encode('ascii')