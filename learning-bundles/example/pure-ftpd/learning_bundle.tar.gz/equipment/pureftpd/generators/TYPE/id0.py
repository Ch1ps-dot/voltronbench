def generate() -> bytes:
    # Build the TYPE command according to IR field definitions
    # CommandCode: constant "TYPE" (4 bytes ASCII)
    # Separator: space (0x20)
    # TypeCode: for this valid request, we choose ASCII type 'A'
    #   No optional format specifier to keep it simple
    # EndOfLine: CRLF (0x0D 0x0A)
    
    command = b"TYPE"
    separator = b"\x20"
    # For ASCII type, we send 'A' (1 byte)
    type_code = b"A"
    eol = b"\x0D\x0A"
    
    return command + separator + type_code + eol