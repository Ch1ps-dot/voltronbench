def generate() -> bytes:
    # QUIT command: constant "QUIT" (3 bytes) + CRLF (2 bytes)
    return b"QUIT\r\n"