import struct

def generate() -> bytes:
    # Build the RMD request as per IR field table
    # Fields: CommandCode (3B constant "RMD"), Whitespace (1B 0x20), Pathname (variable ASCII), EndOfLine (2B 0x0D0A)
    command_code = b"RMD"          # 3 bytes
    whitespace = b"\x20"           # 1 byte space
    # Choose a valid pathname: relative directory name, no CR/LF, ASCII
    pathname = b"testdir"          # variable length, valid ASCII
    end_of_line = b"\x0D\x0A"      # CRLF

    # Concatenate in order
    return command_code + whitespace + pathname + end_of_line