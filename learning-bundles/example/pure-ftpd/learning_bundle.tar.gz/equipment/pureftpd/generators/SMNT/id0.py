def generate() -> bytes:
    # CommandCode: constant "SMNT" (4 bytes, ASCII)
    command_code = b"SMNT"
    
    # Whitespace: single space (0x20, 1 byte)
    whitespace = b"\x20"
    
    # Pathname: variable length, ASCII characters except CR/LF
    # Use a valid pathname typical for FTP file system mounting.
    # We choose "/tmp/fuzz" as a concrete valid pathname.
    pathname = b"/tmp/fuzz"
    
    # EndOfLine: CRLF (0x0D 0x0A, 2 bytes)
    end_of_line = b"\r\n"
    
    # Concatenate in IR order: CommandCode, Whitespace, Pathname, EndOfLine
    request = command_code + whitespace + pathname + end_of_line
    
    return request