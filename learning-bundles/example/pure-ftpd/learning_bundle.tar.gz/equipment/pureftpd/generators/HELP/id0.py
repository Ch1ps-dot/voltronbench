def generate() -> bytes:
    return b"HELP USER\r\n"