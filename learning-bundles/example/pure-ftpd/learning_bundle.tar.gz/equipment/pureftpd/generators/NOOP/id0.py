def generate() -> bytes:
    # Fixed command code for NOOP: four ASCII characters
    command_code = b"NOOP"
    # Telnet end-of-line sequence: CR (0x0D) followed by LF (0x0A)
    end_of_line = b"\x0D\x0A"
    # Concatenate in IR field order
    return command_code + end_of_line