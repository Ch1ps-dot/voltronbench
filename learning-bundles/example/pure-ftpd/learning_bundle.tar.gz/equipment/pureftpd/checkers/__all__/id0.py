def packet_checker(response: bytes) -> bool:
    # Reject non-bytes
    if not isinstance(response, bytes):
        return False

    # Must be at least 3 digits + 1 separator + 2 CRLF = 6 bytes minimum
    if len(response) < 6:
        return False

    # Check end-of-line (CRLF) at the end of the message
    if response[-2:] != b'\r\n':
        return False

    # Extract the first line: everything up to the first CRLF
    # Find the first CRLF
    crlf_idx = response.find(b'\r\n')
    if crlf_idx == -1:
        return False

    first_line = response[:crlf_idx]
    # Must have at least 4 bytes (3 digits + separator)
    if len(first_line) < 4:
        return False

    # StatusCode: first 3 bytes must be digits 0-9
    status_code_bytes = first_line[:3]
    if not all(48 <= b <= 57 for b in status_code_bytes):
        return False
    status_code = int(status_code_bytes)
    # StatusCode must be between 100 and 599 inclusive
    if status_code < 100 or status_code > 599:
        return False

    # Separator: 4th byte must be space (0x20) or hyphen (0x2D)
    separator = first_line[3:4]
    if separator not in (b' ', b'-'):
        return False

    # Text: the rest of the first line (after separator) must be printable ASCII or whitespace
    # TCHAR: VCHAR (0x21-0x7E), SP (0x20), HTAB (0x09)
    text_part = first_line[4:]
    for byte in text_part:
        if byte not in (0x09, 0x20) and (byte < 0x21 or byte > 0x7E):
            return False

    # If separator is hyphen, it's a multi-line reply
    if separator == b'-':
        # After the first line, there can be additional lines, each terminated by CRLF
        # The last line must start with the same StatusCode followed by a space
        # Check that the message ends with the last line that matches the pattern
        remaining = response[crlf_idx + 2:]  # after first CRLF
        if not remaining:
            # Multi-line reply must have at least one more line
            return False

        # Split remaining into lines by CRLF
        # Last line must end with CRLF which we already checked, but we need to ensure it's properly terminated
        # The remaining should end with CRLF as well? Actually the whole message ends with CRLF, so the last line
        # is already accounted for in the initial check. But we need to ensure the last line starts with StatusCode + space.
        # Let's find all lines in remaining:
        lines = remaining.split(b'\r\n')
        # The last element after split will be empty because trailing CRLF
        if lines and lines[-1] == b'':
            lines = lines[:-1]  # remove empty trailing element
        if not lines:
            return False
        # Check each intermediate line (if any) - all must be acceptable text
        for i, line in enumerate(lines):
            if i < len(lines) - 1:
                # Intermediate line: must be valid text (any printable ASCII or whitespace)
                for byte in line:
                    if byte not in (0x09, 0x20) and (byte < 0x21 or byte > 0x7E):
                        return False
            else:
                # Last line: must start with same StatusCode + space
                if len(line) < 4:
                    return False
                # Check first 3 bytes match StatusCode
                if line[:3] != status_code_bytes:
                    return False
                # Check 4th byte is space
                if line[3:4] != b' ':
                    return False
                # Check remaining text
                text_part_last = line[4:]
                for byte in text_part_last:
                    if byte not in (0x09, 0x20) and (byte < 0x21 or byte > 0x7E):
                        return False
    else:
        # Single-line reply: no more lines allowed after the first CRLF
        # But there might be extra CRLF? The check above already ensures the message ends with the first line's CRLF?
        # Actually we need to ensure no extra data after the first CRLF
        # The response is the entire message, and we already checked it ends with CRLF.
        # If the first line's CRLF is the only one, then the remaining after first CRLF is empty.
        # Let's check if there is anything after the first CRLF (excluding the final CRLF itself)
        # Actually the response ends with CRLF, so if the first line is the whole message, then crlf_idx == len(response)-2
        # But consider a multi-line message: the first line is not the whole message.
        # For single-line, we must ensure no extra bytes after the first CRLF.
        # The response might have the first CRLF at the end.
        # So we require that the first CRLF is exactly at len(response)-2.
        if crlf_idx != len(response) - 2:
            return False

    # If we got here, all checks passed
    return True