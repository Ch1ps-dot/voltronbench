import hashlib

def packet_observer(response: bytes) -> str:
    """
    Observer for FTP server responses.
    Normalizes the human-readable text portion (dynamic, non-behavioral)
    while preserving the three-digit status code, separator, framing, and end-of-line.
    If the response is empty or cannot be parsed safely, returns the SHA-256 of the original bytes.
    """
    if not isinstance(response, bytes):
        response = b""
    if not response:
        return hashlib.sha256(b"").hexdigest()
    
    try:
        # Split into lines on CRLF (0x0D0A)
        lines = response.split(b"\r\n")
        # Remove trailing empty line if present
        if lines and lines[-1] == b"":
            lines = lines[:-1]
        if not lines:
            return hashlib.sha256(response).hexdigest()
        
        normalized_lines = []
        for line in lines:
            if len(line) < 4:
                # Not enough for status code + separator; keep original
                normalized_lines.append(line)
                continue
            status_bytes = line[:3]
            separator = line[3:4]
            rest = line[4:]
            # Validate status code: three digits
            try:
                status_code = int(status_bytes)
                if not (100 <= status_code <= 599):
                    raise ValueError
            except (ValueError, TypeError):
                # Invalid status code; keep original
                normalized_lines.append(line)
                continue
            
            # Valid separator is space (0x20) or hyphen (0x2D)
            if separator not in (b" ", b"-"):
                # Invalid separator; keep original
                normalized_lines.append(line)
                continue
            
            # Normalize the text portion: replace printable ASCII text with a fixed marker
            # Preserve the length of the original text to maintain structure
            text_len = len(rest)
            if text_len > 0:
                # Replace with a marker of same length; use 'X' as placeholder
                normalized_text = b"X" * text_len
            else:
                normalized_text = b""
            normalized_line = status_bytes + separator + normalized_text
            normalized_lines.append(normalized_line)
        
        # Rebuild with CRLF between lines
        if normalized_lines:
            normalized_response = b"\r\n".join(normalized_lines) + b"\r\n"
        else:
            normalized_response = b""
        return hashlib.sha256(normalized_response).hexdigest()
    except Exception:
        # If any parsing error occurs, fall back to original bytes
        return hashlib.sha256(response).hexdigest()