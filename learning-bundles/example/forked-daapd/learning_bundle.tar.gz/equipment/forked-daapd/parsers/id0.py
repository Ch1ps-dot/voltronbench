def packet_parser(response: bytes) -> bytes:
    try:
        # DAAP uses HTTP-like response lines; the first line has Status-Code
        # as the second token after the protocol version
        text = response.decode('utf-8', errors='replace')
        # Split on whitespace; first token is HTTP version, second is status code
        parts = text.split(None, 2)  # at most 2 splits: first token, second token, rest
        if len(parts) < 2:
            return b""
        status_code = parts[1]
        # Validate it is one of the known values from the spec
        known = {
            "100", "101", "200", "201", "202", "203", "204", "205", "206",
            "300", "301", "302", "303", "304", "305", "306", "307", "308",
            "400", "401", "402", "403", "404", "405", "406", "407", "408",
            "409", "410", "411", "412", "413", "414", "415", "416", "417",
            "418", "421", "422", "426", "500", "501", "502", "503", "504", "505"
        }
        if status_code in known:
            return status_code.encode('utf-8')
        else:
            return b""
    except Exception:
        return b""