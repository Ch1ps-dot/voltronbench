import struct

def generate() -> bytes:
    # Build a POST request to add items to the queue
    # Use a valid path from the API: /api/queue/items/add
    request_target = "/api/queue/items/add?id=123"
    http_version = "HTTP/1.1"
    host = "localhost"
    content_type = "application/json"
    # JSON body: add a track from the library, e.g., the first track of an album
    # Use a simple valid JSON that adds a track by URI
    body = b'{"uris": ["library:track:1"]}'
    content_length = len(body)
    
    # Build header fields
    headers = []
    headers.append(f"Host: {host}\r\n")
    headers.append(f"Content-Type: {content_type}\r\n")
    headers.append(f"Content-Length: {content_length}\r\n")
    # Optionally add Accept header
    headers.append("Accept: */*\r\n")
    # Combine header fields (no extra CRLF after last header, that's the terminating CRLF)
    header_fields = "".join(headers).encode("ascii")
    
    # Build request line: Method SP RequestTarget SP HTTPVersion CRLF
    request_line = b"POST " + request_target.encode("ascii") + b" " + http_version.encode("ascii") + b"\r\n"
    
    # Terminating CRLF (empty line)
    terminating_crlf = b"\r\n"
    
    # Assemble full message
    message = request_line + header_fields + terminating_crlf + body
    
    return message