_GET_TARGETS = [
    b'/api/player',
    b'/api/outputs',
    b'/api/queue',
    b'/api/library',
    b'/api/library/playlists',
    b'/api/library/artists',
    b'/api/library/albums',
    b'/api/library/genres',
    b'/api/library/count',
    b'/api/library/files',
]
_gen_idx = 0

def generate() -> bytes:
    global _gen_idx
    # Build a valid HTTP GET request for forked-daapd API
    # Fields in IR order:
    # Method: constant GET
    method = b'GET'
    # Separator1: constant 0x20 (space)
    sep1 = b' '
    # RequestTarget: variable, choose a valid GET API endpoint from SUT_CONTEXT
    request_target = _GET_TARGETS[_gen_idx % len(_GET_TARGETS)]
    _gen_idx += 1
    # Separator2: constant 0x20 (space)
    sep2 = b" "
    # HTTPVersion: variable, use HTTP/1.1
    http_version = b"HTTP/1.1"
    # EndOfLine1: constant 0x0D0A (CRLF)
    eol1 = b"\r\n"
    # HeaderSection: variable, must include at least the Host header for HTTP/1.1
    # and terminate with an empty line (CRLF)
    host_header = b'Host: localhost:3689\r\n'
    # End of header section marker: empty line (CRLF)
    header_end = b"\r\n"
    # Combine all fields in order
    message = (
        method
        + sep1
        + request_target
        + sep2
        + http_version
        + eol1
        + host_header
        + header_end
    )
    return message