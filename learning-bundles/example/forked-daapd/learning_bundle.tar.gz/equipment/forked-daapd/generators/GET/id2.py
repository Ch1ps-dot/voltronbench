HTTP_METHODS = [b'GET', b'PUT', b'POST', b'DELETE']
_GET_TARGETS = [
    b'/api/player',
    b'/api/outputs',
    b'/api/queue',
    b'/api/library',
    b'/api/library/playlists',
    b'/api/library/artists',
    b'/api/library/albums',
    b'/api/library/genres',
    b'/api/library/count',
    b'/api/library/files',
]
# Targets for PUT, POST, DELETE that require additional fields
_PUT_TARGETS = [
    b'/api/player/play',
    b'/api/player/pause',
    b'/api/player/stop',
    b'/api/player/toggle',
    b'/api/player/next',
    b'/api/player/previous',
    b'/api/player/shuffle',
    b'/api/player/consume',
    b'/api/player/repeat',
    b'/api/player/volume',
    b'/api/player/seek',
    b'/api/outputs/set',
    b'/api/outputs/1',
    b'/api/outputs/1/toggle',
    b'/api/queue/clear',
    b'/api/queue/items/1',
    b'/api/library/playlists/1',
    b'/api/library/tracks',
    b'/api/library/tracks/1',
    b'/api/update',
    b'/api/rescan',
    b'/api/library/backup',
]
_POST_TARGETS = [
    b'/api/queue/items/add',
    b'/api/library/add',
]
_DELETE_TARGETS = [
    b'/api/queue/items/1',
    b'/api/library/playlists/1',
]
_gen_idx = 0
_method_idx = 0

def generate() -> bytes:
    global _gen_idx, _method_idx
    # Cycle through HTTP methods to reach PUT, POST, DELETE states
    method = HTTP_METHODS[_method_idx % len(HTTP_METHODS)]
    _method_idx += 1
    sep1 = b' '
    # Choose request target based on method
    if method == b'GET':
        request_target = _GET_TARGETS[_gen_idx % len(_GET_TARGETS)]
        _gen_idx += 1
    elif method == b'PUT':
        request_target = _PUT_TARGETS[_gen_idx % len(_PUT_TARGETS)]
        _gen_idx += 1
    elif method == b'POST':
        request_target = _POST_TARGETS[_gen_idx % len(_POST_TARGETS)]
        _gen_idx += 1
    else:  # DELETE
        request_target = _DELETE_TARGETS[_gen_idx % len(_DELETE_TARGETS)]
        _gen_idx += 1
    sep2 = b' '
    http_version = b'HTTP/1.1'
    eol1 = b'\r\n'
    host_header = b'Host: localhost:3689\r\n'
    header_end = b'\r\n'
    message = (
        method
        + sep1
        + request_target
        + sep2
        + http_version
        + eol1
        + host_header
        + header_end
    )
    return message