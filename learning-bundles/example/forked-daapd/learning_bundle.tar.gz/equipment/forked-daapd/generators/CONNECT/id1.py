def generate() -> bytes:
    # Build the CONNECT request line
    # Method: CONNECT (constant, 7 bytes)
    method = b"CONNECT"
    # SP (constant, 1 byte)
    sp = b" "
    # RequestTarget: authority-form host:port
    # Use the API endpoint /api/player for a GET request (valid DAAP resource)
    host = b"localhost"
    port = b"3689"
    request_target = host + b":" + port
    # SP
    sp2 = b" "
    # HTTPVersion: HTTP/1.1 (common for CONNECT)
    http_version = b"HTTP/1.1"
    # CRLF
    crlf = b"\r\n"
    # HeaderSection: must include Host header matching request target, then empty line
    # Host header: Host: localhost:3689
    host_header = b"Host: " + request_target + b"\r\n"
    # Add a minimal set of headers as required by the protocol
    # End with final CRLF (empty line)
    headers = host_header + b"\r\n"
    # Assemble the full request
    request = method + sp + request_target + sp2 + http_version + crlf + headers
    return request