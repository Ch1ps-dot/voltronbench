def generate() -> bytes:
    # Build the CONNECT request line
    # Method: CONNECT (constant, 7 bytes)
    method = b"CONNECT"
    # SP (constant, 1 byte)
    sp = b" "
    # RequestTarget: authority-form host:port
    # Use a valid host and port from the SUT context (e.g., server.example.com:443)
    # For fuzzing exploration, use a common valid target
    host = b"server.example.com"
    port = b"443"
    request_target = host + b":" + port
    # SP
    sp2 = b" "
    # HTTPVersion: HTTP/1.1 (common for CONNECT)
    http_version = b"HTTP/1.1"
    # CRLF
    crlf = b"\r\n"
    # HeaderSection: must include Host header matching request target, then empty line
    # Host header: Host: server.example.com:443
    host_header = b"Host: " + request_target + b"\r\n"
    # Optional: add a minimal set of headers (e.g., Proxy-Authorization not required)
    # End with final CRLF (empty line)
    headers = host_header + b"\r\n"
    # Assemble the full request
    request = method + sp + request_target + sp2 + http_version + crlf + headers
    return request