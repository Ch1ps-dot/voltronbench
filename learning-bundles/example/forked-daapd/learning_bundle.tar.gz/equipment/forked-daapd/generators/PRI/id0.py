def generate() -> bytes:
    # Build the PRI method request line for HTTP/2 connection preface
    # Fields in IR order: Method, Space, RequestTarget, Space, HttpVersion, StartLineEnd, EmptyLine
    
    # Method: constant "PRI" (3 bytes)
    method = b"PRI"
    
    # Space: single byte 0x20
    space1 = b"\x20"
    
    # RequestTarget: constant "*" (1 byte)
    request_target = b"*"
    
    # Space: single byte 0x20
    space2 = b"\x20"
    
    # HttpVersion: constant "HTTP/2.0" (8 bytes)
    http_version = b"HTTP/2.0"
    
    # StartLineEnd: CRLF 0x0D 0x0A (2 bytes)
    crlf = b"\r\n"
    
    # EmptyLine: CRLF 0x0D 0x0A (2 bytes) representing empty header section
    empty_line = b"\r\n"
    
    # Concatenate all fields in order
    return method + space1 + request_target + space2 + http_version + crlf + empty_line