import struct

def generate() -> bytes:
    # Build a valid HTTP OPTIONS request for forked-daapd DAAP server
    # Fields in IR order:
    # 1. Method: constant "OPTIONS" (7 bytes)
    # 2. Space1: constant 0x20 (1 byte)
    # 3. RequestTarget: variable; use '*' for server-wide query (common for OPTIONS)
    # 4. Space2: constant 0x20 (1 byte)
    # 5. HTTPVersion: variable; use HTTP/1.1 (common + valid)
    # 6. RequestLineCRLF: constant 0x0D0A (2 bytes)
    # 7. HeaderSection: variable; include Host header (required in HTTP/1.1) and Connection header
    # 8. EmptyLine: constant 0x0D0A (2 bytes) terminating headers
    # 9. MessageBody: variable; empty for OPTIONS (almost never has body)

    method = b"OPTIONS"
    space1 = b"\x20"
    request_target = b"*"  # server-wide query - valid for OPTIONS
    space2 = b"\x20"
    http_version = b"HTTP/1.1"
    request_line_crlf = b"\r\n"

    # Header section: include Host and Connection (common required headers)
    # Host: forked-daapd may listen on port 3689, use localhost for generality
    host_header = b"Host: localhost:3689\r\n"
    # Connection header to keep alive (common)
    connection_header = b"Connection: keep-alive\r\n"
    # User-Agent (optional but common)
    user_agent_header = b"User-Agent: DAAP-Fuzzer/1.0\r\n"

    # Accept header (common for OPTIONS)
    accept_header = b"Accept: */*\r\n"

    # Combine headers
    header_section = host_header + connection_header + user_agent_header + accept_header

    # Empty line terminating headers
    empty_line = b"\r\n"

    # Message body: empty (no body for OPTIONS)
    message_body = b""

    # Concatenate all parts in IR order
    request = (
        method +
        space1 +
        request_target +
        space2 +
        http_version +
        request_line_crlf +
        header_section +
        empty_line +
        message_body
    )

    return request