import random

def generate() -> bytes:
    # Build the DELETE request line: DELETE <target> HTTP/1.1
    method = b'DELETE'
    sp1 = b' '

    # Vary between supported DELETE resources from SUT_CONTEXT.
    # Include both queue items and library playlists for better coverage.
    request_target = random.choice([
        b'/api/queue/items/1',
        b'/api/queue/items/now_playing',
        b'/api/library/playlists/1',
        b'/api/library/playlists/2',
    ])
    sp2 = b' '
    http_version = b'HTTP/1.1'
    crlf1 = b'\r\n'

    # Build header section: Host header + optional valid headers + empty line.
    # Always include Host header; vary other headers to explore different states.
    optional_headers = [
        b'Accept: */*\r\n',
        b'User-Agent: forked-daapd-client/1.0\r\n',
        b'Connection: keep-alive\r\n',
        b'Content-Length: 0\r\n',
    ]
    extra_headers = b''.join(
        header for header in optional_headers if random.choice([True, False])
    )
    header_section = b'Host: localhost\r\n' + extra_headers + b'\r\n'

    # The body is optional and typically empty for DELETE requests.
    body = b''

    # Assemble in IR order: Method, SP1, RequestTarget, SP2, HTTPVersion, CRLF1, HeaderSection, Body
    request = method + sp1 + request_target + sp2 + http_version + crlf1 + header_section + body

    return request