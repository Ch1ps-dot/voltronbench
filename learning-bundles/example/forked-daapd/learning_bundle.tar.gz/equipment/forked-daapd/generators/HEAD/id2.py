import struct

def generate() -> bytes:
    # Vary existing fields and also add more request targets, version, and header combinations
    # to reach additional unobserved legal protocol states.
    targets = [
        b'/api/player',
        b'/api/outputs',
        b'/api/queue',
        b'/api/library',
        b'/api/library/playlists',
        b'/api/library/artists',
        b'/api/library/albums',
        b'/api/library/genres',
        b'/api/library/count',
        b'/api/library/files',
        b'/api/library/playlists/1',
        b'/api/library/artists/1',
        b'/api/library/albums/1',
        b'/api/library/tracks/1',
        b'/api/outputs/1',
        b'/api/queue/items/1',
        b'/api/queue/items/now_playing',
    ]
    versions = [b'HTTP/1.1', b'HTTP/1.0']
    header_sets = [
        (b'Host: localhost:3689', b'Accept: */*'),
        (b'Host: localhost:3689',),
        (b'Host: localhost:3689', b'User-Agent: forked-daapd-test'),
        (b'Host: localhost:3689', b'Accept: */*', b'Connection: close'),
        (b'Host: localhost:3689', b'Accept: */*', b'Connection: keep-alive'),
        (b'Host: localhost:3689', b'User-Agent: forked-daapd-test', b'Connection: close'),
    ]

    variants = [
        (target, version, headers)
        for target in targets
        for version in versions
        for headers in header_sets
    ]

    if not hasattr(generate, '_idx'):
        generate._idx = 0
    target, version, headers = variants[generate._idx % len(variants)]
    generate._idx = (generate._idx + 1) % len(variants)

    method = b'HEAD'
    space = b' '
    crlf = bytes((13, 10))

    request_line = method + space + target + space + version + crlf

    header_block = b''.join(header + crlf for header in headers) + crlf

    return request_line + header_block