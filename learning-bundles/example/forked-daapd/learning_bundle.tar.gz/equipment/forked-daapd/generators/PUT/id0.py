def generate() -> bytes:
    # Build a valid HTTP PUT request for forked-daapd
    # Choose a valid endpoint: /api/player/play
    method = b"PUT"
    sp1 = b" "
    target = b"/api/player/play"
    sp2 = b" "
    http_version = b"HTTP/1.1"
    crlf1 = b"\r\n"
    
    # Headers: Host is required, Content-Length 0 for play (no body)
    host = b"Host: localhost:3689\r\n"
    content_length = b"Content-Length: 0\r\n"
    # Optional header for DAAP client
    user_agent = b"User-Agent: DAAP Fuzzer\r\n"
    # Empty line to end headers
    header_end = b"\r\n"
    
    header_section = host + content_length + user_agent + header_end
    
    # Message body is empty (play has no body)
    message_body = b""
    
    # Assemble in IR order: Method, SP1, RequestTarget, SP2, HTTPVersion, CRLF1, HeaderSection, MessageBody
    request = method + sp1 + target + sp2 + http_version + crlf1 + header_section + message_body
    return request