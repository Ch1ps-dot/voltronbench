def generate() -> bytes:
    # Build valid HTTP PUT requests for legal no-body SUT endpoints.
    if not hasattr(generate, '_index'):
        generate._index = 0
    endpoints = [
        b'/api/update',
        b'/api/rescan',
        b'/api/player/play',
        b'/api/player/pause',
        b'/api/player/stop',
        b'/api/player/toggle',
        b'/api/player/next',
        b'/api/player/previous',
        b'/api/queue/clear',
        b'/api/library/backup',
    ]
    method = b'PUT'
    sp1 = b' '
    target = endpoints[generate._index % len(endpoints)]
    generate._index += 1
    sp2 = b" "
    http_version = b"HTTP/1.1"
    crlf1 = b"\r\n"
    
    # Headers: Host is required, Content-Length 0 for no body
    host = b"Host: localhost:3689\r\n"
    content_length = b"Content-Length: 0\r\n"
    user_agent = b"User-Agent: DAAP Fuzzer\r\n"
    header_end = b"\r\n"
    
    header_section = host + content_length + user_agent + header_end
    
    # Message body is empty
    message_body = b""
    
    # Assemble in IR order: Method, SP1, RequestTarget, SP2, HTTPVersion, CRLF1, HeaderSection, MessageBody
    request = method + sp1 + target + sp2 + http_version + crlf1 + header_section + message_body
    return request