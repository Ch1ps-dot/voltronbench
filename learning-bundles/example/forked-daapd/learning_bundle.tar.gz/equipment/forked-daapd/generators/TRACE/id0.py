def generate() -> bytes:
    # Build a valid TRACE request for forked-daapd
    # Request line: "TRACE /api/player HTTP/1.1\r\n"
    method = b"TRACE"
    sp1 = b" "
    # Use a valid API endpoint from the SUT; root path is safe
    request_target = b"/api/player"
    sp2 = b" "
    http_version = b"HTTP/1.1"
    crlf1 = b"\r\n"
    
    # Header section: Host header is required by HTTP/1.1, plus empty line termination
    host_header = b"Host: localhost:3689\r\n"  # default daap port
    # Optional: Max-Forwards header (common for TRACE)
    # Use a reasonable value, e.g., 0
    max_forwards = b"Max-Forwards: 0\r\n"
    # Empty line to terminate headers
    empty_line = b"\r\n"
    
    # Concatenate in order
    request_line = method + sp1 + request_target + sp2 + http_version + crlf1
    header_section = host_header + max_forwards + empty_line
    
    return request_line + header_section