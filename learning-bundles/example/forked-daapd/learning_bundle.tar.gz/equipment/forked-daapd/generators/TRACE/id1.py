def generate() -> bytes:
    # Build a valid TRACE request for forked-daapd
    # Select an API endpoint from SUT and vary optional TRACE headers.
    method = b"TRACE"
    sp1 = b" "
    sp2 = b" "
    http_version = b"HTTP/1.1"
    crlf1 = b"\r\n"

    targets = [
        b"/api/player",
        b"/api/outputs",
        b"/api/queue",
        b"/api/library",
        b"/api/library/playlists",
        b"/api/library/artists",
        b"/api/library/albums",
        b"/api/library/genres",
        b"/api/library/count",
        b"/api/library/files",
    ]
    # Max-Forwards is optional; the empty option removes it.
    max_forwards_options = [
        b"Max-Forwards: 0\r\n",
        b"Max-Forwards: 1\r\n",
        b"Max-Forwards: 2\r\n",
        b"Max-Forwards: 5\r\n",
        b"",
    ]
    if not hasattr(generate, "_index"):
        generate._index = 0
    idx = generate._index
    generate._index += 1
    request_target = targets[idx % len(targets)]
    max_forwards = max_forwards_options[(idx // len(targets)) % len(max_forwards_options)]
    # Header section: Host is required by HTTP/1.1.
    host_header = b"Host: localhost:3689\r\n"  # default daap port
    # Empty line to terminate headers
    empty_line = b"\r\n"
    
    # Concatenate in order
    request_line = method + sp1 + request_target + sp2 + http_version + crlf1
    header_section = host_header + max_forwards + empty_line
    
    return request_line + header_section