def generate() -> bytes:
    # Build a valid TRACE request for forked-daapd
    # Select an API endpoint from SUT and vary optional TRACE headers.
    method = b"TRACE"
    sp1 = b" "
    sp2 = b" "
    http_version = b"HTTP/1.1"
    crlf1 = b"\r\n"

    targets = [
        b"/api/player",
        b"/api/outputs",
        b"/api/queue",
        b"/api/library",
        b"/api/library/playlists",
        b"/api/library/artists",
        b"/api/library/albums",
        b"/api/library/genres",
        b"/api/library/count",
        b"/api/library/files",
        b"/api/player/play",
        b"/api/player/pause",
        b"/api/player/stop",
        b"/api/player/toggle",
        b"/api/player/next",
        b"/api/player/previous",
        b"/api/player/shuffle",
        b"/api/player/consume",
        b"/api/player/repeat",
        b"/api/player/volume",
        b"/api/player/seek",
        b"/api/outputs/set",
        b"/api/queue/clear",
        b"/api/queue/items/add",
        b"/api/queue/items/now_playing",
        b"/api/library/tracks",
        b"/api/library/add",
        b"/api/update",
        b"/api/rescan",
        b"/api/library/backup",
    ]
    # Optional header blocks: every entry is zero or more complete header
    # field lines, each ending with CRLF. The empty entry omits optional
    # headers, leaving the required Host header and terminating blank line.
    optional_headers = [
        b"Max-Forwards: 0\r\n",
        b"Max-Forwards: 1\r\n",
        b"Max-Forwards: 2\r\n",
        b"Max-Forwards: 3\r\n",
        b"Max-Forwards: 4\r\n",
        b"Max-Forwards: 5\r\n",
        b"Max-Forwards: 10\r\n",
        b"Max-Forwards: 255\r\n",
        b"",
        b"Max-Forwards: 0\r\nUser-Agent: daap-client/1.0\r\n",
        b"Max-Forwards: 1\r\nAccept: */*\r\n",
        b"User-Agent: daap-client/1.0\r\n",
        b"Accept: */*\r\n",
        b"Connection: close\r\n",
    ]
    if not hasattr(generate, "_index"):
        generate._index = 0
    idx = generate._index
    generate._index += 1
    request_target = targets[idx % len(targets)]
    optional = optional_headers[(idx // len(targets)) % len(optional_headers)]
    # Header section: Host is required by HTTP/1.1.
    host_header = b"Host: localhost:3689\r\n"  # default daap port
    # Empty line to terminate headers
    empty_line = b"\r\n"

    # Concatenate in order
    request_line = method + sp1 + request_target + sp2 + http_version + crlf1
    header_section = host_header + optional + empty_line
    
    return request_line + header_section