def packet_checker(response: bytes) -> bool:
    # Reject non-bytes input
    if not isinstance(response, bytes):
        return False

    # Must start with "HTTP/" (4 bytes "HTTP" + 1 byte "/")
    if len(response) < 5:
        return False
    if response[:4] != b"HTTP":
        return False
    if response[4] != 0x2F:  # '/'
        return False

    # Parse major version: one or more digits
    pos = 5
    major_start = pos
    while pos < len(response) and 48 <= response[pos] <= 57:  # '0'-'9'
        pos += 1
    if pos == major_start:
        return False
    major_version = response[major_start:pos]

    # Must have a dot
    if pos >= len(response) or response[pos] != 0x2E:  # '.'
        return False
    pos += 1

    # Parse minor version: one or more digits
    minor_start = pos
    while pos < len(response) and 48 <= response[pos] <= 57:
        pos += 1
    if pos == minor_start:
        return False
    minor_version = response[minor_start:pos]

    # Must have space after version
    if pos >= len(response) or response[pos] != 0x20:  # space
        return False
    pos += 1

    # Status code: exactly 3 digits
    if pos + 3 > len(response):
        return False
    status_bytes = response[pos:pos+3]
    # Check digits
    for b in status_bytes:
        if not (48 <= b <= 57):
            return False
    status_code = status_bytes.decode('ascii')
    # Validate against allowed list (primary field)
    # The rule JSON is empty, so we use primary field list
    allowed_status_codes = {
        "100", "101", "200", "201", "202", "203", "204", "205", "206",
        "300", "301", "302", "303", "304", "305", "306", "307", "308",
        "400", "401", "402", "403", "404", "405", "406", "407", "408",
        "409", "410", "411", "412", "413", "414", "415", "416", "417",
        "418", "421", "422", "426",
        "500", "501", "502", "503", "504", "505"
    }
    if status_code not in allowed_status_codes:
        return False
    pos += 3

    # Must have space after status code
    if pos >= len(response) or response[pos] != 0x20:
        return False
    pos += 1

    # Reason phrase: any OCTET except CTLs (0-31, 127) but including LWS (spaces, HT)
    # End at CRLF (0x0D 0x0A)
    reason_start = pos
    while pos < len(response):
        if response[pos] == 0x0D and pos + 1 < len(response) and response[pos+1] == 0x0A:
            break
        # Check for CTLs (except space and HT which are LWS)
        if response[pos] < 32 and response[pos] not in (0x09,):  # HT is allowed
            # But 0x09 is allowed as LWS; 0x0A and 0x0D are handled separately
            if response[pos] == 0x0A:
                # Bare LF not allowed before CRLF sequence
                return False
            # Other CTLs (0x00-0x08, 0x0B-0x0C, 0x0E-0x1F) are not allowed
            # 0x0D is handled in the break condition
            if response[pos] != 0x0D:  # 0x0D will be handled in break
                # Actually 0x0D alone is not allowed, but break will catch it
                return False
        if response[pos] == 0x7F:  # DEL
            return False
        pos += 1
    else:
        # No CRLF found
        return False
    # Now at CRLF
    reason_phrase = response[reason_start:pos]
    # Check reason phrase: no CTLs except LWS
    for b in reason_phrase:
        if b < 32 and b not in (0x09, 0x20):  # HT and space are LWS
            return False
        if b == 0x7F:
            return False
    # Consume CRLF
    if pos + 1 >= len(response) or response[pos] != 0x0D or response[pos+1] != 0x0A:
        return False
    pos += 2  # skip CRLF

    # Now parse header section: zero or more header fields, each ending with CRLF, then empty line (CRLF)
    # We'll parse until we find double CRLF (empty line)
    header_end = None
    search_pos = pos
    while search_pos < len(response):
        # Look for CRLF
        if search_pos + 1 < len(response) and response[search_pos] == 0x0D and response[search_pos+1] == 0x0A:
            # Found CRLF
            if search_pos == pos:
                # Empty line, header section ends
                header_end = search_pos
                break
            # Otherwise, we have a header field; need to validate basic syntax
            # But we don't enforce full OWS grammar; just check no CRLF inside field values
            # Actually, we need to ensure no stray CRLF in field value
            # For simplicity, we'll just allow any bytes except embedded CRLF
            # However, we must ensure that the field line doesn't contain CRLF before the termination
            # We'll treat the field as the line from pos to search_pos
            field_line = response[pos:search_pos]
            # Basic check: field line must contain ':'
            if b':' not in field_line:
                return False
            # Check no CR or LF in field line (should be fine since we search for CRLF)
            # Move past this line
            pos = search_pos + 2
            search_pos = pos
            continue
        search_pos += 1
    else:
        # No double CRLF found
        return False
    # Now at empty line: consume the CRLF
    if header_end is not None:
        pos = header_end + 2
    else:
        # Should not happen
        return False

    # After header section, optional body remains
    # No further constraints on body; accept any remaining bytes
    # No trailing data after body? Actually, whole message consumption: body is optional, so any remaining bytes are the body
    # We accept any trailing bytes as body (no rule forbids it)
    # But contract says "reject ... unexplained trailing data". However, body is defined as optional, so trailing data is body.
    # So we accept.
    return True