import hashlib
import re
from typing import List, Tuple, Optional

def packet_observer(response: bytes) -> str:
    if not isinstance(response, bytes):
        response = b""
    
    try:
        # Try to parse as HTTP/1.x response
        # Split into status line and rest
        header_end = response.find(b"\r\n\r\n")
        if header_end == -1:
            # No complete headers found, hash original
            return hashlib.sha256(response).hexdigest()
        
        status_line_end = response.find(b"\r\n")
        if status_line_end == -1 or status_line_end > header_end:
            return hashlib.sha256(response).hexdigest()
        
        status_line = response[:status_line_end]
        headers_section = response[status_line_end+2:header_end]
        body = response[header_end+4:]
        
        # Parse status line: HTTP/1.1 200 OK
        parts = status_line.split(b" ", 2)
        if len(parts) < 2:
            return hashlib.sha256(response).hexdigest()
        
        version_part = parts[0]  # e.g., b"HTTP/1.1"
        status_code_part = parts[1]  # e.g., b"200"
        reason_part = parts[2] if len(parts) > 2 else b""
        
        # Validate version format: HTTP/x.y
        version_match = re.match(br'^HTTP/(\d+)\.(\d+)$', version_part)
        if not version_match:
            return hashlib.sha256(response).hexdigest()
        
        # Validate status code: 3 digits
        if not re.match(br'^\d{3}$', status_code_part):
            return hashlib.sha256(response).hexdigest()
        
        # Parse headers
        headers = parse_headers(headers_section)
        if headers is None:
            return hashlib.sha256(response).hexdigest()
        
        # Normalize dynamic fields identified in IR:
        # - Headers that might contain session/trace/auth tokens, generated IDs, timestamps, nonces
        # But we must preserve status/type, framing, lengths, etc.
        # We'll normalize specific header values that are dynamic/behavioral identifiers.
        # Known dynamic headers: Set-Cookie, Authorization, WWW-Authenticate, X-Request-Id, etc.
        # But we must be careful not to strip structure.
        normalized_headers = []
        for name, value in headers:
            name_lower = name.lower()
            if name_lower in (b'authorization', b'www-authenticate', b'proxy-authenticate', b'set-cookie', b'cookie', b'x-request-id', b'x-trace-id', b'x-session-id', b'x-nonce', b'x-id', b'x-transaction-id', b'x-correlation-id', b'x-request-token', b'x-csrf-token', b'x-api-key', b'if-modified-since', b'if-unmodified-since', b'if-none-match', b'if-match', b'etag', b'last-modified', b'date', b'expires', b'age') or name_lower.startswith(b'x-'):
                # Normalize value to preserve length and presence but mask dynamic content
                # Use a stable marker: X' followed by length in hex
                normalized_value = b'X' + str(len(value)).encode() + b'X'
                normalized_headers.append((name, normalized_value))
            else:
                normalized_headers.append((name, value))
        
        # Reconstruct headers section
        new_headers_section = b"\r\n".join(
            name + b": " + value for name, value in normalized_headers
        ) + b"\r\n"
        
        # Reconstruct full response
        new_response = version_part + b" " + status_code_part + b" " + reason_part + b"\r\n" + new_headers_section + b"\r\n" + body
        
        return hashlib.sha256(new_response).hexdigest()
    
    except Exception:
        # If any parsing error, hash original
        return hashlib.sha256(response).hexdigest()


def parse_headers(section: bytes) -> Optional[List[Tuple[bytes, bytes]]]:
    """Parse HTTP headers. Returns list of (name, value) tuples or None on parse error."""
    if not section:
        return []
    
    lines = section.split(b"\r\n")
    headers = []
    for line in lines:
        if not line:
            continue
        # Header line: name: value
        colon_pos = line.find(b":")
        if colon_pos == -1 or colon_pos == 0:
            # Invalid header line (no colon or empty name)
            return None
        name = line[:colon_pos]
        # Allow optional whitespace after colon
        value = line[colon_pos+1:].lstrip(b" \t")
        # Check that name contains only valid characters (printable ASCII, no spaces)
        if not re.match(br'^[a-zA-Z0-9!#$%&\'*+\-.^_`|~]+$', name):
            return None
        headers.append((name, value))
    return headers