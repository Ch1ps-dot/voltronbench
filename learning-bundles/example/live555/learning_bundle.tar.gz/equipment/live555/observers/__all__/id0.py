import hashlib
import re

def packet_observer(response: bytes) -> str:
    if not isinstance(response, bytes):
        return hashlib.sha256(b"").hexdigest()
    
    # Attempt to parse the status line
    # Pattern: RTSP-Version SP Status-Code SP Reason-Phrase CRLF
    # Status-Code is 3 digits, Reason-Phrase any text up to CRLF
    header_end = response.find(b"\r\n\r\n")
    if header_end == -1:
        # No headers delimiter found, just hash original
        return hashlib.sha256(response).hexdigest()
    
    status_line_end = response.find(b"\r\n")
    if status_line_end == -1 or status_line_end > header_end:
        # malformed: no status line within headers
        return hashlib.sha256(response).hexdigest()
    
    status_line = response[:status_line_end]
    # Split status line into parts by spaces
    parts = status_line.split(b" ")
    if len(parts) < 3:
        # not enough parts, hash original
        return hashlib.sha256(response).hexdigest()
    
    # parts[0] = RTSPVersion, parts[1] = StatusCode, parts[2] = ReasonPhrase (may contain spaces)
    version = parts[0]
    status_code = parts[1]
    reason_phrase = b" ".join(parts[2:])
    
    # Validate status code is 3 digits (substitute if not)
    if not re.match(b'^[0-9]{3}$', status_code):
        # abnormal status code, hash original
        return hashlib.sha256(response).hexdigest()
    
    # Normalize version: keep as is (static protocol version)
    # Normalize status code: keep as is (semantic, not dynamic)
    # Normalize reason phrase: keep as is (semantic, associated with status code)
    
    # For __all__ response type, we treat all fields as static except maybe ones not identified.
    # No dynamic fields identified in primary fields or IR table note except possibly timestamps, IDs, etc.
    # But the IR table does not list any dynamic fields; the only variable fields are Version, StatusCode, ReasonPhrase, Headers, MessageBody.
    # Headers may contain dynamic values like CSeq, Session, etc. We need to normalize those.
    # We'll parse headers and normalize known dynamic fields.
    
    headers_raw = response[status_line_end+2:header_end]  # after status line CRLF, before final CRLFCRLF
    # Now split headers by CRLF
    header_lines = headers_raw.split(b"\r\n")
    normalized_headers = []
    for line in header_lines:
        if not line:
            continue
        # Split into name and value at first colon
        colon_pos = line.find(b":")
        if colon_pos == -1:
            normalized_headers.append(line)
            continue
        name = line[:colon_pos].strip().lower()
        value = line[colon_pos+1:].strip()
        # Normalize dynamic fields:
        # CSeq: sequence number, should be preserved (semantic, ordering), but we treat as static? Actually it's a counter, but it's not generated randomly; it's a request-response correlation. However, contract says "normalize only IR-identified dynamic, non-behavioral values". CSeq is not identified as dynamic in the IR table. The IR table does not list it as dynamic. So we keep it.
        # Session: identifier, could be dynamic. But not listed. However, per typical RTSP, Session is a server-generated token. We'll treat it as dynamic if present, but IR table doesn't specify. We'll be conservative: only normalize fields that are explicitly dynamic in the context. Since no field is identified as dynamic, we keep all headers as-is.
        # Therefore, we keep all headers unchanged.
        normalized_headers.append(line)
    
    # Rebuild headers part with CRLF between lines
    normalized_headers_raw = b"\r\n".join(normalized_headers)
    
    # Rebuild the response from status line, normalized headers, and body
    # status line is unchanged (version, status code, reason phrase preserved)
    # Then CRLF (already in original)
    # Then normalized headers
    # Then CRLF (the delimiter between headers and body)
    # Then body as is
    body = response[header_end+4:]  # after the CRLFCRLF
    
    # Check if body has dynamic content? Not identified. Keep as is.
    # No dynamic normalization needed per IR table.
    # However, we must ensure that we did not change any static parts.
    # Since we kept everything as is, the normalized bytes are the same as original.
    # But we need to output hash of normalized bytes.
    # We'll rebuild the response exactly as original to avoid any unintended changes.
    # Actually, we didn't change anything, so we can just hash the original.
    # But contract says normalize only dynamic fields. Since none identified, we hash original.
    return hashlib.sha256(response).hexdigest()