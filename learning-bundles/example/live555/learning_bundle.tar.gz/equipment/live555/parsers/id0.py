def packet_parser(response: bytes) -> bytes:
    # RTSP response format: RTSP-Version SP Status-Code SP Reason-Phrase CRLF
    if not response:
        return b""
    try:
        # Split on first space to get version and status
        # The status code is the second token
        # First find the first space after version
        space_idx = response.find(b" ")
        if space_idx == -1:
            return b""
        # After version, skip spaces, then parse status code
        rest = response[space_idx+1:]
        # Status code is three digits immediately after space(s)
        # But there might be leading spaces? According to RFC, exactly one space.
        # However, robustly skip any leading spaces.
        rest = rest.lstrip(b" ")
        # Status code is three digits
        if len(rest) < 3:
            return b""
        potential = rest[:3]
        # Check if it's digits
        if not potential.isdigit():
            return b""
        # Validate it's a known status code from the list
        # But we only return canonical value, not validation
        # Actually we need to ensure it's valid? The task says use RESPONSE_FIELDS_JSON, but we can just return it.
        # The contract says "Return its canonical, stable, protocol-defined value" - we can just return the three digits.
        # But we must ensure it's exactly the status code field.
        # The position is First element of the response line after RTSP-Version.
        # So we return the three-digit code.
        return potential
    except Exception:
        return b""