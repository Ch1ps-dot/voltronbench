def generate() -> bytes:
    # Vary the request URI to target a different stream (mp3AudioTest) to explore new state transitions
    # Keep a valid CSeq value (1) but vary the Range value to a different format (clock) to exercise unobserved paths
    return (
        b"PLAY_NOTIFY rtsp://127.0.0.1:8554/mp3AudioTest RTSP/2.0\r\n"
        b"Date: Mon, 01 Jan 2024 00:00:00 GMT\r\n"
        b"CSeq: 1\r\n"
        b"Notify-Reason: scale-change\r\n"
        b"Session: 000022B8\r\n"
        b"Media-Properties: Time-Progressing, Scales\r\n"
        b"Media-Range: clock=20240101T000000Z-20240101T013721Z\r\n"
        b"Range: npt=00:01:00-\r\n"
        b"Scale: 0.5\r\n"
        b"RTP-Info: url=rtsp://127.0.0.1:8554/mp3AudioTest;ssrc=1234ABCD;seq=12345;rtptime=5400000\r\n"
        b"\r\n"
    )