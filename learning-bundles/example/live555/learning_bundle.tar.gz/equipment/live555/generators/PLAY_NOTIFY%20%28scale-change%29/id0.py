def generate() -> bytes:
    return (
        b"PLAY_NOTIFY rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest RTSP/2.0\r\n"
        b"Date: Mon, 01 Jan 2024 00:00:00 GMT\r\n"
        b"CSeq: 1\r\n"
        b"Notify-Reason: scale-change\r\n"
        b"Session: 000022B8\r\n"
        b"Media-Properties: Time-Progressing, Scales\r\n"
        b"Media-Range: npt=00:00:00-01:37:21.394\r\n"
        b"Range: npt=00:01:00-\r\n"
        b"Scale: 2.0\r\n"
        b"RTP-Info: url=rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest;ssrc=1234ABCD;seq=12345;rtptime=5400000\r\n"
        b"\r\n"
    )