def generate() -> bytes:
    # Build the REDIRECT request line
    method = b"REDIRECT"
    space1 = b" "
    # Use the first stream URL from SUT context as Request-URI
    request_uri = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest"
    space2 = b" "
    version = b"RTSP/2.0"
    crlf = b"\r\n"
    request_line = method + space1 + request_uri + space2 + version + crlf

    # CSeq header: mandatory, choose a valid sequence number (e.g., 1)
    cseq = b"CSeq: 1\r\n"

    # Location header: mandatory, points to alternative server (use same stream on different port)
    location = b"Location: rtsp://127.0.0.1:8555/mpeg1or2AudioVideoTest\r\n"

    # Terminate-Reason header: mandatory, choose a reason (e.g., Server-Admin with no optional params)
    terminate_reason = b"Terminate-Reason: Server-Admin\r\n"

    # Optional headers: include Session header (from SUT context) and Date for state exploration
    session = b"Session: 000022B8\r\n"
    # Date header with a valid HTTP-date (RFC 5322) – use current as a fixed valid value
    date = b"Date: Mon, 01 Jan 2024 12:00:00 GMT\r\n"

    # End of headers (empty line)
    end_of_headers = b"\r\n"

    # Message body: not present for REDIRECT (no Content-Type/Content-Length headers)
    # Combine all parts
    message = request_line + cseq + location + terminate_reason + session + date + end_of_headers
    return message