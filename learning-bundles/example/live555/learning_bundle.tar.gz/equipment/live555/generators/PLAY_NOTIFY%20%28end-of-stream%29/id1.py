def generate() -> bytes:
    # Build the PLAY_NOTIFY (end-of-stream) request per RTSP/2.0 spec
    # Fields in IR order, using provided session and URL context

    method = b"PLAY_NOTIFY"
    sp1 = b" "
    request_uri = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest"  # valid stream URL
    sp2 = b" "
    rtsp_version = b"RTSP/2.0"
    crlf1 = b"\r\n"
    notify_reason = b"Notify-Reason: end-of-stream"
    crlf2 = b"\r\n"
    # Request-Status: cseq=<1*9DIGIT> status=<Status-Code> reason="<Reason-Phrase>"
    cseq_val = b"853"  # valid arbitrary CSeq within range
    status_code = b"200"
    reason_phrase = b"OK"
    request_status = b"cseq=" + cseq_val + b" status=" + status_code + b' reason="' + reason_phrase + b'"'
    crlf3 = b"\r\n"
    # Range: npt=<end-time> - use a valid end time (e.g., 10.5)
    range_npt = b"npt=10.5"
    range_header = b"Range: " + range_npt
    crlf4 = b"\r\n"
    # RTP-Info: url="<stream-uri>" ssrc=<ssrc>:seq=<last-seq>;rtptime=<last-rtptime>
    rtp_url = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest/track1"
    ssrc = b"0x12345678"
    last_seq = b"12345"
    last_rtptime = b"987654321"
    rtp_info = b'RTP-Info: url="' + rtp_url + b'" ssrc=' + ssrc + b':seq=' + last_seq + b';rtptime=' + last_rtptime
    crlf5 = b"\r\n"
    # Scale: optional - include with value 1.0 (default) since not 1? Actually Scale: 1.0 is common and valid
    scale_header = b"Scale: 1.0"
    crlf6 = b"\r\n"
    # Session: mandatory
    session_id = b"000022B8"  # provided client session ID
    session_header = b"Session: " + session_id
    crlf7 = b"\r\n"
    # CSeq: mandatory
    cseq_header = b"CSeq: " + cseq_val
    crlf8 = b"\r\n"
    # Date: recommended
    # Use a fixed valid RTSP date (RFC 5322 format)
    date_value = b"Thu, 01 Jan 2024 12:00:00 GMT"
    date_header = b"Date: " + date_value
    crlf9 = b"\r\n"
    # Other-Headers: include a Via header to vary the request
    other_headers = b"Via: RTSP/2.0 127.0.0.1:8554"
    crlf10 = b"\r\n"
    # Empty line (end of headers, no body)
    empty_line = b"\r\n"

    # Assemble all parts in order
    request = (
        method + sp1 + request_uri + sp2 + rtsp_version + crlf1 +
        notify_reason + crlf2 +
        request_status + crlf3 +
        range_header + crlf4 +
        rtp_info + crlf5 +
        scale_header + crlf6 +
        session_header + crlf7 +
        cseq_header + crlf8 +
        date_header + crlf9 +
        other_headers + crlf10 +
        empty_line
    )
    return request