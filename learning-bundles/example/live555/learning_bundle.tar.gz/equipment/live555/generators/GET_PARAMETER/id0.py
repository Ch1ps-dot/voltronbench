def generate() -> bytes:
    method = b"GET_PARAMETER"
    request_uri = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest"
    version = b"RTSP/2.0"
    crlf = b"\r\n"
    headers = b"CSeq: 1\r\nSession: 000022B8\r\n"
    return method + b" " + request_uri + b" " + version + crlf + headers + crlf