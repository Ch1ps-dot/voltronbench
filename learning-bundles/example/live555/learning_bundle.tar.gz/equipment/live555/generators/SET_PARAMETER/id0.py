def generate() -> bytes:
    # Build the request line: SET_PARAMETER SP Request-URI SP RTSP-Version CRLF
    # Use the first stream URL from SUT context for a valid request
    request_uri = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest"
    method = b"SET_PARAMETER"
    rtsp_version = b"RTSP/2.0"
    request_line = method + b" " + request_uri + b" " + rtsp_version + b"\r\n"
    
    # CSeq header: mandatory, choose a valid sequence number (e.g., 1)
    cseq_header = b"CSeq: 1\r\n"
    
    # Session header: required for SET_PARAMETER per SUT context (session id provided)
    session_header = b"Session: 000022B8\r\n"
    
    # Content-Type header: typical for SET_PARAMETER (text/parameters)
    content_type = b"Content-Type: text/parameters\r\n"
    
    # Content-Length header: must match body length
    # Body example: simple parameter setting
    body = b"parameter1=value1\r\n"
    content_length = b"Content-Length: " + str(len(body)).encode() + b"\r\n"
    
    # Optional User-Agent (common)
    user_agent = b"User-Agent: RTSP_Fuzzer/1.0\r\n"
    
    # Header terminator (empty line)
    header_terminator = b"\r\n"
    
    # Assemble all parts in order: request line, mandatory headers, optional headers, terminator, body
    # Order per IR: method line, CSeq, then optional headers, then terminator, body
    message = request_line + cseq_header + session_header + content_type + content_length + user_agent + header_terminator + body
    return message