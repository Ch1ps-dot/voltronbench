_cseq_counter = 0

def generate() -> bytes:
    global _cseq_counter
    _cseq_counter = (_cseq_counter % 999999999) + 1

    request_uri = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest"
    method = b"SET_PARAMETER"
    rtsp_version = b"RTSP/2.0"
    request_line = method + b" " + request_uri + b" " + rtsp_version + b"\r\n"

    cseq_header = b"CSeq: " + str(_cseq_counter).encode() + b"\r\n"

    session_header = b"Session: 000022B8\r\n"
    content_type = b"Content-Type: text/parameters\r\n"

    body = b"parameter1: value1\r\n"
    content_length = b"Content-Length: " + str(len(body)).encode() + b"\r\n"

    user_agent = b"User-Agent: RTSP_Fuzzer/1.0\r\n"

    header_terminator = b"\r\n"

    message = request_line + cseq_header + session_header + content_type + content_length + user_agent + header_terminator + body
    return message
    return message