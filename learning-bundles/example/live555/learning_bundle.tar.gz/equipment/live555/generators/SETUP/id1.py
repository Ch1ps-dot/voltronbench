import struct

def generate() -> bytes:
    # Build the request line with constants
    request_line = b"SETUP rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest RTSP/2.0\r\n"
    
    # Build headers
    # Mandatory: CSeq, Accept-Ranges, Transport
    # Use a valid CSeq (e.g., 1)
    cseq = b"CSeq: 1\r\n"
    # Accept-Ranges: typical for RTSP, e.g., "npt"
    accept_ranges = b"Accept-Ranges: npt\r\n"
    # Transport: must include client_port, usually RTP/AVP; use a valid port range
    transport = b"Transport: RTP/AVP;unicast;client_port=3456-3457\r\n"
    # Optional: Session (from SUT context), User-Agent, etc.
    session = b"Session: 000022B8\r\n"
    # Optional: Require (if needed by server, but not required)
    # Empty line after headers
    empty_line = b"\r\n"
    
    # No message body for SETUP (unless SET_PARAMETER, but not here)
    message = request_line + cseq + accept_ranges + transport + session + empty_line
    return message
    return message