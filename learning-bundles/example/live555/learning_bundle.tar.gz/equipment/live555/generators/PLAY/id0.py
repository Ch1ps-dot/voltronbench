def generate() -> bytes:
    session_id = b"000022B8"
    return (
        b"PLAY rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest RTSP/2.0\r\n"
        + b"CSeq: 1\r\n"
        + b"Session: " + session_id + b"\r\n"
        + b"\r\n"
    )