def generate() -> bytes:
    # Build the PAUSE request line
    method = b"PAUSE"
    space1 = b" "
    # Use the first stream URL from the SUT context
    request_uri = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest"
    space2 = b" "
    version = b"RTSP/2.0"
    crlf1 = b"\r\n"

    # Mandatory CSeq header with a valid sequence number (1)
    cseq = b"CSeq: 1\r\n"

    # Session header with the provided session id
    session = b"Session: 000022B8\r\n"

    # Optional headers: include a User-Agent for variety
    optional = b"User-Agent: Fuzzer/1.0\r\n"

    # Empty line marking end of headers
    empty_line = b"\r\n"

    # Concatenate all parts in IR order
    request = (
        method + space1 + request_uri + space2 + version + crlf1 +
        cseq +
        session +
        optional +
        empty_line
    )
    return request