def generate() -> bytes:
    # Build the request line: Method SP Request-URI SP RTSP-Version CRLF
    method = b"PLAY_NOTIFY"
    sp1 = b" "  # 0x20
    # Choose a valid RTSP URI from SUT context; use the first stream for simplicity
    request_uri = b"rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest"
    sp2 = b" "
    rtsp_version = b"RTSP/2.0"
    crlf1 = b"\r\n"

    request_line = method + sp1 + request_uri + sp2 + rtsp_version + crlf1

    # Mandatory header: CSeq
    # Use a boundary valid value: 1
    cseq_name = b"CSeq: "
    cseq_value = b"1"  # 1*9DIGIT, valid
    crlf2 = b"\r\n"
    cseq_header = cseq_name + cseq_value + crlf2

    # Mandatory header: Session
    # Use provided session ID from SUT context: 000022B8
    session_name = b"Session: "
    session_id = b"000022B8"
    crlf3 = b"\r\n"
    session_header = session_name + session_id + crlf3

    # Mandatory header: Notify-Reason
    notify_reason_name = b"Notify-Reason: "
    # Fixed value from type rule: media-properties-update
    notify_reason_value = b"media-properties-update"
    crlf4 = b"\r\n"
    notify_reason_header = notify_reason_name + notify_reason_value + crlf4

    # Mandatory header: Range
    # Choose a valid npt-range: the beginning of the stream (0-)
    range_name = b"Range: "
    # npt-range = "npt" "=" npt-sec [ "-" [ npt-sec ] ]
    # Valid: npt=0-
    range_value = b"npt=0-"
    crlf5 = b"\r\n"
    range_header = range_name + range_value + crlf5

    # Optional headers: none added for minimal valid request
    # End of headers: a final CRLF (empty line)
    end_headers = b"\r\n"

    # Assemble the complete request
    request = (
        request_line
        + cseq_header
        + session_header
        + notify_reason_header
        + range_header
        + end_headers
    )

    return request