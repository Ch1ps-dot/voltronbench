def generate() -> bytes:
    # Build the request line: "OPTIONS * RTSP/2.0\r\n"
    request_line = b"OPTIONS * RTSP/2.0\r\n"
    
    # Build headers: CSeq (mandatory) with a random like value for exploration, 
    # User-Agent, and then the ending empty line.
    # Use a valid CSeq number (e.g., 1)
    cseq_header = b"CSeq: 1\r\n"
    # Optional but common for state exploration: User-Agent
    user_agent_header = b"User-Agent: RTSP-fuzzer/1.0\r\n"
    # End of headers: empty line (CRLF)
    empty_line = b"\r\n"
    
    # Combine all parts
    message = request_line + cseq_header + user_agent_header + empty_line
    return message