import struct; STREAMS=(b'rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest', b'rtsp://127.0.0.1:8554/mp3AudioTest', b'rtsp://127.0.0.1:8554/wavAudioTest', b'rtsp://127.0.0.1:8554/aacAudioTest', b'rtsp://127.0.0.1:8554/ac3AudioTest', b'rtsp://127.0.0.1:8554/matroskaFileTest', b'rtsp://127.0.0.1:8554/webmFileTest'); _NEXT_STREAM=0; _CSEQ=1

def generate() -> bytes:
    # Build the request line: DESCRIBE rtsp://127.0.0.1:8554/mpeg1or2AudioVideoTest RTSP/2.0 CRLF
    global _NEXT_STREAM, _CSEQ; method = b'DESCRIBE'
    space1 = b" "
    request_uri = STREAMS[_NEXT_STREAM]; _NEXT_STREAM = (_NEXT_STREAM + 1) % len(STREAMS)
    space2 = b" "
    version = b"RTSP/2.0"
    crlf = b"\r\n"
    
    # Header block: minimal required headers (CSeq, Session) and empty line terminator
    # CSeq must be present; choose a valid value (e.g., 1)
    cseq_line = b'CSeq: ' + str(_CSEQ).encode('ascii') + b'\r\n'; _CSEQ += 1
    # Session header required; use provided session id 000022B8
    session_line = b"Session: 000022B8\r\n"
    # No Accept header needed for basic DESCRIBE, but include a common one for exploration
    accept_line = b"Accept: application/sdp\r\n"
    # Empty line to terminate headers
    empty_line = b"\r\n"
    
    header_block = cseq_line + session_line + accept_line + empty_line
    
    # Assemble full request
    request = method + space1 + request_uri + space2 + version + crlf + header_block
    return request