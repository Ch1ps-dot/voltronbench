def packet_checker(response: bytes) -> bool:
    # Validate input type
    if not isinstance(response, bytes):
        return False
    
    data = response
    # Minimum length: RTSP/2.0 SP 3DIGIT SP CRLF = 12 bytes
    if len(data) < 12:
        return False
    
    # Parse RTSPVersion: up to 19 digits + prefix, but must end with space
    # Search for first space after "RTSP/..." 
    if not data.startswith(b'RTSP/'):
        return False
    # Find the first space after the version string
    space1_idx = data.find(b' ', 0)
    if space1_idx == -1:
        return False
    # Version must be at least "RTSP/1.0" (8 chars) but no more than "RTSP/" + 19 digits + 1 = 24
    # Actually, we need to ensure no space in version itself (it's a single token)
    # And version must be reasonable: RTSP/1.0 or RTSP/2.0 etc.
    version_bytes = data[:space1_idx]
    # Simple check: must be RTSP/ followed by digits and dots
    version_str = version_bytes.decode('ascii', errors='replace')
    if not version_str.startswith('RTSP/'):
        return False
    # Check that version number part is valid: at least one digit, only digits and dots
    version_num = version_str[5:]
    if not version_num:
        return False
    for ch in version_num:
        if ch not in '0123456789.':
            return False
    # Ensure version length is within plausible range (up to 19 digits + 5 for "RTSP/")
    if len(version_bytes) > 24:
        return False
    
    # After version, must be space (already verified at space1_idx)
    # Check that space is exactly 0x20
    if data[space1_idx] != 0x20:
        return False
    
    # Now parse StatusCode: exactly 3 digits after space
    if space1_idx + 4 > len(data):
        return False
    status_bytes = data[space1_idx+1:space1_idx+4]
    if not (status_bytes[0] in range(0x30, 0x3A) and
            status_bytes[1] in range(0x30, 0x3A) and
            status_bytes[2] in range(0x30, 0x3A)):
        return False
    status_code = int(status_bytes)
    # Validate against allowed values
    allowed_status = {100, 200, 301, 302, 303, 304, 305, 400, 401, 402, 403, 404, 405, 406, 407, 408, 410, 412, 413, 414, 415, 451, 452, 453, 454, 455, 456, 457, 458, 459, 460, 461, 462, 463, 464, 465, 466, 470, 471, 472, 500, 501, 502, 503, 504, 505, 551, 553}
    if status_code not in allowed_status:
        return False
    
    # After status code must be space
    space2_idx = space1_idx + 4
    if space2_idx >= len(data) or data[space2_idx] != 0x20:
        return False
    
    # Find ReasonPhrase end: CRLF
    # After space2, find the next CRLF (0x0D0A)
    crlf1_idx = data.find(b'\r\n', space2_idx + 1)
    if crlf1_idx == -1:
        return False
    # ReasonPhrase is between space2 and CRLF (not including space)
    # It must be valid UTF-8 or HT/SP (but we just accept any bytes for now, as per spec)
    # Check that there is at least one character? Actually ReasonPhrase can be empty? Usually it's present.
    # But spec says "TEXT-UTF8char / HT / SP", so it's not empty. But RFC 2326 allows empty? Let's allow empty for robustness.
    # We'll just require that it's not just spaces? No, we'll accept any bytes.
    
    # After CRLF1, we have Headers... until CRLF2
    # Headers field: variable length, then CRLF2 (empty line), then optional MessageBody
    # We need to parse headers to find the end of headers (empty line: CRLFCRLF)
    # But note: Headers are raw octets, and we need to find the double CRLF that separates headers from body
    
    # Find the position after first CRLF
    after_crlf1 = crlf1_idx + 2
    # Now find the double CRLF (CRLF + CRLF) that marks end of headers
    double_crlf = data.find(b'\r\n\r\n', after_crlf1)
    if double_crlf == -1:
        # No double CRLF means no headers? Actually must have headers? But spec says Headers can be present?
        # According to IR table, Headers field is "1*OCTET" meaning at least one octet.
        # But we also have CRLF2 as empty line separating headers from body.
        # This means headers must be present and then CRLF2.
        # However, if there are no headers, the double CRLF would be the CRLF2? 
        # But the spec says Headers is 1*OCTET. So there must be at least one header.
        # Nonetheless, we'll be lenient: if no headers, we still need the empty line.
        # Let's check if the immediate next bytes are CRLF again (i.e., empty line after Status-Line)
        # That would be: after crlf1, we have directly another CRLF, meaning no headers
        if len(data) >= after_crlf1 + 2 and data[after_crlf1:after_crlf1+2] == b'\r\n':
            # No headers, empty line
            headers_end = after_crlf1
            body_start = after_crlf1 + 2
        else:
            return False
    else:
        # Headers exist. Check that there is at least one header (i.e., something between crlf1 and double_crlf)
        if double_crlf == after_crlf1:
            # No headers, but double_crlf found at same position: that's actually CRLF2 directly after Status-Line CRLF
            # But we already parsed that case? Actually if double_crlf == after_crlf1, then data[after_crlf1:after_crlf1+2] must be CRLF, and then another CRLF?
            # Actually if double_crlf == after_crlf1, then data[after_crlf1:after_crlf1+4] should be \r\n\r\n, meaning first CRLF ends the Status-Line, second CRLF is empty line.
            # That means no headers. So it's okay.
            headers_end = double_crlf
            body_start = double_crlf + 2
        else:
            # There is at least one header
            headers_end = double_crlf
            body_start = double_crlf + 2
            # Headers are between after_crlf1 and double_crlf
            # We should check that headers are valid (simple checks: contain colon, no stray CRLF without following CRLF? but we'll skip for now)
    
    # Now we have body starting at body_start
    message_body = data[body_start:]
    
    # Check for any trailing data after body? If there is no Content-Length header, body length should be zero.
    # But we need to determine if Content-Length header is present.
    # Parse headers to find Content-Length
    content_length = None
    if headers_end != after_crlf1:  # There are headers
        headers_section = data[after_crlf1:headers_end]
        # Split headers by CRLF
        header_lines = headers_section.split(b'\r\n')
        for line in header_lines:
            if not line:
                continue
            # Check for Content-Length
            if line.lower().startswith(b'content-length:'):
                try:
                    # Value is after colon and optional space
                    colon_idx = line.find(b':')
                    if colon_idx != -1:
                        value_str = line[colon_idx+1:].strip()
                        content_length = int(value_str)
                        if content_length < 0:
                            return False
                except (ValueError, IndexError):
                    return False
                break
    
    if content_length is not None:
        # Body must match content_length
        if len(message_body) != content_length:
            return False
    else:
        # No Content-Length: body must be empty
        if len(message_body) != 0:
            # Check if there is a Session header that might indicate body? No, body length is determined by Content-Length.
            # If no Content-Length, body length is zero.
            return False
    
    # Check that we consumed all data exactly
    # body_start + len(message_body) should equal len(data)
    if body_start + len(message_body) != len(data):
        return False
    
    # All checks passed
    return True