import hashlib

def packet_observer(response: bytes) -> str:
    """
    Normalize HTTP response bytes by replacing dynamic values (such as
    ReasonPhrase, certain header values) with stable markers that preserve
    presence and length. Then return lowercase SHA-256 hex.
    """
    # If input is not bytes, treat as b""
    if not isinstance(response, bytes):
        response = b""

    # Attempt to parse the HTTP response status line.
    # We need to handle both HTTP/1.x and HTTP/2 (but minimal here).
    # For HTTP/2, the status is in pseudo-header, but we don't parse that.
    # For HTTP/1.x: "HTTP/1.1 200 OK\r\n..."
    # We'll try to find the first CRLF (or LF) to isolate the status line.
    # But we must be careful about malformed responses.

    # Find the end of the status line (first CRLF or LF)
    crlf_pos = response.find(b"\r\n")
    lf_pos = response.find(b"\n")
    # Determine which is the first line terminator
    # We'll use the first occurrence of either; if both, use the earlier.
    line_end = None
    if crlf_pos != -1:
        line_end = crlf_pos
    if lf_pos != -1:
        if line_end is None or lf_pos < line_end:
            line_end = lf_pos

    if line_end is None:
        # No line ending found; treat whole response as a single line.
        status_line = response
        rest = b""
    else:
        status_line = response[:line_end]
        # Determine the actual line break length
        if line_end + 1 < len(response) and response[line_end:line_end+2] == b"\r\n":
            rest = response[line_end+2:]
        else:
            # LF only
            rest = response[line_end+1:]

    # Split status line into parts by spaces.
    # Expected: version, status_code, reason_phrase (maybe missing)
    parts = status_line.split(b" ")
    # Initialize normalized line parts
    normalized_parts = []
    # We know the first part should be the protocol version (e.g., HTTP/1.1)
    # But we must preserve it exactly (it's not dynamic).
    # However, we need to identify the status code (3 digits) and the reason phrase.
    # The status code is the second part if it exists and is 3 bytes.
    # We'll rebuild the status line with normalized parts.

    # Actually, we need to be careful: the status line can have multiple spaces in reason phrase.
    # But we can treat the first space-separated part as version, second as status code,
    # and the rest as reason phrase.
    # However, the reason phrase is considered dynamic (free text) and should be normalized.
    # Also, the status code is a primary field, but it's not dynamic; it's preserved.
    # The reason phrase is dynamic per the IR (it's text, can be anything).
    # So we'll replace the reason phrase with a marker that preserves its length (or presence).

    # We'll rebuild the status line with normalized reason phrase.
    # But we must preserve the exact status code, version, and the spaces.
    # Also, there might be no reason phrase (e.g., HTTP/2 status line).
    # For simplicity, we'll treat the entire status line after the version and status code as reason phrase.

    # Let's parse more robustly: version is the first word until space.
    # But we need to handle the case of HTTP/2 where there is no version string.
    # However, the IR field table shows the format specifically for HTTP/1.x.
    # For HTTP/2, the response uses pseudo-headers, but we are not handling that here.
    # We'll assume HTTP/1.x format.

    # We'll use a simple approach: find the first two spaces and split.
    # But reason phrase may contain spaces.
    # Better: version is everything up to the first space.
    # After that, we need to find the status code (3 digits) and then the rest is reason.
    # However, the status code is exactly 3 digits.

    # Let's try to split by space, but we need to handle the case where there are multiple spaces.
    # Since the status code is exactly 3 bytes, we can find it.
    # But that's fragile. Instead, we'll use the following normalization:
    # - Preserve the version and status code as is.
    # - Replace the reason phrase (the remainder after version and status code) with a marker
    #   that has the same length, but consists of a fixed character (e.g., 'X').
    # - Also, we need to normalize dynamic headers. For simplicity, we'll treat header values
    #   that are likely dynamic (e.g., Date, Set-Cookie, Authorization, etc.) with markers.
    #   But we must not strip all headers; we need to preserve structure.
    #   Since the task says "normalize only IR-identified dynamic, non-behavioral values",
    #   and the IR does not specify which headers are dynamic, we might need to rely on common knowledge.
    #   However, the contract says "If parsing is unsafe or no dynamic field is identified, hash the original bytes."
    #   So we can be conservative: only normalize the reason phrase (which is explicitly in the IR as variable text)
    #   and possibly other fields we identify as dynamic (like timestamps in headers).
    #   But we must be careful: the header section is general, and we cannot safely parse all headers.
    #   We'll implement a simple normalization for the reason phrase and maybe some common headers.
    #   To be safe, we'll only normalize the reason phrase, and for headers, we'll leave them as is.
    #   However, the reason phrase is part of the status line, which we already handle.

    # Actually, let's look at the primary fields: status code is primary, but reason phrase is not.
    # The IR field table includes ReasonPhrase as variable length, which is dynamic.
    # So we'll normalize it.

    # We'll rebuild the status line by replacing the ReasonPhrase with a placeholder.
    # But we need to preserve the status code and version.

    # Let's find the version and status code.
    # We'll split by space, but limit to 3 parts: version, status, rest.
    # However, there might be multiple spaces before the status code? No, standard is single space.
    # We'll use first space to separate version, then second space to separate status code, then rest.
    # But we need to handle the case where there is no reason phrase (just version and status).
    # Also, there might be trailing spaces.

    # For simplicity, we'll use a regular expression to extract the three components.
    # But we cannot use re (not built-in? Actually 're' is built-in, but we can use it.
    # However, the contract says "use built-ins", and 're' is a built-in module, but it's not in the default namespace.
    # We can import re? The instruction says "Use built-ins and hashlib.sha256; self-contained; no I/O/...".
    # It's ambiguous. To be safe, we'll avoid re and do manual parsing.

    # Let's implement a manual parser for the status line.
    # We'll assume the format: VERSION SP STATUS_CODE SP REASON_PHRASE CRLF
    # But we already have the status line without the line break.

    # We'll find the first space.
    first_space = status_line.find(b" ")
    if first_space == -1:
        # No space, so no version/status separation; treat as all dynamic? Unlikely; hash original.
        return hashlib.sha256(response).hexdigest()

    version_part = status_line[:first_space]
    rest_after_version = status_line[first_space+1:]

    # Now find the next space (separator to status code)
    second_space = rest_after_version.find(b" ")
    if second_space == -1:
        # No second space: only version and status code (no reason phrase)
        status_code_part = rest_after_version
        reason_part = b""
    else:
        status_code_part = rest_after_version[:second_space]
        reason_part = rest_after_version[second_space+1:]

    # Validate status code is 3 digits (just for safety)
    if len(status_code_part) == 3 and status_code_part.isdigit():
        # Valid status code; preserve it.
        pass
    else:
        # Not a standard status code; maybe it's not a valid HTTP response? Or HTTP/2? Hash original.
        return hashlib.sha256(response).hexdigest()

    # Normalize reason phrase: replace each character with a fixed marker (e.g., 'X')
    # But preserve length. If reason phrase is empty, keep empty.
    normalized_reason = b"X" * len(reason_part) if reason_part else b""

    # Rebuild status line with original version, status code, and normalized reason
    # Ensure single spaces between parts.
    if reason_part:
        # There was a reason phrase, so we need to add space before it
        normalized_status_line = version_part + b" " + status_code_part + b" " + normalized_reason
    else:
        # No reason phrase
        normalized_status_line = version_part + b" " + status_code_part

    # Now we need to handle the rest of the response (headers and body).
    # For headers, we could potentially normalize dynamic values like Date, Set-Cookie, etc.
    # But since the IR does not specify which headers are dynamic, and the task says to normalize
    # only IR-identified dynamic values, we can leave headers as is.
    # However, the ReasonPhrase is the only dynamic field explicitly identified in the IR field table
    # (apart from the body which is arbitrary but structural). The body is not dynamic per se;
    # it's the payload. We should preserve it as is.
    # So we'll keep the rest unchanged.

    # But we also need to consider the headers: they contain field names and values,
    # and some values might be dynamic (like timestamps), but we are not required to normalize them
    # unless they are "IR-identified dynamic". The IR only identifies the ReasonPhrase as variable text.
    # Therefore, we can leave headers and body as is.

    # However, the contract says "Normalize only IR-identified dynamic, non-behavioral values".
    # The IR field table includes "ReasonPhrase" with type "variable" and note "Short textual description".
    # That is the only dynamic non-behavioral field identified. Headers are not listed as individual fields.
    # So we will only normalize the reason phrase.

    # Reconstruct the normalized response.
    # We need to use the original line terminator (CRLF or LF) that we found.
    if line_end is not None:
        # Determine the line terminator from the original response
        # We'll use the same terminator as in the original status line.
        # But we don't have it directly; we can reconstruct using CRLF (standard) or LF.
        # Since we don't know, we'll use CRLF (most common). But to be safe, we can use the original
        # line break sequence from the response. However, we removed the line break.
        # We'll assume standard CRLF for the normalized line.
        # But this could change the length if the original used LF only.
        # The contract says "preserve presence and required length". The line terminator length is part of the framing.
        # So we should preserve the exact line terminator from the original.
        # We stored the line break length indirectly: if we found CRLF, we used 2 bytes; otherwise, LF.
        # Let's reconstruct the line break.
        original_line_break = response[line_end:line_end+2] if response[line_end:line_end+2] == b"\r\n" else response[line_end:line_end+1]
        # But careful: if we used LF, the line_end is the position of LF, so the break is b"\n" (1 byte).
        # If we used CRLF, it's b"\r\n" (2 bytes).
        # We'll use the same.
        line_break = original_line_break
    else:
        line_break = b""

    # If line_end is None, the whole response is the status line, no line break.
    # In that case, we keep it as is.

    # Reconstruct the normalized response
    normalized_response = normalized_status_line + line_break + rest

    # Return the SHA-256 hash of the normalized bytes
    return hashlib.sha256(normalized_response).hexdigest()