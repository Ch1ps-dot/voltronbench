def generate() -> bytes:
    if not hasattr(generate, "_target_index"):
        generate._target_index = 0
    targets = (b"/hello.txt", b"/StarWars3.wav")
    target = targets[generate._target_index % len(targets)]
    generate._target_index += 1
    return b"DELETE " + target + b" HTTP/1.1\r\nHost: 127.0.0.1:8080\r\n\r\n"