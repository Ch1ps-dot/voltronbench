def generate() -> bytes:
    if not hasattr(generate, "_target_index"):
        generate._target_index = 0
    targets = (b"/hello.txt", b"/StarWars3.wav")
    versions = (b"HTTP/1.1", b"HTTP/1.0")
    bodies = (b"", b"payload")
    target = targets[generate._target_index % len(targets)]
    version = versions[(generate._target_index // len(targets)) % len(versions)]
    body = bodies[(generate._target_index // (len(targets) * len(versions))) % len(bodies)]
    generate._target_index += 1
    header = b""
    if body:
        header = b"Content-Length: " + str(len(body)).encode() + b"\r\n"
    return b"DELETE " + target + b" " + version + b"\r\nHost: 127.0.0.1:8080\r\n" + header + b"\r\n" + body