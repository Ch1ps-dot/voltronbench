def generate() -> bytes:
    # Build a valid HTTP POST request to /hello.txt with HTTP/1.1, minimal headers, and a body.
    # Fields in IR order: Method, Space1, RequestTarget, Space2, HTTPVersion, CRLF1,
    #                    HeaderFields, TerminatingCRLF, MessageBody

    # Method: constant "POST" (3 bytes)
    method = b"POST"
    # Space1: constant space (0x20)
    space1 = b" "
    # RequestTarget: choose a valid URI from SUT context (use /hello.txt)
    request_target = b"/hello.txt"
    # Space2: constant space
    space2 = b" "
    # HTTPVersion: typical "HTTP/1.1" (variable, ASCII)
    http_version = b"HTTP/1.1"
    # CRLF1: constant 0x0D0A
    crlf1 = b"\r\n"
    # HeaderFields: include mandatory Host header, and Content-Length for body.
    # Host: matches server IP and port (127.0.0.1:8080)
    host_header = b"Host: 127.0.0.1:8080\r\n"
    # Content-Length computed from body length (body = "Hello, World!" => 13 bytes)
    body = b"Hello, World!"
    content_length = len(body)
    content_length_header = f"Content-Length: {content_length}\r\n".encode("ascii")
    # Add Connection: close to explicitly request that the server close the connection after the response.
    connection_header = b"Connection: close\r\n"
    # Combine headers: Host, Content-Length, and Connection, each ending with CRLF, no trailing blank line yet.
    header_fields = host_header + content_length_header + connection_header
    # TerminatingCRLF: empty line separating headers from body
    terminating_crlf = b"\r\n"
    # MessageBody: the body bytes
    message_body = body

    # Concatenate all fields in order
    request = method + space1 + request_target + space2 + http_version + crlf1 + header_fields + terminating_crlf + message_body
    return request