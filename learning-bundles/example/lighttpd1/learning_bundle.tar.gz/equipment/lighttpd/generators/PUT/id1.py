def generate() -> bytes:
    method = b"PUT"
    sp1 = b" "
    request_target = b"/StarWars3.wav"
    sp2 = b" "
    http_version = b"HTTP/1.1"
    crlf1 = b"\r\n"

    body = b"\x00\x00\x00\x00"
    header_section = (
        b"Host: 127.0.0.1:8080\r\n"
        + b"Content-Type: text/plain\r\n"
        + b"Content-Length: " + str(len(body)).encode("ascii") + b"\r\n"
        + b"\r\n"
    )

    return method + sp1 + request_target + sp2 + http_version + crlf1 + header_section + body