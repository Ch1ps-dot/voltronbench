def generate() -> bytes:
    return (
        b"GET /hello.txt HTTP/1.1\r\n"
        b"Host: 127.0.0.1:8080\r\n"
        b"User-Agent: fuzz\r\n"
        b"Accept: */*\r\n"
        b"\r\n"
    )