def generate() -> bytes:
    return b"OPTIONS /hello.txt HTTP/1.1\r\nHost: 127.0.0.1:8080\r\n\r\n"