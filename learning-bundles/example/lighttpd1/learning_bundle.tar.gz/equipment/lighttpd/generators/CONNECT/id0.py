def generate() -> bytes:
    # Build constant parts: Method, SP, RequestTarget, SP, HTTPVersion, CRLF
    # Method: "CONNECT" (7 bytes)
    method = b"CONNECT"
    sp = b" "
    # RequestTarget: authority-form host:port, use SUT context 127.0.0.1:8080
    request_target = b"127.0.0.1:8080"
    # HTTPVersion: use HTTP/1.1 (8 bytes)
    http_version = b"HTTP/1.1"
    crlf = b"\r\n"
    
    # HeaderSection: must include Host header matching request target, and final CRLF
    # Host header: "Host: 127.0.0.1:8080\r\n"
    host_header = b"Host: 127.0.0.1:8080\r\n"
    # End of header section: empty line (CRLF)
    header_end = crlf
    
    # Assemble request line
    request_line = method + sp + request_target + sp + http_version + crlf
    
    # Full request
    request = request_line + host_header + header_end
    
    return request