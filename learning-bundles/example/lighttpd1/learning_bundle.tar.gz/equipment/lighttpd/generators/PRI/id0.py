def generate() -> bytes:
    return b"".join(
        [
            b"PRI",
            b"\x20",
            b"*",
            b"\x20",
            b"HTTP/2.0",
            b"\r\n",
            b"\r\n",
        ]
    )