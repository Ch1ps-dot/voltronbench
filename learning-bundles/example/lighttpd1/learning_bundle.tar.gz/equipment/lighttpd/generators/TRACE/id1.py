def generate() -> bytes:
    targets = (b"/hello.txt", b"/StarWars3.wav")
    max_forwards_values = (b"0", b"1", b"255", None)
    via_values = (None, b"HTTP/1.1 trace-client")
    index = getattr(generate, "_index", 0)
    generate._index = index + 1
    n = index
    via = via_values[n % len(via_values)]
    n //= len(via_values)
    target = targets[n % len(targets)]
    n //= len(targets)
    max_forwards = max_forwards_values[n % len(max_forwards_values)]
    header_lines = [b"Host: 127.0.0.1:8080\r\n"]
    if max_forwards is not None:
        header_lines.append(b"Max-Forwards: " + max_forwards + b"\r\n")
    if via is not None:
        header_lines.append(b"Via: " + via + b"\r\n")
    return (
        b"TRACE " + target + b" HTTP/1.1\r\n"
        + b"".join(header_lines)
        + b"\r\n"
    )
