def generate() -> bytes:
    targets = (b"/hello.txt", b"/StarWars3.wav")
    max_forwards_values = (b"0", b"1", b"255")
    index = getattr(generate, "_index", 0)
    generate._index = index + 1
    target = targets[index % len(targets)]
    max_forwards = max_forwards_values[index % len(max_forwards_values)]
    return (
        b"TRACE " + target + b" HTTP/1.1\r\n"
        b"Host: 127.0.0.1:8080\r\n"
        b"Max-Forwards: " + max_forwards + b"\r\n\r\n"
    )