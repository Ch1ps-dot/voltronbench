def generate() -> bytes:
    if not hasattr(generate, "_i"):
        generate._i = 0
    target = (b"/hello.txt", b"/StarWars3.wav")[generate._i % 2]
    generate._i += 1

    method = b"HEAD"
    space_after_method = b" "
    space_before_version = b" "
    http_version = b"HTTP/1.1"
    crlf = b"\r\n"
    header_section = b"Host: 127.0.0.1:8080\r\n\r\n"

    return method + space_after_method + target + space_before_version + http_version + crlf + header_section