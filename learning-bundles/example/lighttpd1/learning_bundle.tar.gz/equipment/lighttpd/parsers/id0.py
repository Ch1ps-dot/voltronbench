def packet_parser(response: bytes) -> bytes:
    """
    Extracts the HTTP response status code from a raw HTTP response.

    For HTTP/1.x: extracts the three-digit status code from the first line.
    For HTTP/2: extracts the ':status' pseudo-header value.
    Returns the status code as UTF-8 bytes, or b"" on failure.
    """
    if not isinstance(response, bytes):
        return b""

    # Try HTTP/1.x style: first line has status code
    # Find end of first line
    idx = response.find(b"\r\n")
    if idx != -1:
        first_line = response[:idx]
        # Status line format: HTTP/1.x SP Status-Code SP Reason-Phrase
        # Find the second space; status code is between first and second space
        # Or: HTTP/1.x SP Status-Code
        parts = first_line.split(b" ")
        if len(parts) >= 2:
            # parts[0] is protocol version, parts[1] is status code
            status_code = parts[1]
            # Validate it's a three-digit numeric code
            if len(status_code) == 3 and status_code.isdigit():
                return status_code

    # Try HTTP/2 style: pseudheader :status
    # Look for ":status" followed by any linear whitespace and a value
    # But we need to be careful: the response might be binary HTTP/2
    # For simplicity, we look for it in the raw bytes
    # Since HTTP/2 frames are not easily parsed from raw bytes without
    # proper framing, we assume the response is already decoded to text
    # or we are looking for the pattern in the first few bytes.
    # However, HTTP/2 responses over the wire are binary and not self-delimiting.
    # As per the contract, we only use RESPONSE_FIELDS_JSON to locate/decode.
    # Since the protocol is http, we assume either HTTP/1.x or HTTP/2.
    # For HTTP/2, we can look for the pattern ":status" followed by
    # a colon, then value. But this is tricky because of binary framing.
    # Given the constraints, we'll try a simple heuristic: look for
    # b":status" in the response and then extract the numeric value.
    # This may not be robust for all cases, but it's a best effort.
    # Alternatively, we can try to parse the first bytes as HTTP/2
    # but that's complex. Instead, we'll search for the pattern.
    status_idx = response.find(b":status")
    if status_idx != -1:
        # after ":status" there might be a colon or space, then value
        # HTTP/2 pseudoheaders are written as ":status: 200" or similar
        # But in raw binary, it's part of a header block.
        # Let's try to find the value after the colon.
        colon_pos = response.find(b":", status_idx + 7)  # after ":status"
        if colon_pos != -1:
            # Find the start of the value (skip whitespace)
            value_start = colon_pos + 1
            while value_start < len(response) and response[value_start:value_start+1] in (b" ", b"\t"):
                value_start += 1
            # Find the end of the value (until next whitespace or end of line)
            value_end = value_start
            while value_end < len(response) and response[value_end:value_end+1] not in (b" ", b"\t", b"\r", b"\n"):
                value_end += 1
            if value_end > value_start:
                status_code = response[value_start:value_end]
                # Validate it's a three-digit numeric code
                if len(status_code) == 3 and status_code.isdigit():
                    return status_code

    # Fallback: try to find any three-digit number that looks like a status code
    # in the first line or after ":status"
    # This is a last resort
    # Look for a three-digit number in the first part of the response
    # (first 1024 bytes)
    chunk = response[:1024]
    import re
    # Find all three-digit sequences
    matches = re.findall(rb'\b(1[0-9][0-9]|2[0-9][0-9]|3[0-9][0-9]|4[0-9][0-9]|5[0-9][0-9])\b', chunk)
    if matches:
        # Return the first match (likely the status code)
        return matches[0]

    return b""