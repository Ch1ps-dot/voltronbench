def packet_checker(response: bytes) -> bool:
    """
    Checks if the given bytes represent a valid HTTP/1.x response.
    Returns True if the message is fully conformant, False otherwise.
    """
    if not isinstance(response, bytes):
        return False

    # ---- Helper: parse status line from bytes ----
    # Status line format: "HTTP/1.1 200 OK\r\n" (only major.minor version in 1.x)
    # We will parse the first line up to CRLF.
    # Find the first CRLF (0x0D 0x0A)
    crlf_pos = response.find(b'\r\n')
    if crlf_pos == -1:
        return False  # No CRLF -> cannot have a complete status line
    status_line = response[:crlf_pos]
    # The status line must be at least "HTTP/1.1 200" (13 bytes) + possible reason phrase
    # Minimum: "HTTP/1.1 200" is 11 bytes (because "HTTP/1.1" is 8, space 1, code 3 = 12? Let's count: H T T P / 1 . 1 space 2 0 0 = 12 bytes)
    # Actually "HTTP/1.1" is 8 bytes + space = 9 + 3 = 12, plus possible reason phrase after space.
    # Ensure at least 12 bytes plus nothing else? We'll check later.
    # Check constant prefix "HTTP/"
    if not status_line.startswith(b'HTTP/'):
        return False
    # After "HTTP/" we need major version digit(s), dot, minor version digit(s)
    pos = 5  # after "HTTP/"
    # At least one digit
    if pos >= len(status_line) or not (48 <= status_line[pos] <= 57):
        return False
    while pos < len(status_line) and 48 <= status_line[pos] <= 57:
        pos += 1
    # Expect dot
    if pos >= len(status_line) or status_line[pos] != 0x2E:
        return False
    pos += 1  # skip dot
    # At least one digit for minor version
    if pos >= len(status_line) or not (48 <= status_line[pos] <= 57):
        return False
    while pos < len(status_line) and 48 <= status_line[pos] <= 57:
        pos += 1
    # Expect space (0x20)
    if pos >= len(status_line) or status_line[pos] != 0x20:
        return False
    pos += 1
    # Status code: three digits
    if pos + 3 > len(status_line):
        return False
    code_bytes = status_line[pos:pos+3]
    if not (code_bytes[0] in range(48,58) and code_bytes[1] in range(48,58) and code_bytes[2] in range(48,58)):
        return False
    status_code_str = code_bytes.decode('ascii')
    # Validate against allowed codes (Primary field)
    allowed_codes = {"100","101","200","201","202","203","204","205","206","300","301","302","303","304","305","306","307","308","400","401","402","403","404","405","406","407","408","409","410","411","412","413","414","415","416","417","418","421","422","426","500","501","502","503","504","505"}
    if status_code_str not in allowed_codes:
        return False
    pos += 3
    # Now there must be a space before reason phrase (but reason phrase may be empty? According to HTTP spec, space is present even if reason phrase is empty. RFC 9112: "status-line = HTTP-version SP status-code SP reason-phrase CRLF"
    # So space must be present.
    if pos >= len(status_line) or status_line[pos] != 0x20:
        return False
    pos += 1
    # Reason phrase: any OCTET except CR and LF (0x0D,0x0A). But we already have status_line up to CRLF, so no CR/LF inside.
    # We'll just accept any remaining bytes as reason phrase (until end of status_line)
    # The reason phrase can be empty, but we already passed the space, so it's okay.
    # After reason phrase, we already consumed everything up to the CRLF we found.
    # So status line is complete.

    # ---- Now headers section ----
    # After status line CRLF, we have headers: *(field-name ':' OWS field-value OWS CRLF) CRLF
    # So we need to parse subsequent lines until we find an empty line (CRLF immediately after CRLF).
    # But careful: the status line CRLF ends with \r\n. Then after that, headers start.
    header_start = crlf_pos + 2
    # Find the empty line: double CRLF (CRLF CRLF) or CRLF at end of message? Actually headers section ends with CRLF (empty line).
    # So we need to find the first occurrence of a line that is just CRLF.
    # Strategy: iterate over lines delimited by CRLF.
    # But we must ensure proper CRLF parsing.
    # We'll scan for the next CRLF after header_start.
    search_pos = header_start
    # We'll locate the header section end by finding a CRLF that is immediately followed by another CRLF (or end of headers? Better: the empty line is the first line that is empty: i.e., CRLF where the content between previous CRLF and this CRLF is empty.
    # So we need to parse line by line.
    # Build a list of header lines (including the final empty line)
    # But we must ensure that the header section ends with CRLF, i.e., we have a terminating empty line.
    # If the message ends without an empty line, it's invalid.
    # We'll find the position of the last CRLF that is part of the header section empty line.
    # Simpler: slice the remaining bytes and find the empty line.
    remaining = response[header_start:]
    # Find the first \r\n that is not part of double? Actually standard: header section = *( header-field CRLF ) CRLF
    # So we need to parse fields until we encounter a CRLF immediately after a previous CRLF (i.e., empty line).
    # We'll iterate.
    pos = 0
    # We'll need to ensure no extra bytes after the final CRLF (except body).
    # But body is allowed after header section. The empty line is the CRLF that ends headers.
    # After that, body may be present.
    # So we need to find the position of the empty line, then the rest is body.
    # Let's find the first occurrence of double CRLF: b'\r\n\r\n'
    double_crlf = remaining.find(b'\r\n\r\n')
    if double_crlf == -1:
        # Might be that header section is empty? But specification says header section includes CRLF empty line.
        # If there is no double CRLF, then either headers are missing the empty line, or no headers and no body? But specification requires CRLF after headers.
        # Actually, if there are no headers, the header section is just CRLF (empty line). So we need exactly \r\n after status line.
        # So we need to check if the remaining starts with \r\n (empty line). That would be double_crlf at position 0.
        # Let's handle that.
        if remaining.startswith(b'\r\n'):
            # Then the remaining is just \r\n[body]? Actually empty line is \r\n, so double_crlf would be at 0. But we already checked -1.
            # So maybe remaining is just \r\n (single). But header section requires CRLF (empty line). So if remaining is exactly \r\n then no body, okay.
            # But then there is no double CRLF, but the header section is just that CRLF.
            # In that case, the header section ends at position 2, and body starts after that (empty).
            # So we can treat the empty line as the first line.
            # We'll handle this separately.
            pass
        else:
            # No empty line found -> invalid
            return False
    # We'll do a more robust parse: find the first line that is empty (i.e., \r\n at start of line).
    # But need to consider that header fields may have folding? HTTP/1.1 does not allow line folding (obs-fold) in modern spec, but we accept only OWS and no folding.
    # We'll parse by scanning for CRLF sequences.
    # Let's do a simple state machine.
    # We'll track the position in remaining.
    # We need to ensure that after the status line, we have at least one CRLF (empty line or header field).
    # But we already have the status line CRLF. So header_start points to beginning of header section.
    # We'll parse lines until we find an empty line (i.e., line with length 0 before CRLF).
    # If we reach end of 'remaining' without finding empty line, invalid.
    # We'll set 'pos' to 0 relative to remaining.
    # We'll also need to ensure that header field names and values are valid? According to the contract, we enforce constants, lengths, etc.
    # The IR says: HeaderSection: variable, zero or more header fields (each followed by CRLF) and a terminating empty line.
    # We'll do basic validation: each header field must match "field-name ':' OWS field-value OWS CRLF".
    # We'll implement a simple check for allowed characters? For simplicity, we'll check that field name contains only tokens (no CTLs, no separators except ':'), but we can be lenient since we only need to ensure structure.
    # However, to be safe, we'll enforce that field name is non-empty, contains no spaces, no colon, no CRLF, and then colon, optional whitespace, field value, optional whitespace, CRLF.
    # We'll accept any bytes except CR and LF in field value? Actually field value can contain any OCTET except CR, LF, and NUL? But we'll just check no CR or LF until the CRLF.
    # We'll also ensure that the header section ends with an empty line (CRLF).
    # If there is a body, it starts after that empty line.
    # Let's implement.
    # We'll work on the 'remaining' bytes from header_start.
    # We'll find the empty line by scanning.
    # We'll use a loop:
    #   line start = current pos
    #   Find next CRLF from pos
    #   If not found: invalid
    #   line = remaining[pos:crlf_pos] (without CRLF)
    #   If line is empty (length 0): this is the empty line. Then header section ends. Body starts after this CRLF.
    #   Else: parse line as header field.
    #   Then move pos to after CRLF.
    # We'll also need to ensure that after the header section empty line, we may have body (any bytes) and then no extra trailing data? Actually the whole message is consumed, but body may be present. The message ends after body. The problem says: "Reject ... unexplained trailing data". So after the body, there should be no extra bytes. But we don't know the exact length of body; it could be determined by Content-Length or chunked encoding. However, we are not required to parse Content-Length or chunked; the IR says "arbitrary octets" for body. So we can allow any trailing bytes as body? But then we wouldn't detect trailing data because body is arbitrary. However, the contract says "Reject ... unexplained trailing data". So if there is a body, it's part of the message. But if there is extra data after the body, it's unexplained. But we don't know where body ends. This is ambiguous. In many HTTP messages, the body length is determined by Content-Length or Transfer-Encoding: chunked. If we don't parse those, we cannot know where the body ends. However, the contract says: "Parse candidates in wire order ... enforce ... framing, payload boundaries, and whole-message consumption when specified." The IR says MessageBody: variable, arbitrary octets. It does not specify framing. So we cannot determine the boundary. Therefore, we must assume that the message ends at the end of the bytes. But then there is no trailing data because we consume everything. However, the contract says "Reject ... unexplained trailing data" - but we cannot differentiate between body and trailing data. To be safe, we should treat any leftover bytes after the header section as body, and accept them as part of the message. But then we cannot reject trailing data if there is no body framing specified. However, the contract says "when specified". Since the IR does not specify framing for body, we allow any leftover bytes as body. So we will accept a message that ends with the header section empty line (no body) or with additional bytes after empty line (body). Also, we must ensure that after the header section, the entire bytes are consumed. So we will check that after the empty line, the remaining bytes are the body (any bytes). And no extra bytes after that (but we already consume all). So we will return True if the parsing reaches the end of 'response' without error.

    # So we parse remaining.
    # Let's implement as described.
    pos = 0  # position in 'remaining' (bytes after status line CRLF)
    # We'll parse header fields until empty line.
    while True:
        # Find next CRLF from pos
        next_crlf = remaining.find(b'\r\n', pos)
        if next_crlf == -1:
            # No CRLF -> incomplete header section
            return False
        # Extract line (without CRLF)
        line = remaining[pos:next_crlf]
        # Check if empty line
        if len(line) == 0:
            # This is the empty line terminating headers
            # Body starts after this CRLF
            body_start = next_crlf + 2
            # No further constraints on body; accept any remaining bytes
            # But we must ensure that we have consumed the entire message? Actually we have consumed everything up to the end of 'remaining'? Not yet.
            # The body is everything after body_start. We don't need to parse it.
            # So we have successfully parsed the header section.
            # Now we just need to ensure that we have consumed the entire response? Actually we have consumed the status line + header section + body. The body is the rest of 'remaining' from body_start.
            # That covers the entire response. So we return True.
            # But we also need to ensure that there is no extra data after the body? Since body is the rest, there is none.
            return True
        else:
            # This is a header field line
            # Must contain a colon
            colon_pos = line.find(b':')
            if colon_pos == -1:
                return False
            field_name = line[:colon_pos]
            # Field name must be non-empty and contain only valid characters? At least no CR, LF, space? According to RFC 9110, field name is token (no spaces, no separators, no CTLs). We'll enforce that it contains no spaces, no CR, LF, and no colon (but colon is at position so not in name).
            # Simple check: any byte in field_name must not be 0x00-0x1F (except maybe 0x09? but CTLs are 0x00-0x1F and 0x7F). We'll disallow CTLs and space/colon? Actually space is 0x20, which is allowed in token? No, token excludes space. So we disallow spaces, CTLs, and DEL.
            for b in field_name:
                if b <= 0x1F or b == 0x20 or b == 0x7F:
                    # Also colon is not allowed but colon is not in field_name because we split at first colon.
                    # But if there is another colon later, it's part of field value? Actually field name can't have colon.
                    # We'll just check for improper characters.
                    return False
            # After colon, there is optional whitespace (OWS) which is SP or HTAB (0x20 or 0x09)
            after_colon = colon_pos + 1
            # Skip OWS
            while after_colon < len(line) and (line[after_colon] == 0x20 or line[after_colon] == 0x09):
                after_colon += 1
            # The rest of the line is field value (until optional trailing OWS before CRLF? Actually OWS can be before CRLF as well, but we already have the line up to CRLF, so we need to trim trailing OWS? The spec says field-value = *field-content, and OWS can appear before CRLF. But we can leave it as is; it's part of value. However, we need to ensure that field value does not contain CR or LF (0x0D,0x0A). Since we split at CRLF, the line does not contain CR/LF.
            # So we accept the field value.
            # Move pos to after the CRLF
            pos = next_crlf + 2
            # Continue to next line
            continue

    # Should never reach here
    return False