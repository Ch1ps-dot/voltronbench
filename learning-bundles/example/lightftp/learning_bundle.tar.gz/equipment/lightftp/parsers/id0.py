def packet_parser(response: bytes) -> bytes:
    # FTP response codes are always three digits at the start of the response line.
    # The response may be ASCII text, but we operate on bytes.
    # We check if the first three bytes are ASCII digits and match one of the allowed codes.
    if len(response) < 3:
        return b""
    # Check that the first three characters are digits
    part = response[:3]
    if not part.isdigit():
        return b""
    # Convert to integer for matching against the defined list
    code_int = int(part)
    # Allowed codes from RESPONSE_FIELDS_JSON
    allowed = {110, 120, 125, 150, 200, 202, 211, 212, 213, 214, 215, 220, 221, 225, 226, 227, 229, 230, 232, 234, 235, 250, 257, 331, 332, 334, 335, 336, 350, 421, 425, 426, 431, 450, 451, 452, 500, 501, 502, 503, 504, 522, 530, 532, 533, 534, 535, 536, 537, 550, 551, 552, 553, 631, 632, 633}
    if code_int in allowed:
        return part  # already bytes
    return b""