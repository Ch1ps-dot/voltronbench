def generate() -> bytes:
    command_code = b"NLST"
    separator = b" "
    pathname = b"/home/ubuntu"
    end_of_line = b"\r\n"
    return command_code + separator + pathname + end_of_line