def generate() -> bytes:
    # CommandCode: constant "ABOR" (4 bytes, ASCII)
    command_code = b"ABOR"
    # EndOfLine: constant 0x0D0A (CRLF, 2 bytes)
    end_of_line = b"\r\n"
    # Return the complete ABOR request
    return command_code + end_of_line