def generate() -> bytes:
    # CommandCode: constant "NOOP" in ASCII, 4 bytes
    command_code = b"NOOP"
    # EndOfLine: constant 0x0D 0x0A (CRLF), 2 bytes
    end_of_line = b"\r\n"
    # Concatenate in IR order: CommandCode then EndOfLine
    return command_code + end_of_line