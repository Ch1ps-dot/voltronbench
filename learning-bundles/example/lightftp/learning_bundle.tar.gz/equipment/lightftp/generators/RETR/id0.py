def generate() -> bytes:
    # CommandCode: constant "RETR" (3 bytes)
    command_code = b"RETR"
    # Separator: single space (0x20)
    separator = b"\x20"
    # Pathname: variable, choose a valid file name (ASCII printable, no CR/LF)
    # Use a simple pathname that is common for testing
    pathname = b"testfile.txt"
    # EndOfLine: CRLF (0x0D0A)
    eol = b"\x0D\x0A"
    
    # Concatenate in order
    return command_code + separator + pathname + eol