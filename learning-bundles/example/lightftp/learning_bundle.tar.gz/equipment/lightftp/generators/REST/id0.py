def generate() -> bytes:
    return b"REST 0\r\n"