def generate() -> bytes:
    return b"QUIT\r\n"