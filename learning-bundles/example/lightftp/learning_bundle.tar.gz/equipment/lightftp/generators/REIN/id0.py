def generate() -> bytes:
    # Command code: "REIN" (uppercase, 4 bytes)
    command_code = b"REIN"
    # End of line: CR LF (0x0D 0x0A)
    eol = b"\r\n"
    # Concatenate in IR order
    return command_code + eol