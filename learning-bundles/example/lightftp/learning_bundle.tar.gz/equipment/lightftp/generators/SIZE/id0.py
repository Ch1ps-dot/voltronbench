import random

def generate() -> bytes:
    # Constants
    command_code = b"SIZE"
    whitespace = b"\x20"
    end_of_line = b"\r\n"
    
    # Generate a valid pathname: ASCII characters except CR (0x0D) and LF (0x0A)
    # Use a typical file path for semantic realism, then vary for exploration
    # Common paths: "/home/ubuntu/file.txt", "/etc/passwd", "/tmp/test"
    path_options = [
        b"/home/ubuntu/file.txt",
        b"/etc/passwd",
        b"/tmp/test",
        b"/pub/readme",
        b"/incoming/upload",
        b"/var/log/syslog",
        b"/"
    ]
    pathname = random.choice(path_options)
    
    # Assemble the request
    request = command_code + whitespace + pathname + end_of_line
    return request