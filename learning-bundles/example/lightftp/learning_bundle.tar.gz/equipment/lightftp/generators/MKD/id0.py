import struct

def generate() -> bytes:
    # Build the MKD command: CommandCode + Whitespace + Pathname + EndOfLine
    command_code = b"MKD"
    whitespace = b"\x20"
    # Use a typical variable pathname: absolute path for exploration
    pathname = b"/tmp/testdir"
    end_of_line = b"\r\n"
    
    return command_code + whitespace + pathname + end_of_line