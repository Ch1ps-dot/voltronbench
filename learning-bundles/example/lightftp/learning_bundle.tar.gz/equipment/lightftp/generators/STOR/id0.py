def generate() -> bytes:
    return b"STOR test.txt\r\n"