def generate() -> bytes:
    # Command code constant
    cmd = b"PASS"
    # Whitespace separator
    ws = b"\x20"
    # Password: from SUT context, user ubuntu password is "ubuntu"
    password = b"ubuntu"
    # End-of-line: CRLF
    eol = b"\x0D\x0A"
    
    # Assemble in IR order: CommandCode, Whitespace, Password, EndOfLine
    return cmd + ws + password + eol