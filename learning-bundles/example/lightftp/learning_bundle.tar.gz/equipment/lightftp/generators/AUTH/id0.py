def generate() -> bytes:
    # Build AUTH command for FTP using the protocol definition
    # Fields in IR order: CommandCode, Whitespace, MechanismName, EndOfLine
    # Constant values as specified
    command_code = b"AUTH"
    whitespace = b" "
    # MechanismName: choose a valid, common security mechanism for state exploration
    # Use "X-ANONYMOUS" as a valid local-use mechanism (IANA-registered "X-" prefix)
    # This is ASCII, case-insensitive, no CR/LF; length variable
    mechanism_name = b"X-ANONYMOUS"
    end_of_line = b"\r\n"
    # Concatenate in order
    return command_code + whitespace + mechanism_name + end_of_line