def generate() -> bytes:
    # CDUP command code: constant "CDUP" as ASCII
    command_code = b"CDUP"
    # End-of-line: constant 0x0D 0x0A
    eol = b"\x0D\x0A"
    # Concatenate in the order defined by the IR: command code then EOL
    return command_code + eol