def generate() -> bytes:
    # Command code: "PASV" in ASCII
    command_code = b"PASV"
    # End of line: CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    # Return the complete request: CommandCode + EndOfLine
    return command_code + end_of_line