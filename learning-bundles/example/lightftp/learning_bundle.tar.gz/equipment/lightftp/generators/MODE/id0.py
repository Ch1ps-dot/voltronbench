def generate() -> bytes:
    """
    Generate a valid FTP MODE request with Stream mode (S).
    Fields in order: CommandCode (4 bytes), Whitespace (1 byte), ModeCode (1 byte), EndOfLine (2 bytes).
    """
    # Command code: "MODE" in ASCII, case-insensitive; use uppercase per RFC convention
    command_code = b"MODE"
    # Whitespace: single space (0x20)
    whitespace = b" "
    # Mode code: 'S' for Stream mode, ASCII
    mode_code = b"S"
    # End-of-line: CRLF (0x0D 0x0A)
    eol = b"\r\n"
    # Concatenate in order
    return command_code + whitespace + mode_code + eol