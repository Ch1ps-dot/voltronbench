def generate() -> bytes:
    # Constants
    command_code = b"MIC"
    whitespace = b"\x20"
    # Base64-encoded protected message: we use a simple valid base64 string
    # For FTP MIC, the protected message is a safe FTP command, e.g. "USER ubuntu"
    # Base64 of "USER ubuntu" (length 11) is "VVNFUiB1YnVudHU=" (12 chars)
    base64_data = b"VVNFUiB1YnVudHU="
    end_of_line = b"\x0D\x0A"
    
    return command_code + whitespace + base64_data + end_of_line