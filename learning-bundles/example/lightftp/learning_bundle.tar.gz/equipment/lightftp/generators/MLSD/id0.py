def generate():
    return b"MLSD /home/ubuntu\r\n"