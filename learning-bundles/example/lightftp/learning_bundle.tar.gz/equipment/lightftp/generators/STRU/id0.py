import struct

def generate() -> bytes:
    """
    Generate a valid FTP STRU request with Structure-code = 'F' (File).
    """
    # IR order: CommandCode (constant "STRU"), Whitespace (constant 0x20),
    # StructureCode (variable "F"), EndOfLine (constant CRLF)
    command_code = b"STRU"
    whitespace = b"\x20"
    structure_code = b"F"  # File structure
    end_of_line = b"\r\n"
    
    return command_code + whitespace + structure_code + end_of_line