def generate() -> bytes:
    return b"FEAT\r\n"