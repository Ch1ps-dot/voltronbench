import base64
import random

def generate() -> bytes:
    # Command code "ENC" exactly 3 bytes ASCII
    command_code = b"ENC"
    # Single space separator (0x20)
    whitespace = b"\x20"
    # Base64 encoded data: we need to produce a valid base64 string.
    # For fuzzing state exploration, we generate a random plaintext, then base64 encode it.
    # Choose a random length for the plaintext (1-20 bytes).
    plaintext_len = random.randint(1, 20)
    plaintext = bytes(random.randint(0, 255) for _ in range(plaintext_len))
    base64_data = base64.b64encode(plaintext)
    # Ensure no line breaks; base64.b64encode already returns a single line without newlines.
    # End-of-line CRLF
    end_of_line = b"\x0D\x0A"
    return command_code + whitespace + base64_data + end_of_line