def generate() -> bytes:
    # Build the MDTM command request for FTP
    # Fields: CommandCode (4B constant "MDTM"), Whitespace (1B space),
    # Pathname (variable, ASCII), EndOfLine (2B CRLF)
    
    # Use a common valid pathname for testing
    pathname = b"/home/ubuntu/test.txt"
    
    # Assemble request
    request = b"MDTM" + b" " + pathname + b"\r\n"
    return request