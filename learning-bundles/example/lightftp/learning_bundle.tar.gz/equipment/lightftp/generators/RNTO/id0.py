import struct

def generate() -> bytes:
    # Command code RNTO (4 bytes)
    command = b"RNTO"
    # Whitespace separator (1 byte SP)
    whitespace = b"\x20"
    # Pathname: variable-length ASCII printable, no CR/LF (0x0D, 0x0A)
    # Use a valid pathname from FTP context: assume a home directory file
    pathname = b"/home/ubuntu/newfile.txt"
    # End-of-line sequence (2 bytes CR+LF)
    eol = b"\r\n"
    # Assemble in IR order
    msg = command + whitespace + pathname + eol
    return msg