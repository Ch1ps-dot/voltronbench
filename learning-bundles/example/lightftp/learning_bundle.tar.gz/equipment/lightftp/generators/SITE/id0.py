def generate() -> bytes:
    return b"SITE HELP\r\n"