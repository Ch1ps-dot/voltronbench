def generate() -> bytes:
    command_code = b"LIST"
    whitespace = b" "
    pathname = b"/home/ubuntu"
    eol = b"\r\n"
    return command_code + whitespace + pathname + eol