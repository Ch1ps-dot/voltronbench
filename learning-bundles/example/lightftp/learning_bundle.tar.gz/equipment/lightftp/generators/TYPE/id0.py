def generate() -> bytes:
    # Build the TYPE command: command code "TYPE", separator space, type code "A", CRLF
    command = b"TYPE"
    separator = b" "
    type_code = b"A"
    crlf = b"\r\n"
    return command + separator + type_code + crlf