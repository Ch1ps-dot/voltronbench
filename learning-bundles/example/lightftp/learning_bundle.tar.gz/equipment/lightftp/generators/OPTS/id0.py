def generate() -> bytes:
    return b"OPTS MLST type;size;modify\r\n"