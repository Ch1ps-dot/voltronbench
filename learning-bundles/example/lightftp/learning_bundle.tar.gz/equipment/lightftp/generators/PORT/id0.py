def generate() -> bytes:
    # Build the PORT command: "PORT h1,h2,h3,h4,p1,p2\r\n"
    # Use the account info: ubuntu/ubuntu on local server.
    # Choose a valid local IP and port for active mode.
    # IP: 127.0.0.1, Port: 20 (0x14 => 0,20)
    host_octets = [127, 0, 0, 1]
    # Port 20: high byte = 0, low byte = 20
    port_high = 0
    port_low = 20

    # Compose the argument string: h1,h2,h3,h4,p1,p2
    arg = f"{host_octets[0]},{host_octets[1]},{host_octets[2]},{host_octets[3]},{port_high},{port_low}"
    # Full command: "PORT " + arg + "\r\n"
    msg = f"PORT {arg}\r\n"
    return msg.encode("ascii")