def generate() -> bytes:
    return b"CCC\r\n"