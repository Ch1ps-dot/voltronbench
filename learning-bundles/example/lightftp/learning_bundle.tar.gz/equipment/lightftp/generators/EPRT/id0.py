import struct

def generate() -> bytes:
    # Delimiter character: use recommended '|' (ASCII 124)
    delim = b'|'
    
    # Command and whitespace
    command = b'EPRT'
    whitespace = b' '
    
    # NetProtocol: 1 for IPv4 (use a common valid value)
    net_proto = b'1'
    
    # NetworkAddress: IPv4 dotted-decimal example (using a non-routable test address)
    net_addr = b'192.168.1.100'
    
    # TCPPort: a common port for FTP data (e.g., 20)
    tcp_port = b'20'
    
    # End of line: CRLF
    eol = b'\r\n'
    
    # Build the full request in IR order:
    # CommandCode + Whitespace + Delimiter1 + NetProtocol + Delimiter2 + NetworkAddress + Delimiter3 + TCPPort + Delimiter4 + EndOfLine
    request = command + whitespace + delim + net_proto + delim + net_addr + delim + tcp_port + delim + eol
    
    return request