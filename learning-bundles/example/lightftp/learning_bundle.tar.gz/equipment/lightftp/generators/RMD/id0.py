import struct

def generate() -> bytes:
    # Build the RMD command as per FTP protocol specification
    # CommandCode: "RMD" (3 bytes, constant)
    # Whitespace: 0x20 (1 byte)
    # Pathname: variable, ASCII excluding CR and LF
    # EndOfLine: 0x0D0A (2 bytes, CR LF)
    
    # Choose a valid pathname for the remove directory command
    # Here we use a simple relative directory name to avoid system-specific issues
    pathname = "testdir"
    
    # Validate pathname contains no carriage return or line feed (ensure safety)
    assert '\r' not in pathname and '\n' not in pathname, "Pathname must not contain CR or LF"
    
    # Build the request in order: CommandCode, Whitespace, Pathname, EndOfLine
    request = b"RMD " + pathname.encode('ascii') + b"\r\n"
    
    return request