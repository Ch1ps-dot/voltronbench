def generate() -> bytes:
    # Build the USER command according to the protocol specification
    # Command code: "USER" (4 bytes, ASCII)
    command_code = b"USER"
    # Whitespace: single space (0x20)
    whitespace = b"\x20"
    # Username: choose "ubuntu" as per SUT account information
    # username is variable length ASCII string without CR/LF
    username = b"ubuntu"
    # End of line: CRLF (0x0D 0x0A)
    end_of_line = b"\x0D\x0A"
    # Concatenate in order: CommandCode + Whitespace + Username + EndOfLine
    return command_code + whitespace + username + end_of_line