def generate() -> bytes:
    # Command code: "ACCT" (4 bytes, ASCII)
    command_code = b"ACCT"
    # Whitespace: single space (0x20)
    whitespace = b"\x20"
    # Account information: "ubuntu" (ASCII string)
    account_info = b"ubuntu"
    # End of line: CR LF (0x0D 0x0A)
    end_of_line = b"\x0D\x0A"
    # Concatenate in order: CommandCode, Whitespace, AccountInformation, EndOfLine
    return command_code + whitespace + account_info + end_of_line