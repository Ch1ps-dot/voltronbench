def generate() -> bytes:
    # Command code "PWD" as ASCII bytes, exactly 3 bytes per spec
    command_code = b"PWD"
    # End-of-line sequence: CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    # Concatenate in IR order: CommandCode then EndOfLine
    return command_code + end_of_line