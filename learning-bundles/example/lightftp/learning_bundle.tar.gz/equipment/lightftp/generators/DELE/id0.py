def generate() -> bytes:
    """
    Generate a valid FTP DELE request for deleting a file.
    Uses the account ubuntu:ubuntu on the local server.
    """
    # Command code: "DELE" (4 ASCII characters, uppercase)
    command_code = b"DELE"
    
    # Whitespace: single space (0x20)
    whitespace = b"\x20"
    
    # Pathname: variable-length printable ASCII string, no CR/LF
    # Choose a valid pathname for the ubuntu user's home directory
    pathname = b"/home/ubuntu/test.txt"
    
    # End-of-line: CRLF (0x0D 0x0A)
    eol = b"\r\n"
    
    # Assemble in IR order: CommandCode, Whitespace, Pathname, EndOfLine
    request = command_code + whitespace + pathname + eol
    
    return request