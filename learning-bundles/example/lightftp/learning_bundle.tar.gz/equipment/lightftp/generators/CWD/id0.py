def generate() -> bytes:
    command_code = b"CWD"
    whitespace = b" "
    pathname = b"/home/ubuntu"
    end_of_line = b"\r\n"
    return command_code + whitespace + pathname + end_of_line