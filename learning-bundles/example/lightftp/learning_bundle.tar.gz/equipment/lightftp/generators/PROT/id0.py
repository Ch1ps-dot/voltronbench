def generate() -> bytes:
    """
    Generate a single PROT command with the specified type-rule: Command='PROT', Prot-code='C'.
    The structure is: PROT<space>C<CRLF>
    Field order: CommandCode, Whitespace, ProtectionLevel, EndOfLine
    All values are constant/literal as per the IR.
    """
    # CommandCode: "PROT" (4 bytes ASCII)
    command_code = b"PROT"
    # Whitespace: 0x20 (1 byte)
    whitespace = b"\x20"
    # ProtectionLevel: "C" (1 byte ASCII) - Clear level
    protection_level = b"C"
    # EndOfLine: 0x0D0A (2 bytes)
    end_of_line = b"\r\n"

    # Concatenate in IR order
    return command_code + whitespace + protection_level + end_of_line