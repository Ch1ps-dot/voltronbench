def generate() -> bytes:
    return b"STAT /home/ubuntu\r\n"