def generate() -> bytes:
    return b"RNFR /home/ubuntu/oldname.txt\r\n"