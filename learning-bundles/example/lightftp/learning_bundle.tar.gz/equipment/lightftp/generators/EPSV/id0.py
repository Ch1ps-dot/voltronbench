def generate() -> bytes:
    # Build EPSV command with no argument
    # CommandCode: "EPSV" (4 bytes, constant)
    # No Whitespace or Argument (optional, omitted)
    # EndOfLine: CRLF (0x0D0A)
    return b"EPSV\r\n"