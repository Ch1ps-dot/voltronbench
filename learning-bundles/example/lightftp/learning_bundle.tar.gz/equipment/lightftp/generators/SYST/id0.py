def generate() -> bytes:
    # SYST command: constant "SYST" followed by CRLF (0x0D 0x0A)
    command = b"SYST"
    crlf = b"\r\n"
    return command + crlf