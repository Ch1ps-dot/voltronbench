def generate() -> bytes:
    # Command code (constant, 4 bytes, ASCII)
    cmd = b"PBSZ"
    # Whitespace separator (constant, 1 byte, space)
    sep = b" "
    # BufferSize: valid decimal integer between 1 and 4294967295
    # Using a common boundary value for state exploration: 0 (invalid) avoided,
    # using 1 as minimal valid value, varies from account requirement.
    buffer_size = b"1"
    # EndOfLine (constant, 2 bytes, CRLF)
    eol = b"\r\n"
    # Assemble in IR order
    return cmd + sep + buffer_size + eol