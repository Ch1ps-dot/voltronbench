def generate() -> bytes:
    # Build the APPE command according to RFC 959
    # CommandCode: constant "APPE" (4 bytes ASCII)
    command_code = b"APPE"
    # Whitespace: constant 0x20 (1 byte)
    whitespace = b"\x20"
    # Pathname: variable length, ASCII printable except CR/LF.
    # Choose a valid pathname that exists or can be created on the target system.
    # Using a common path that is likely to be valid for the ubuntu account.
    pathname = b"/home/ubuntu/testfile.txt"
    # EndOfLine: constant CRLF (0x0D 0x0A)
    end_of_line = b"\x0D\x0A"
    # Combine in IR order
    return command_code + whitespace + pathname + end_of_line