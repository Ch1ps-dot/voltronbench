def generate():
    return b"SMNT /home/ubuntu\r\n"