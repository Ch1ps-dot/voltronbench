def generate() -> bytes:
    return b"MLST /home/ubuntu\r\n"