def packet_checker(response: bytes) -> bool:
    # Reject non-bytes
    if not isinstance(response, bytes):
        return False

    # Must be at least 3 digits + separator + EOL (5 bytes: 3 digits, 1 separator, 2 CRLF)
    # But text can be empty, so minimum is 3 + 1 + 2 = 6 bytes? Actually 3 digits + separator + CRLF = 6 bytes.
    # However, StatusCode is 3 digits, Separator is 1 byte, EndOfLine is 2 bytes -> total 6 bytes minimum (with empty text)
    if len(response) < 6:
        return False

    # Parse StatusCode: first 3 bytes must be ASCII digits
    try:
        status_code_str = response[0:3].decode('ascii')
    except UnicodeDecodeError:
        return False
    if not status_code_str.isdigit():
        return False
    status_code = int(status_code_str)
    # First digit must be 1-5
    first_digit = status_code // 100
    if first_digit not in [1, 2, 3, 4, 5]:
        return False
    # Range 100-599
    if not (100 <= status_code <= 599):
        return False

    # Primary field value list from PRIMARY_FIELDS_JSON
    allowed_codes = [110, 120, 125, 150, 200, 202, 211, 212, 213, 214, 215, 220, 221, 225, 226, 227, 229, 230, 232, 234, 235, 250, 257, 331, 332, 334, 335, 336, 350, 421, 425, 426, 431, 450, 451, 452, 500, 501, 502, 503, 504, 522, 530, 532, 533, 534, 535, 536, 537, 550, 551, 552, 553, 631, 632, 633]
    if status_code not in allowed_codes:
        return False

    # Separator: 4th byte must be 0x20 (space) or 0x2D (hyphen)
    separator = response[3]
    if separator not in (0x20, 0x2D):
        return False

    # If separator is space (0x20), single-line reply: text until CRLF, then EOL
    # If separator is hyphen (0x2D), multi-line reply: first line ends with CRLF, then additional lines, last line begins with same StatusCode followed by space
    # We need to parse accordingly.

    if separator == 0x20:
        # Single-line: text from position 4 until CRLF
        # Find CRLF (0x0D0A) starting from position 4
        crlf_pos = response.find(b'\r\n', 4)
        if crlf_pos == -1:
            return False
        # Text between position 4 and crlf_pos
        text = response[4:crlf_pos]
        # Validate text: each byte must be TCHAR (VCHAR, SP, HTAB) -> printable ASCII (0x20-0x7E) plus HTAB (0x09)
        for b in text:
            if not (0x20 <= b <= 0x7E or b == 0x09):
                return False
        # EndOfLine must be exactly CRLF at crlf_pos
        if response[crlf_pos:crlf_pos+2] != b'\r\n':
            return False
        # Check that after EOL there is no trailing data
        if len(response) != crlf_pos + 2:
            return False
        return True

    else:  # separator == 0x2D (hyphen)
        # Multi-line reply: first line ends with CRLF, then additional lines, last line begins with same StatusCode followed by space.
        # The entire response must end with the closing line: StatusCode (3 digits) + space + optional text + CRLF
        # No trailing data allowed.
        # We need to locate the last line: it should be the line starting with the same StatusCode followed by a space at the end of the response.
        # First, find the first CRLF after position 4 to get first line text.
        first_crlf = response.find(b'\r\n', 4)
        if first_crlf == -1:
            return False
        # Validate first line text (excluding the separator and CRLF)
        first_text = response[4:first_crlf]
        for b in first_text:
            if not (0x20 <= b <= 0x7E or b == 0x09):
                return False
        # Now, after first CRLF, there should be more lines, and the last line must start with StatusCode + space
        # The last line starts at some position and ends with CRLF at the end of response.
        # Let's find the last CRLF in the response (the final one)
        # The response must end with CRLF
        if not response.endswith(b'\r\n'):
            return False
        # Find the start of the last line: the last CRLF before the final one? Actually, the last line is between the last CRLF (which is the final one) and the previous CRLF.
        # The final CRLF is at the end. The preceding CRLF (if any) marks the end of the previous line.
        # So we need to find the second-to-last CRLF.
        # If there is only one CRLF (the first one), then the last line is the same as the first? But multi-line requires at least one additional line, so the last line must be different.
        # Check that there are at least two CRLFs (first line and last line)
        # Actually, the first line ends with CRLF, then the last line also ends with CRLF. So total CRLFs >= 2.
        # The last line is from the position after the last CRLF (except the final one) to the end before the final CRLF.
        # Let's find all CRLF positions.
        crlf_positions = []
        start = 0
        while True:
            pos = response.find(b'\r\n', start)
            if pos == -1:
                break
            crlf_positions.append(pos)
            start = pos + 2
        if len(crlf_positions) < 2:
            # Need at least first line and last line closing
            return False
        # The last line starts after the second-to-last CRLF (the last one before the final CRLF)
        # The final CRLF is at crlf_positions[-1]
        # The previous CRLF is at crlf_positions[-2]
        last_line_start = crlf_positions[-2] + 2
        last_line_end = crlf_positions[-1]  # position of final CRLF (the CR itself)
        last_line = response[last_line_start:last_line_end]
        # The last line must start with the same StatusCode (3 digits) followed by space (0x20)
        if len(last_line) < 4:
            return False
        if last_line[0:3] != response[0:3]:
            return False
        if last_line[3] != 0x20:
            return False
        # Validate the rest of last line (text after space)
        for b in last_line[4:]:
            if not (0x20 <= b <= 0x7E or b == 0x09):
                return False
        # Validate all text in intermediate lines (between first CRLF and last line start)
        intermediate = response[first_crlf+2:last_line_start]
        # This should consist of zero or more lines, each ending with CRLF
        # But we need to ensure that each line's text (excluding CRLF) is valid TCHAR
        # Split by CRLF, but carefully: intermediate may be empty if there are no intermediate lines? But multi-line definition: additional text lines follow the first line, and the last line repeats StatusCode. So there must be at least one intermediate line? Actually, the first line is the one with hyphen, then there may be additional lines, and the last line has space. So the number of lines after first line is at least 1 (the last line). So intermediate should contain the lines between first and last, possibly empty? But if there are no intermediate lines, then the last line immediately follows the first CRLF? That would mean the last line starts right after the first CRLF, which is valid? The definition: "additional text lines (each terminated by CRLF) follow this first line; the last line repeats the same StatusCode followed by a space." So there could be zero additional lines? Possibly, but then the last line would be the line after the first CRLF, which would be the closing line. That is allowed. So intermediate can be empty.
        if len(intermediate) > 0:
            # It must consist of one or more lines each ending with CRLF, but since we have already defined last_line_start after the second-to-last CRLF, the intermediate may contain multiple lines.
            # We need to parse lines in intermediate. But intermediate ends right before last_line_start, which is after the second-to-last CRLF. The intermediate itself may contain CRLFs.
            # Let's parse all lines from the start of intermediate to the end of the last CRLF before the last line.
            # Actually, we already have the last line. The intermediate should be exactly the part from first_crlf+2 to last_line_start, which should be multiple lines each ending with CRLF.
            # We can validate by splitting intermediate by CRLF and checking each line's text.
            lines = intermediate.split(b'\r\n')
            # The split will produce a list where the last element is empty if intermediate ends with CRLF? Let's see: intermediate ends at last_line_start, which is after the second-to-last CRLF. So intermediate includes the CRLF of the previous line(s). For example, if there is one intermediate line, intermediate = "text\r\n", then split gives ['text', '']; the empty string is because the trailing CRLF is split. But we want to validate the text part only. The last element being empty is fine because it represents the end of the line. However, if intermediate ends with CRLF, the split will have an empty string at the end. That empty string corresponds to the text after the last CRLF, which is empty. That is okay because the last line is separate.
            # But we need to ensure that each line's text (non-empty parts) are valid TCHAR. The empty string is fine.
            for line in lines:
                for b in line:
                    if not (0x20 <= b <= 0x7E or b == 0x09):
                        return False
        # Ensure that no trailing data after final CRLF (already checked by endswith)
        # Also ensure that the entire response is consumed: the last line ends at the final CRLF, and no extra bytes.
        if len(response) != last_line_end + 2:
            return False
        return True