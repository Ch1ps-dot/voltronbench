import hashlib

def packet_observer(response: bytes) -> str:
    """
    Normalize FTP response bytes by replacing dynamic text with a fixed marker,
    then return lowercase SHA-256 hex digest.
    """
    if not isinstance(response, bytes):
        return hashlib.sha256(b"").hexdigest()

    try:
        # Split on first space or hyphen after the three-digit status code
        # The separator is at position 3 (0-indexed)
        if len(response) < 4:
            return hashlib.sha256(response).hexdigest()

        # Status code is ASCII digits at positions 0-2
        status = response[:3]
        # Separator is at position 3
        separator = response[3:4]
        # The rest is text + end-of-line
        tail = response[4:]

        # Validate status code is three ASCII digits
        if not (status.isdigit() and 100 <= int(status) <= 599):
            return hashlib.sha256(response).hexdigest()

        # Validate separator is space or hyphen
        if separator not in (b" ", b"-"):
            return hashlib.sha256(response).hexdigest()

        # Remove trailing CRLF (0x0D 0x0A)
        # In multi-line replies, each line ends with CRLF, but we only normalize the first line's text.
        # The entire response is a single reply; we treat the text after the first separator as dynamic.
        # For multi-line replies, subsequent lines are part of the text; we replace the whole text block.
        # To preserve length and structure, we replace the text with a marker of fixed length.
        # The marker should be a string of printable ASCII that matches the length of the original text.
        # However, to avoid complexity and potential issues with length variation, we use a simple stable marker.
        # We'll replace the text portion with a marker that preserves the length of the original text.
        # But the original text length can vary; we need a deterministic replacement.
        # The contract says "stable field-specific markers that preserve presence and required length."
        # For FTP text, the "required length" is not fixed; it's variable. The presence is preserved.
        # We'll replace the entire text (including any trailing CRLF) with a marker of the same length (number of bytes).
        # To keep it simple and stable, we'll use a fixed marker like b'X' repeated for the length of the text.
        # But that would change the length if the text length varies between responses? No, we match the length.
        # However, the contract says "preserve ... required length". The text length is dynamic, not required.
        # So we can replace it with a fixed-length marker? The contract says "preserve presence and required length."
        # The text is not a required fixed-length field; its length is variable. So we can replace it with a marker of the same length as the original.
        # That would preserve the overall response length, which is important for framing.
        # Alternatively, we can replace the entire tail with a single fixed marker like b'<TEXT>'.
        # But that would change the length, which might affect the hash's ability to detect framing differences.
        # The contract says "preserve status/type, framing, lengths, ...". So we should preserve the total length.
        # Therefore, we replace the text with a marker of the same length.
        # However, the marker itself must be deterministic and field-specific.
        # We'll use b'X' * len(tail) as a placeholder.
        # But we must also handle the case where tail is empty (possible).
        # For multi-line replies, the first line ends with hyphen, and subsequent lines follow.
        # The entire response bytes include all lines. We treat the whole response as a single reply.
        # The text portion includes everything after the first separator (including CRLF, subsequent lines, etc.).
        # So we replace that entire tail with a marker of equal length.
        # This is safe because the status code and separator are preserved.
        normalized = status + separator + b'X' * len(tail)
        return hashlib.sha256(normalized).hexdigest()
    except Exception:
        # If any parsing fails, hash the original bytes
        return hashlib.sha256(response).hexdigest()