def packet_checker(response: bytes) -> bool:
    # Reject non-bytes
    if not isinstance(response, bytes):
        return False

    # Must be at least 3 digits + separator + CRLF (min 5 bytes: 3 digits + 1 space + 2 CRLF)
    if len(response) < 5:
        return False

    # Check end-of-line (constant 0x0D0A)
    if response[-2:] != b'\x0d\x0a':
        return False

    # Extract prefix (everything before CRLF)
    payload = response[:-2]
    if len(payload) < 3:
        return False

    # Extract status code (first 3 bytes must be digits)
    status_bytes = payload[:3]
    try:
        status_str = status_bytes.decode('ascii')
    except UnicodeDecodeError:
        return False
    if not status_str.isdigit():
        return False
    status_code = int(status_str)
    if status_code < 100 or status_code > 599:
        return False

    # Separator: byte 3 (index 3) must be 0x20 (space) or 0x2D (hyphen)
    if len(payload) < 4:
        return False
    separator = payload[3]
    if separator not in (0x20, 0x2D):
        return False

    # Text: remaining bytes after separator (must be printable ASCII plus whitespace)
    text = payload[4:]
    for byte in text:
        # Allowed: VCHAR (0x21-0x7E), SP (0x20), HTAB (0x09)
        if byte not in (0x20, 0x09) and (byte < 0x21 or byte > 0x7E):
            return False

    # If separator is hyphen (multi-line), additional validation:
    # The last line of a multi-line response must start with the same status code followed by space.
    if separator == 0x2D:
        # Find last CRLF-split? But we already stripped the final CRLF.
        # Multi-line: the payload contains lines separated by CRLF.
        # Since we have payload without final CRLF, we need to split by CRLF within payload.
        # But CRLF inside payload is not allowed per our end-of-line constant? Actually multi-line
        # responses have CRLF after each line except the last line before the final CRLF is the last line.
        # Our payload ends before the final CRLF, so it may contain embedded CRLFs.
        # Let's check if there are any CRLFs in the text. If yes, we need to validate last line.
        # However, the specification: last line repeats the same StatusCode followed by space and optional text.
        # We'll find the last line by splitting on CRLF.
        # But note: the embedded CRLF would be part of the text? Actually the protocol uses CRLF as line terminator.
        # The payload includes only the content before the final CRLF, which may contain embedded CRLFs.
        # We need to check the last line after the last CRLF.
        # We'll search for the last occurrence of CRLF and then check the remainder.
        # But careful: The text may contain CRLF, but our payload has already removed the final CRLF.
        # So we find the last CRLF in payload and take the part after it.
        last_crlf = payload.rfind(b'\x0d\x0a')
        if last_crlf != -1:
            # There is at least one embedded CRLF
            last_line = payload[last_crlf+2:]  # skip the CRLF
        else:
            # No embedded CRLF, the entire payload after status+separator is the last line (but separator is hyphen, so it's first line of multi-line? Actually single-line with hyphen? That's allowed? The spec says hyphen for first line of multi-line. So there must be more lines. If no embedded CRLF, it's malformed.)
            # However, we treat it as last line if no CRLF: but then the multi-line has no final line? Better to reject.
            return False  # Malformed: hyphen separator but no subsequent lines

        # Check last line: must start with the same status code + space
        if len(last_line) < 4:
            return False
        if last_line[:3] != status_bytes:
            return False
        if last_line[3] != 0x20:
            return False
        # Remaining text of last line must be valid (already checked above? Actually we checked entire text including embedded CRLFs. But we need to check that the last line's text is valid, but we already validated all bytes in text. However, we must also ensure that the last line does not contain any CRLF (since it's the last line before final CRLF). That's fine because we split on CRLF.
        # Also, the first line (before first CRLF) must have the hyphen separator, which we already checked.
        # Validate that the first line's text (after status+hyphen) before first CRLF is valid (already checked for all bytes, but we need to ensure no CRLF in first line? Actually first line text can contain any printable ASCII, but CRLF is not part of text; it's the line terminator. So the first line text ends at first CRLF. Our validation of text includes CRLF bytes? We didn't allow CRLF in text because we only allowed 0x20, 0x09, and 0x21-0x7E. So CRLF (0x0D, 0x0A) are not allowed in text. This ensures that any CRLF in payload is only as line separator. But we already stripped the final CRLF, so embedded CRLFs are present. In our validation above, we checked each byte of text, which includes the CR and LF bytes. Since we disallowed 0x0D and 0x0A, the validation would reject any embedded CRLF. That is a problem.
        # Actually the specification: The text is human-readable message. For multi-line, additional text lines follow. The line terminator is CRLF. So the payload contains CRLF between lines. We need to allow CRLF in the text region as separators.
        # Therefore our earlier validation of text bytes is too strict. We must allow CRLF within the text for multi-line responses.
        # Let's redo: Instead of iterating over text bytes and disallowing CRLF, we should allow CRLF as part of the structure. Better to validate line by line.

        # So we need to reconsider the entire validation.

        # Given the complexity, let's step back: The response is a complete FTP response with final CRLF. The payload includes multiple lines separated by CRLF. The last line also ends with CRLF (which we removed). So we need to split payload into lines by CRLF.
        # For single-line (separator=space), the payload has exactly one line (no CRLF inside).
        # For multi-line (separator=hyphen), the payload has two or more lines, each separated by CRLF.

        # So we'll redo validation from scratch with proper line splitting.

        # Actually, to avoid rework, we can adjust: instead of disallowing CRLF, we should allow them in text but then enforce proper line structure.

        # Let's rewrite the whole function more cleanly.

        # Since the contract requires exact handling, we'll implement a proper parser.

        # We'll return earlier if issues, but we need to redo. Let's abort and rewrite.

        # (Given the complexity, I'll restructure the code.)
        # However, I'll keep the initial checks and then redo from separator.

        # Actually, let's just start over within this function but keep the early checks.

        # We'll keep the code from here but replace the body.

        # Since we are in the middle, we can just return False for now? No.

        # Let's proceed with a clean implementation.

        # We'll discard the current logic and reimplement.

        # Start fresh inside the function.

        # But we already have code. We'll replace the rest.

        # Actually, we can just return False for now and then rewrite the function below.

        # Since the instruction says "no markdown or prose", we need to output only the final code.

        # I will output the complete corrected function.

        pass

    # If we reach here, all checks passed for single-line or multi-line with proper structure.
    return True

# Redefine the function with corrected logic
def packet_checker(response: bytes) -> bool:
    if not isinstance(response, bytes):
        return False
    if len(response) < 5:
        return False
    # End-of-line must be CRLF
    if response[-2:] != b'\x0d\x0a':
        return False
    # Payload without final CRLF
    payload = response[:-2]
    if len(payload) < 4:
        return False

    # Status code: first 3 bytes must be digits 100-599
    sc_bytes = payload[:3]
    try:
        sc_str = sc_bytes.decode('ascii')
    except UnicodeDecodeError:
        return False
    if not sc_str.isdigit():
        return False
    sc = int(sc_str)
    if sc < 100 or sc > 599:
        return False

    # Separator: byte at index 3
    sep = payload[3]
    if sep not in (0x20, 0x2D):
        return False

    # Remainder after separator
    rest = payload[4:]

    if sep == 0x20:  # Single-line response
        # No CRLF allowed in rest (since it's a single line)
        if b'\x0d\x0a' in rest:
            return False
        # Text must be printable ASCII (SP, HTAB, VCHAR)
        for byte in rest:
            if byte not in (0x20, 0x09) and (byte < 0x21 or byte > 0x7E):
                return False
        return True
    else:  # sep == 0x2D, multi-line response
        # Split rest into lines by CRLF
        lines = rest.split(b'\x0d\x0a')
        # Must have at least 2 lines (first line and last line)
        if len(lines) < 2:
            return False
        # First line: after status+hyphen, before first CRLF
        first_line = lines[0]
        # Check first line text (no CRLF inside, already split)
        for byte in first_line:
            if byte not in (0x20, 0x09) and (byte < 0x21 or byte > 0x7E):
                return False
        # Middle lines (if any) - must be valid text
        for line in lines[1:-1]:
            if len(line) == 0:  # empty line not allowed? Actually could be, but we check bytes
                pass
            for byte in line:
                if byte not in (0x20, 0x09) and (byte < 0x21 or byte > 0x7E):
                    return False
        # Last line: must start with same status code + space
        last_line = lines[-1]
        if len(last_line) < 4:
            return False
        if last_line[:3] != sc_bytes:
            return False
        if last_line[3] != 0x20:
            return False
        # Remaining text of last line
        last_text = last_line[4:]
        for byte in last_text:
            if byte not in (0x20, 0x09) and (byte < 0x21 or byte > 0x7E):
                return False
        # Ensure no trailing data after the last line? We already consumed rest and split by CRLF.
        # The rest ends without CRLF (since we removed final CRLF). So the lines are complete.
        # If there is any extra byte after the last CRLF? Actually rest ends at the final CRLF, so no extra.
        return True

# Overwrite the previous definition (the earlier function will be replaced by this one)
# Use the final function
packet_checker = packet_checker