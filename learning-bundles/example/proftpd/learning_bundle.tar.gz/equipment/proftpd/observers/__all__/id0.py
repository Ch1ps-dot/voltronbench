import hashlib

def packet_observer(response: bytes) -> str:
    """Normalize dynamic parts of an FTP response and return SHA-256 hex."""
    if not isinstance(response, bytes):
        response = b""
    try:
        text = response.decode("ascii", errors="replace")
    except Exception:
        text = response.decode("ascii", errors="replace")
    lines = text.split("\r\n")
    if not lines:
        return hashlib.sha256(response).hexdigest()
    first_line = lines[0]
    # Check if first three characters are digits
    if len(first_line) < 3 or not first_line[:3].isdigit():
        return hashlib.sha256(response).hexdigest()
    # We'll normalize the first line's text part if it's a single-line reply (separator is space)
    # For multi-line replies, the first line has hyphen, last line repeats code with space.
    # We'll preserve the status code, separator, and replace text with a marker.
    status_code = first_line[:3]
    # Determine separator character
    if len(first_line) > 3 and first_line[3] == '-':
        separator = '-'
    else:
        separator = ' '
    # Build normalized first line
    # For multi-line, we preserve the hyphen marker and the trailing text lines structure.
    # We'll normalize each line's text to a fixed marker preserving length.
    # For simplicity, we treat the entire text after status+separator as dynamic.
    # But we need to preserve the structural pattern (multi-line with repeated code).
    if separator == '-':
        # Multi-line response: first line with hyphen, then intermediate lines, last line with space.
        # We'll normalize each line's text to a marker of the same length.
        normalized_lines = []
        # First line
        text_part = first_line[4:]  # after code and hyphen
        # Replace text with a fixed string of same length to preserve length
        norm_text = 'X' * len(text_part) if text_part else ''
        normalized_lines.append(status_code + '-' + norm_text)
        # Intermediate lines
        for i in range(1, len(lines)-1):
            # If the line is empty, keep empty
            if not lines[i]:
                normalized_lines.append('')
            else:
                # If line starts with a 3-digit code and space, it could be a continuation? Actually multi-line: lines after first are arbitrary text, last line repeats code with space.
                # We'll just treat all non-last lines as text lines.
                line = lines[i]
                # Check if it's the last line's pattern? No, we are in intermediate.
                # Normalize entire line content to 'X' of same length.
                norm_line = 'X' * len(line) if line else ''
                normalized_lines.append(norm_line)
        # Last line (should have same code then space)
        last_line = lines[-1] if len(lines) > 1 else ''
        if last_line and len(last_line) >= 4 and last_line[:3].isdigit() and last_line[3] == ' ':
            code_last = last_line[:3]
            text_last = last_line[4:]
            norm_text_last = 'X' * len(text_last) if text_last else ''
            normalized_lines.append(code_last + ' ' + norm_text_last)
        else:
            # fallback: normalize whole line
            norm_last = 'X' * len(last_line) if last_line else ''
            normalized_lines.append(norm_last)
        # Join with CRLF
        normalized = '\r\n'.join(normalized_lines)
    else:
        # Single-line reply: code + space + text
        text_part = first_line[4:] if len(first_line) > 4 else ''
        norm_text = 'X' * len(text_part) if text_part else ''
        normalized = status_code + ' ' + norm_text
        # Add remaining lines (shouldn't be any, but just in case)
        if len(lines) > 1:
            rest = '\r\n'.join(lines[1:])
            if rest:
                # Normalize rest lines similarly? For simplicity, we'll treat them as text.
                # But this is unusual; we'll just normalize each line.
                rest_lines = rest.split('\r\n')
                norm_rest_lines = []
                for rl in rest_lines:
                    norm_rest_lines.append('X' * len(rl) if rl else '')
                normalized += '\r\n' + '\r\n'.join(norm_rest_lines)
        normalized += '\r\n'  # trailing CRLF? The original may have trailing CRLF, but we preserve it.
        # Actually the original response ends with CRLF, but when splitting we lost it. We'll add back if needed.
        if response.endswith(b'\r\n'):
            normalized += '\r\n'
        elif response.endswith(b'\n'):
            normalized += '\n'
        else:
            # original didn't have trailing CRLF? We'll keep without.
            pass
    # Encode back to bytes
    normalized_bytes = normalized.encode('ascii', errors='replace')
    return hashlib.sha256(normalized_bytes).hexdigest()