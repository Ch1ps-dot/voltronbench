import re

def packet_parser(response: bytes) -> bytes:
    # Attempt to extract the first three digits (Reply-Code) from the beginning of the response.
    match = re.match(rb"^(\d{3})", response)
    if match:
        code = match.group(1)
        # Validate that the code is in the known list of values.
        # The list is provided as integers; convert to bytes for comparison.
        known_codes = [110, 120, 125, 150, 200, 202, 211, 212, 213, 214, 215, 220, 221, 225, 226, 227, 229, 230, 232, 234, 235, 250, 257, 331, 332, 334, 335, 336, 350, 421, 425, 426, 431, 450, 451, 452, 500, 501, 502, 503, 504, 522, 530, 532, 533, 534, 535, 536, 537, 550, 551, 552, 553, 631, 632, 633]
        if int(code) in known_codes:
            return code
    return b""