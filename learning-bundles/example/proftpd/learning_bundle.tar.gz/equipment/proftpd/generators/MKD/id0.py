def generate() -> bytes:
    return b"MKD ftp_test_directory\r\n"