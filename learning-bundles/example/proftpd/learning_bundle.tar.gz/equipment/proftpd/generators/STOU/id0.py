def generate() -> bytes:
    # STOU: CommandCode is constant "STOU" (3 bytes, ASCII), no argument field
    # EndOfLine is constant 0x0D 0x0A (CR LF)
    command_code = b"STOU"
    end_of_line = b"\x0D\x0A"
    return command_code + end_of_line