def generate() -> bytes:
    # Choose delimiter character as '|' (ASCII 124)
    delimiter = b'|'
    
    # NetProtocol: IPv4 = 1
    net_protocol = b'1'
    
    # NetworkAddress: localhost IPv4
    network_address = b'127.0.0.1'
    
    # TCPPort: use default FTP data port 20
    tcp_port = b'20'
    
    # Build the EPRT command line
    return (b'EPRT ' + delimiter + net_protocol + delimiter +
            network_address + delimiter + tcp_port + delimiter + b'\r\n')