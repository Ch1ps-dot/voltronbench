def generate() -> bytes:
    # Build the STOR request according to the IR field table
    # Fields in order: CommandCode, Whitespace, Pathname, EndOfLine
    command_code = b"STOR"
    whitespace = b" "  # one space, variable length but at least one
    # Choose a valid pathname: use a common test value
    pathname = b"testfile.txt"
    end_of_line = b"\r\n"
    return command_code + whitespace + pathname + end_of_line