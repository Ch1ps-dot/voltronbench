def generate() -> bytes:
    # CommandCode: "QUIT" (3 bytes, ASCII)
    # EndOfLine: "\r\n" (2 bytes, 0x0D0A)
    return b"QUIT\r\n"