def generate() -> bytes:
    # Command code for PWD is "PWD" (3 bytes, ASCII)
    command_code = b"PWD"
    # End-of-line is CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    # Concatenate in IR order: CommandCode followed by EndOfLine
    return command_code + end_of_line