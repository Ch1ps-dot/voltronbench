def generate() -> bytes:
    # Build a valid USER request for FTP login with username "ubuntu"
    # Fields: CommandCode (constant "USER"), Whitespace (0x20), Username (variable), EndOfLine (CRLF)
    command_code = b"USER"
    whitespace = b"\x20"
    username = b"ubuntu"
    end_of_line = b"\r\n"
    return command_code + whitespace + username + end_of_line