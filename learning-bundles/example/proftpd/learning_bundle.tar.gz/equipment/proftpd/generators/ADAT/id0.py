import struct

def generate() -> bytes:
    """
    Generate a valid ADAT FTP command for fuzzing/state exploration.
    Uses base64-encoded security data (RFC 4648) with a common valid example.
    """
    # Command code (4 bytes, ASCII, uppercase)
    command = b"ADAT"
    # Whitespace (1 byte, space)
    whitespace = b" "
    # Security data: variable-length base64 string (example: "AAAA" is valid base64)
    # Using a common padding pattern to ensure validity
    security_data = b"AAAA"
    # End of line (2 bytes, CRLF)
    eol = b"\r\n"
    
    # Concatenate in IR order
    return command + whitespace + security_data + eol