import struct

def generate() -> bytes:
    """
    Generate a valid FTP HELP request.
    Format: "HELP<CRLF>" or "HELP <argument><CRLF>"
    We choose to include an optional argument for state exploration.
    Argument: "USER" (a common command) to explore help on a specific command.
    """
    # Command code constant
    command_code = b"HELP"
    
    # Whitespace (one or more spaces) - include single space since argument is provided
    whitespace = b" "
    
    # Argument: ASCII string, no CR/LF; choose "USER" (valid command name)
    argument = b"USER"
    
    # EndOfLine constant: CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    
    # Build request: command + whitespace + argument + CRLF
    request = command_code + whitespace + argument + end_of_line
    
    return request