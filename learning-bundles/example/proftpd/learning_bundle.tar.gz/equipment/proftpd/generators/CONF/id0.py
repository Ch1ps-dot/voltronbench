def generate() -> bytes:
    # Build the CONF request according to the IR field table
    # CommandCode: constant "CONF" (4 bytes, ASCII)
    command_code = b"CONF"
    # Whitespace: single space (0x20)
    whitespace = b" "
    # Base64Data: variable, base64 encoded confidential message
    # Use a valid base64 string (no padding needed for this example)
    base64_data = b"dGVzdCBjb25maWRlbnRpYWwgZGF0YQ=="
    # EndOfLine: CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    
    # Concatenate in order
    return command_code + whitespace + base64_data + end_of_line