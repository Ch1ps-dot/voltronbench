def generate() -> bytes:
    # STRU command: constant command code "STRU", space, structure code 'F', CRLF
    return b"STRU F\r\n"