def generate() -> bytes:
    return b"MIC Tk9PUA==\r\n"