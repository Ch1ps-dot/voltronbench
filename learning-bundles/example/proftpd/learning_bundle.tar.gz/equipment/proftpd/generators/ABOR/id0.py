def generate() -> bytes:
    # IR field table order: CommandCode, EndOfLine
    # CommandCode: constant "ABOR" (4 bytes, ASCII)
    # EndOfLine: constant 0x0D0A (2 bytes, CRLF)
    request = b"ABOR" + b"\r\n"
    return request