def generate() -> bytes:
    return b"PASV\r\n"