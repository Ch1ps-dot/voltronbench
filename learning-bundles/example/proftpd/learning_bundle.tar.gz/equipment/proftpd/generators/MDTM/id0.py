def generate() -> bytes:
    command_code = b"MDTM"
    whitespace = b" "
    pathname = b".bashrc"
    end_of_line = b"\r\n"
    return command_code + whitespace + pathname + end_of_line