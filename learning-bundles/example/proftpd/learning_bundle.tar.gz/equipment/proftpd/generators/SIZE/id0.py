def generate() -> bytes:
    # Build the SIZE request per RFC 3659
    # CommandCode: "SIZE" (4 ASCII bytes, uppercase)
    command_code = b"SIZE"
    # Whitespace: space character (0x20)
    whitespace = b"\x20"
    # Pathname: variable length, ASCII except CR (0x0D) and LF (0x0A)
    # Use a valid common pathname for state exploration: "/home/ubuntu/test.txt"
    pathname = b"/home/ubuntu/test.txt"
    # EndOfLine: CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    # Concatenate in IR order
    return command_code + whitespace + pathname + end_of_line