def generate() -> bytes:
    # CommandCode constant: "RMD" (3 bytes)
    cmd = b"RMD"
    # Whitespace: 0x20 (1 byte)
    space = b"\x20"
    # Pathname: variable, ASCII excluding CR/LF
    pathname = b"/tmp/testdir"  # valid common absolute path
    # EndOfLine: 0x0D0A (2 bytes)
    eol = b"\x0D\x0A"
    # Assemble full request
    return cmd + space + pathname + eol