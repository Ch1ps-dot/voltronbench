def generate() -> bytes:
    # Build the MODE request per IR field table:
    # 1. CommandCode: constant "MODE" (4 bytes ASCII)
    # 2. Whitespace: constant 0x20 (1 byte)
    # 3. ModeCode: variable "S" (1 byte ASCII) per type rule
    # 4. EndOfLine: constant 0x0D0A (2 bytes)
    return b"MODE S\r\n"