def generate() -> bytes:
    # IR field order: CommandCode, EndOfLine
    # CommandCode: constant "CDUP" (4 bytes)
    # EndOfLine: constant CRLF (0x0D0A, 2 bytes)
    command_code = b"CDUP"
    end_of_line = b"\r\n"
    return command_code + end_of_line