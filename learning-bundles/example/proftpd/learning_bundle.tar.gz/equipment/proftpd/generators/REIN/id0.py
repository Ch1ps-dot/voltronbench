def generate() -> bytes:
    return b"REIN\r\n"