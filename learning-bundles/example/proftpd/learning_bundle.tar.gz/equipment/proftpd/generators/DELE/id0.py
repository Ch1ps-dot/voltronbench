def generate() -> bytes:
    # Command code: "DELE" (4 bytes, ASCII uppercase)
    command_code = b"DELE"
    # Whitespace: space character (0x20)
    whitespace = b"\x20"
    # Pathname: choose a valid file name (printable ASCII, no CR/LF)
    # Use a simple path like "/tmp/test.txt" (ASCII bytes)
    pathname = b"/tmp/test.txt"
    # End-of-line: CR LF (0x0D 0x0A)
    eol = b"\r\n"
    # Assemble the complete DELE request
    return command_code + whitespace + pathname + eol