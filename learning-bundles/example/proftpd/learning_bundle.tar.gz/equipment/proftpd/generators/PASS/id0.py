def generate() -> bytes:
    # Constant command code "PASS" (3 bytes)
    command_code = b"PASS"
    # Constant whitespace (1 byte space)
    whitespace = b"\x20"
    # Password: from account info, the password for user ubuntu is "ubuntu" (variable length)
    password = b"ubuntu"
    # Constant EndOfLine (2 bytes: CR LF)
    eol = b"\x0D\x0A"
    # Assemble in IR order
    return command_code + whitespace + password + eol