def generate() -> bytes:
    return b"ENC VVNFUiB1YnVudHUNCg==\r\n"