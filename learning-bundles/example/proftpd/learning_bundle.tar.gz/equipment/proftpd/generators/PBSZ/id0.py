def generate() -> bytes:
    sizes = (b"1", b"1024", b"1048576", b"4294967295")
    i = getattr(generate, "_next_index", 0)
    generate._next_index = i + 1
    return b"PBSZ " + sizes[i % len(sizes)] + b"\r\n"