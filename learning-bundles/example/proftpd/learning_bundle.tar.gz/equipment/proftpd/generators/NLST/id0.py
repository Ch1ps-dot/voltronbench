def generate() -> bytes:
    """
    Generate a valid NLST (Name List) FTP request.
    
    The message format is:
        CommandCode (constant "NLST") + Separator (spaces) + Pathname (optional) + EndOfLine (0x0D 0x0A)
    
    This implementation:
    - Uses the constant CommandCode "NLST"
    - Includes a separator (single space) and a pathname for a typical request
    - Terminates with CRLF (0x0D 0x0A)
    - Uses ASCII encoding for all text fields
    """
    # Command code: 4 bytes, ASCII "NLST"
    command_code = b"NLST"
    
    # Separator: one or more spaces; we use a single space for simplicity
    separator = b" "
    
    # Pathname: optional, variable length; we use a reasonable pathname
    # Common choices: current directory (empty), "/", or a specific path
    # Using "/home/ubuntu" for state exploration -- a valid path on the SUT
    pathname = b"/home/ubuntu"
    
    # End-of-line: 2 bytes, CR+LF (0x0D 0x0A)
    end_of_line = b"\r\n"
    
    # Assemble the complete request
    request = command_code + separator + pathname + end_of_line
    
    return request