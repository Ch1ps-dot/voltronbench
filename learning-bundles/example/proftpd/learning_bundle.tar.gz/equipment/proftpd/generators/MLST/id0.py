import struct

def generate() -> bytes:
    # CommandCode: constant "MLST", 4 bytes, ASCII
    command_code = b"MLST"
    
    # No pathname argument: omit whitespace and pathname fields
    # EndOfLine: constant CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    
    # Build the message by concatenating fields in IR order
    # When no pathname is provided, whitespace is omitted per protocol spec
    message = command_code + end_of_line
    
    return message