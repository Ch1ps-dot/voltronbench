import struct

def generate() -> bytes:
    # Constants
    command_code = b"AUTH"
    whitespace = b" "
    mechanism_name = b"X-FUZZING"  # Valid variable mechanism name, IANA-style or X- prefix
    end_of_line = b"\r\n"
    
    # Build the message in IR order: CommandCode, Whitespace, MechanismName, EndOfLine
    message = command_code + whitespace + mechanism_name + end_of_line
    
    return message