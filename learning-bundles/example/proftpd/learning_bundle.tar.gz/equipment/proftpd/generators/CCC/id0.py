import struct

def generate() -> bytes:
    # Command code: "CCC" (3 bytes, ASCII uppercase as per RFC 2228)
    command_code = b"CCC"
    # End-of-line: CRLF (0x0D 0x0A)
    end_of_line = b"\r\n"
    # Concatenate in IR order: CommandCode then EndOfLine
    return command_code + end_of_line