def generate() -> bytes:
    # PROT command: CommandCode "PROT", Whitespace 0x20, ProtectionLevel "C", EndOfLine 0x0D0A
    return b"PROT C\r\n"