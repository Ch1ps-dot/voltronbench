def generate() -> bytes:
    # CommandCode: constant "ACCT" (4 bytes)
    command_code = b"ACCT"
    # Whitespace: constant 0x20 (1 byte)
    whitespace = b"\x20"
    # AccountInformation: variable length, ASCII printable except CR/LF
    # Use a valid account identifier; for SUT context, we use "ubuntu" as the account
    account_info = b"ubuntu"
    # EndOfLine: constant CRLF (2 bytes)
    eol = b"\r\n"
    # Assemble in order
    return command_code + whitespace + account_info + eol