def generate() -> bytes:
    # REST command: constant CommandCode "REST", whitespace, variable marker, CRLF
    # Use a valid marker: decimal digits for STREAM mode, e.g., "12345"
    marker = b"12345"
    # Constant parts
    command_code = b"REST"
    whitespace = b" "
    crlf = b"\r\n"
    # Assemble in order
    return command_code + whitespace + marker + crlf