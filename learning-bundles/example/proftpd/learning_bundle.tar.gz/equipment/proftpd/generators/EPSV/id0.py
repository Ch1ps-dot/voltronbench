def generate() -> bytes:
    return b"EPSV 1\r\n"