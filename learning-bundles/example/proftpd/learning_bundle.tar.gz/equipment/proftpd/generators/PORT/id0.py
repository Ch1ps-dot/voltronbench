def generate() -> bytes:
    # Build the PORT command for active data connection.
    # Using common values: 127,0,0,1 for host (localhost) and port 20 (0,20)
    # which is the FTP data port.
    command = b"PORT"
    space = b" "
    h1 = b"127"
    comma1 = b","
    h2 = b"0"
    comma2 = b","
    h3 = b"0"
    comma3 = b","
    h4 = b"1"
    comma4 = b","
    p1 = b"0"   # high byte of port 20
    comma5 = b","
    p2 = b"20"  # low byte of port 20
    crlf = b"\r\n"
    return command + space + h1 + comma1 + h2 + comma2 + h3 + comma3 + h4 + comma4 + p1 + comma5 + p2 + crlf