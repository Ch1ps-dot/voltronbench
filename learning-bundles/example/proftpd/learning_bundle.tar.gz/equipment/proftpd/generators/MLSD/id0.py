def generate() -> bytes:
    return b"MLSD /home/ubuntu\r\n"