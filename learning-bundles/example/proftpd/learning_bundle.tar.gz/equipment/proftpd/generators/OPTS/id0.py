import struct

def generate() -> bytes:
    # Constants
    command_code = b"OPTS"
    whitespace1 = b"\x20"
    # CommandName: choose MLST (common for OPTS)
    command_name = b"MLST"
    # OptionalSpaceAndOptions: for MLST, a semicolon-separated list of facts
    # Use a common valid set: Type;Size;Modify;Perm
    options = b"\x20Type;Size;Modify;Perm"
    end_of_line = b"\x0D\x0A"
    
    # Assemble the message
    message = command_code + whitespace1 + command_name + options + end_of_line
    return message