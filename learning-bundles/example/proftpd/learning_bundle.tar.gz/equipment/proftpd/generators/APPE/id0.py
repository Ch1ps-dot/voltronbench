def generate() -> bytes:
    # Build the APPE command according to IR field table
    # Order: CommandCode, Whitespace, Pathname, EndOfLine
    command = b"APPE"
    whitespace = b"\x20"
    # Choose a valid pathname for exploration: a typical file to append to
    # Use a common Linux path with a file that likely exists
    pathname = b"/tmp/testfile.txt"
    end_of_line = b"\x0D\x0A"
    return command + whitespace + pathname + end_of_line