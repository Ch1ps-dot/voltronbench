def generate() -> bytes:
    # Serialize FEAT request per IR field table
    # CommandCode: constant "FEAT" (4 bytes ASCII)
    # EndOfLine: constant CRLF (0x0D0A, 2 bytes)
    return b"FEAT\r\n"