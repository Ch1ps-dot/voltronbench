def generate() -> bytes:
    # Build a TYPE command: set representation type to ASCII (NVT-ASCII)
    # Fields in IR order: CommandCode (4 bytes), Separator (1 byte), TypeCode (variable), EndOfLine (2 bytes)
    
    command_code = b"TYPE"        # 4 bytes, constant
    separator = b"\x20"           # 1 byte, space
    # TypeCode for ASCII: 'A' (optionally followed by SP and format char, but we send just 'A' for simplicity)
    type_code = b"A"              # variable, one character
    end_of_line = b"\x0D\x0A"     # 2 bytes, CRLF
    
    # Concatenate in order
    request = command_code + separator + type_code + end_of_line
    return request