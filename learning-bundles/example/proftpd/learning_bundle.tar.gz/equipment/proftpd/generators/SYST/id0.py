def generate() -> bytes:
    return b'SYST\r\n'