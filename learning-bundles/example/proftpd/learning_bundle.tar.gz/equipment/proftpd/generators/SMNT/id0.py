def generate() -> bytes:
    return b"SMNT /home/ubuntu\r\n"