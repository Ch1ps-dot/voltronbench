def generate() -> bytes:
    """
    Generate a valid FTP CWD (Change Working Directory) command request.
    Uses the account context to build a likely path that exists on the server
    (e.g., the home directory of user 'ubuntu').
    """
    # Constant fields
    command_code = b"CWD"
    # At least one space is required; using one space as per common usage
    whitespace = b" "
    # Pathname: a valid relative or absolute path that is likely to exist
    # Using the home directory of the ubuntu user as a semantic path
    pathname = b"/home/ubuntu"
    # End-of-line: CRLF
    eol = b"\r\n"
    
    # Assemble in IR order
    return command_code + whitespace + pathname + eol