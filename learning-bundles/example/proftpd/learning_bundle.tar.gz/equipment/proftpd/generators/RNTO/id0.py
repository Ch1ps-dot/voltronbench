import struct

def generate() -> bytes:
    # Build the RNTO request as per IR field table
    # Field order: CommandCode, Whitespace, Pathname, EndOfLine
    command_code = b"RNTO"
    whitespace = b" "  # 0x20
    # Choose a valid pathname: ASCII printable, no CR/LF
    pathname = b"/home/ubuntu/newfile.txt"
    end_of_line = b"\r\n"  # 0x0D0A
    return command_code + whitespace + pathname + end_of_line