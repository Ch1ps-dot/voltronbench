def generate():
    return b"RETR testfile.txt\r\n"