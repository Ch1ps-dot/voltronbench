def packet_checker(response: bytes) -> bool:
    # Reject non-bytes
    if not isinstance(response, bytes):
        return False
    # Must have at least 3 digits + separator + text + CRLF (minimum 3+1+1+2 = 7 bytes)
    if len(response) < 7:
        return False
    # Check end-of-line (CRLF) constant
    if response[-2:] != b'\r\n':
        return False
    # Extract StatusCode (first 3 bytes)
    status_code_bytes = response[:3]
    # Must be exactly 3 bytes and digits
    if len(status_code_bytes) != 3:
        return False
    if not all(48 <= b <= 57 for b in status_code_bytes):
        return False
    # Parse as integer
    status_code = int(status_code_bytes.decode('ascii'))
    # Validate range 100-599
    if status_code < 100 or status_code > 599:
        return False
    # Check first digit classification
    first_digit = status_code // 100
    if first_digit not in (1, 2, 3, 4, 5):
        return False
    # Check second digit (function group)
    second_digit = (status_code // 10) % 10
    if second_digit < 0 or second_digit > 5:
        # Valid second digits: 0,1,2,3,4,5 (per RFC 959)
        return False
    # Valid primary field values (check against allowed list)
    allowed_codes = {110, 120, 125, 150, 200, 202, 211, 212, 213, 214, 215, 220, 221, 225, 226, 227, 229, 230, 232, 234, 235, 250, 257, 331, 332, 334, 335, 336, 350, 421, 425, 426, 431, 450, 451, 452, 500, 501, 502, 503, 504, 522, 530, 532, 533, 534, 535, 536, 537, 550, 551, 552, 553, 631, 632, 633}
    if status_code not in allowed_codes:
        return False
    # Separator: byte 3 (0-indexed) must be 0x20 (space) or 0x2D (hyphen)
    separator = response[3]
    if separator not in (0x20, 0x2D):
        return False
    # Text: from position 4 to before CRLF (exclusive)
    text_bytes = response[4:-2]
    # Text must be non-empty
    if len(text_bytes) == 0:
        return False
    # Validate each character in text: printable ASCII (VCHAR: 0x21-0x7E) or space (0x20) or HTAB (0x09)
    for b in text_bytes:
        if b not in (0x20, 0x09) and (b < 0x21 or b > 0x7E):
            return False
    # If separator is hyphen (0x2D), it indicates multi-line reply.
    # The last line must begin with the same StatusCode followed by a space.
    if separator == 0x2D:
        # Split into lines (by CRLF). Note: original response ends with CRLF, so trailing CRLF yields empty line.
        # But we already have full response; we can split the text part by CRLF lines.
        # However, text_bytes may contain CRLF pairs that are part of the multi-line format.
        # Reconstruct full response body without the trailing CRLF for splitting.
        # Better: parse the entire response (excluding trailing CRLF) as sequence of lines separated by CRLF.
        # The last line is the final line of the multi-line reply.
        # We'll split the response (without final CRLF) on CRLF.
        # Actually, the response ends with CRLF, so content is response[:-2].
        content = response[:-2]
        # The first line is StatusCode + separator + text up to first CRLF.
        # But we want to find the last line which must start with the same StatusCode and a space.
        # We can search for the last CRLF sequence.
        # Find all occurrences of CRLF in content.
        # If there is at least one CRLF, the last segment after last CRLF is the final line.
        # But we need to ensure proper multi-line structure: first line ends with hyphen, intermediate lines end with CRLF, last line starts with StatusCode + space.
        # Simpler: check that the text_bytes can be split by CRLF into lines, and the last line starts with the same StatusCode followed by space.
        # However, text_bytes is between separator and final CRLF; it may contain CRLF sequences.
        # Since we already removed the last CRLF, we can split the entire response[4:-2] (which is text_bytes) by b'\r\n'.
        # But note: the text might contain CRLF mid-way; that's fine.
        lines = text_bytes.split(b'\r\n')
        # The last line must be the final line of the multi-line reply.
        # It should start with the same StatusCode as bytes followed by a space.
        if len(lines) == 0 or lines[-1] == b'':
            # At least one line must exist, and last line should not be empty if there is a proper final line.
            # Actually, if the reply ends with StatusCode + space + text, it's not empty.
            # But if the text part itself is empty? Text is non-empty per earlier check.
            # However, the last line could be just StatusCode + space? That's allowed with optional text.
            # But we already checked text_bytes is non-empty overall; but the final line could be just StatusCode + space.
            # Let's handle: last line must start with exactly 3 bytes of the same StatusCode then a space.
            # But if the last line is shorter than 4 bytes, it's invalid.
            return False
        last_line = lines[-1]
        if len(last_line) < 4:
            return False
        # Check that last line starts with the same StatusCode bytes
        if last_line[:3] != status_code_bytes:
            return False
        # Check that byte at index 3 is space (0x20)
        if last_line[3] != 0x20:
            return False
        # Remaining characters of last line (if any) must be valid text
        for b in last_line[4:]:
            if b not in (0x20, 0x09) and (b < 0x21 or b > 0x7E):
                return False
        # Also, each intermediate line (except last) is just text followed by CRLF; no extra constraints.
        # But we already validated text_bytes characters overall; okay.
        # For multi-line, the first line's separator is hyphen; that's already checked.
    else:
        # Single-line: separator is space, no multi-line structure.
        pass

    # Ensure that the entire response is consumed (no extra trailing data beyond CRLF)
    # We already used all bytes: header (3) + separator (1) + text (variable) + CRLF (2) = len(response)
    # So no remaining bytes.

    return True