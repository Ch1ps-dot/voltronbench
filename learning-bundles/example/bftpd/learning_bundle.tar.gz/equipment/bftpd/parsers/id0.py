_FTP_REPLY_CODES = {
    110, 120, 125, 150,
    200, 202, 211, 212, 213, 214, 215,
    220, 221, 225, 226, 227, 229,
    230, 232, 234, 235,
    250, 257,
    331, 332, 334, 335, 336,
    350,
    421, 425, 426, 431,
    450, 451, 452,
    500, 501, 502, 503, 504, 522,
    530, 532, 533, 534, 535, 536, 537,
    550, 551, 552, 553,
    631, 632, 633,
}

def packet_parser(response: bytes) -> bytes:
    if not isinstance(response, bytes):
        return b""

    line = response.split(b"\n", 1)[0]
    if line.endswith(b"\r"):
        line = line[:-1]

    if len(line) < 3:
        return b""

    code = line[:3]
    if not code.isdigit():
        return b""

    if int(code) in _FTP_REPLY_CODES:
        return code

    return b""