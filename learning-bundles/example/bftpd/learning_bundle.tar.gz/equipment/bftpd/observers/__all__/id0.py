import hashlib

def packet_observer(response: bytes) -> str:
    if not isinstance(response, bytes):
        response = b""
    return hashlib.sha256(response).hexdigest()