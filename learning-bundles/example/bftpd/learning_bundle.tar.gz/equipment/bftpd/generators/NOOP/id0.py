def generate() -> bytes:
    # CommandCode: constant "NOOP" in ASCII
    command_code = b"NOOP"
    # EndOfLine: constant 0x0D 0x0A
    end_of_line = b"\r\n"
    # Return the complete NOOP request
    return command_code + end_of_line