def generate() -> bytes:
    # Build the STRU request according to the IR field table:
    # 1. CommandCode: constant "STRU" (3 bytes ASCII)
    # 2. Whitespace: constant 0x20 (1 byte)
    # 3. StructureCode: "F" (1 byte ASCII) as per type rule
    # 4. EndOfLine: constant 0x0D 0x0A (2 bytes)
    return b"STRU F\r\n"