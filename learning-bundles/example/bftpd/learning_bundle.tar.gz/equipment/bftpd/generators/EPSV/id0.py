def generate() -> bytes:
    i = getattr(generate, "_i", -1) + 1
    generate._i = i
    return (b"EPSV\r\n", b"EPSV 1\r\n", b"EPSV 2\r\n", b"EPSV ALL\r\n")[i % 4]