def generate() -> bytes:
    return b"RETR .profile\r\n"