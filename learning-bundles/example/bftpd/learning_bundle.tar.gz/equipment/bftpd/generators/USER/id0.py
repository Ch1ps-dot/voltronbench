def generate() -> bytes:
    # Build USER command for FTP login
    # Constants per IR field table
    command_code = b"USER"  # 4 bytes, constant
    whitespace = b"\x20"    # 1 byte space
    # Variable username: use valid ASCII string (no CR/LF)
    username = b"ubuntu"    # Valid username from SUT context
    end_of_line = b"\r\n"   # 2 bytes CRLF
    return command_code + whitespace + username + end_of_line