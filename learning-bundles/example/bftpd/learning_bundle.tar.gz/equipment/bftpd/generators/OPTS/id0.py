def generate() -> bytes:
    # Build the FTP OPTS request according to the IR field table
    # Fields in order: CommandCode, Whitespace1, CommandName, OptionalSpaceAndOptions, EndOfLine
    
    # CommandCode: constant "OPTS" (4 bytes, uppercase)
    command_code = b"OPTS"
    
    # Whitespace1: constant 0x20 (1 byte)
    whitespace1 = b"\x20"
    
    # CommandName: variable, ASCII printable excluding SPACE, CR, LF
    # Use a common target command for state exploration: "MLST" (a typical OPTS target)
    command_name = b"MLST"
    
    # OptionalSpaceAndOptions: optional, if present starts with 0x20 then options string
    # For OPTS MLST, common options are semicolon-separated fact names with no spaces.
    # Use a valid set of facts: "type;size;modify;perm" (no internal spaces)
    # Precede with 0x20 as required if options are present.
    options = b"\x20" + b"type;size;modify;perm"
    
    # EndOfLine: constant 0x0D0A (2 bytes)
    eol = b"\x0D\x0A"
    
    # Assemble the complete request
    request = command_code + whitespace1 + command_name + options + eol
    return request