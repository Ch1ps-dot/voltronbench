def generate() -> bytes:
    # QUIT command: constant bytes "QUIT" followed by CRLF
    return b"QUIT\r\n"