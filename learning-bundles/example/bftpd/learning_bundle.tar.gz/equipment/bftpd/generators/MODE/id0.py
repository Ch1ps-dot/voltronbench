def generate() -> bytes:
    return b"MODE S\r\n"