def generate() -> bytes:
    # Command code constant: "RMD"
    command_code = b"RMD"
    # Whitespace separator (0x20)
    whitespace = b"\x20"
    # Pathname: a valid ASCII directory path (no CR/LF), choose a plausible directory name
    pathname = b"/tmp/testdir"
    # End-of-line: CRLF (0x0D0A)
    end_of_line = b"\x0D\x0A"
    # Assemble the complete RMD request in IR order
    return command_code + whitespace + pathname + end_of_line