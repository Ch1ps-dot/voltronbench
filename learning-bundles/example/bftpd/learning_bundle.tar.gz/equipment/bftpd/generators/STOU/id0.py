def generate() -> bytes:
    # Command code "STOU" in ASCII, 3 bytes
    command_code = b"STOU"
    # End-of-line sequence: CR (0x0D) followed by LF (0x0A), 2 bytes
    eol = b"\x0D\x0A"
    # Concatenate in IR order: command code then end-of-line
    return command_code + eol