import struct

def generate() -> bytes:
    # Command code for CDUP is "CDUP" in ASCII, 4 bytes
    command_code = b"CDUP"
    # End-of-line marker: CRLF as 0x0D 0x0A
    eol = b"\r\n"
    
    # Concatenate in IR order: CommandCode then EndOfLine
    message = command_code + eol
    
    return message