def generate() -> bytes:
    return b"PBSZ 1048576\r\n"