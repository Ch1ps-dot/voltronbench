def generate() -> bytes:
    return b"ENC VVNFUiB1YnVudHUNClBBU1MgdWJ1bnR1DQo=\r\n"