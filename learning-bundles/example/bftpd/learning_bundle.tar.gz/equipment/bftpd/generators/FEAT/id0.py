def generate() -> bytes:
    # CommandCode: constant "FEAT" (4 bytes)
    command = b"FEAT"
    # EndOfLine: constant CRLF (2 bytes: 0x0D 0x0A)
    eol = b"\r\n"
    # Return the complete FEAT request
    return command + eol