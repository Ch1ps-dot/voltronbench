import base64
import random
import struct

def generate() -> bytes:
    # Command code and whitespace
    command_code = b"MIC"
    whitespace = b" "
    
    # Generate a valid base64-encoded payload (can be any safe message)
    # For state exploration, we'll vary the content; use a common message
    # The payload should be a valid FTP command protected by integrity check
    # We'll use a simple safe command like "USER ubuntu" as example
    safe_message = "USER ubuntu"
    base64_data = base64.b64encode(safe_message.encode()).decode()
    
    # Ensure base64 string is valid (A-Z, a-z, 0-9, +, /, =)
    # base64.b64encode ensures this
    base64_bytes = base64_data.encode()
    
    # End of line
    eol = b"\r\n"
    
    # Construct the full request
    request = command_code + whitespace + base64_bytes + eol
    return request