def generate() -> bytes:
    """
    Generate a valid MLSD FTP request.
    If a pathname is included, it is a typical directory name; otherwise omitted.
    """
    # Constant parts: Command "MLSD" and CRLF
    # Pathname is optional; we choose to include a simple pathname.
    command = b"MLSD"
    space = b" "
    pathname = b"/home/ubuntu"
    crlf = b"\r\n"
    return command + space + pathname + crlf