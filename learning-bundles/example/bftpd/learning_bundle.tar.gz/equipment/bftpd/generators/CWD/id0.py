import struct

def generate() -> bytes:
    # Build the CWD command per the IR field table
    # Field: CommandCode (constant "CWD")
    command_code = b"CWD"
    # Field: Whitespace (constant 0x20, at least one space)
    whitespace = b" "
    # Field: Pathname (variable, ASCII excluding CR/LF)
    # Use a valid, common path for exploration: current directory "."
    pathname = b"."
    # Field: EndOfLine (constant 2B CRLF: 0x0D 0x0A)
    end_of_line = b"\r\n"
    
    # Concatenate in IR order
    return command_code + whitespace + pathname + end_of_line