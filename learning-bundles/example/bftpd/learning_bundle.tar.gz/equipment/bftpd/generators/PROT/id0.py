def generate() -> bytes:
    # Construct PROT command according to IR field table
    # Constant CommandCode: "PROT" (4 bytes)
    # Constant Whitespace: 0x20 (1 byte)
    # Variable ProtectionLevel: "C" (Clear) as specified in type rule
    # Constant EndOfLine: 0x0D0A (2 bytes)
    
    return b"PROT C\r\n"