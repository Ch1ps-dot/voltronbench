def generate() -> bytes:
    # Construct a valid RNFR request for the FTP protocol
    # CommandCode: "RNFR"
    # Whitespace: " " (0x20)
    # Pathname: Variable path, e.g., "/home/ubuntu/oldfile.txt"
    # EndOfLine: CRLF (0x0D 0x0A)
    result = b"RNFR /home/ubuntu/oldfile.txt\r\n"
    return result