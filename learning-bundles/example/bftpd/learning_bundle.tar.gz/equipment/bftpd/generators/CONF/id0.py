def generate() -> bytes:
    # Build the CONF request according to the IR field table
    # Fields: CommandCode (constant "CONF"), Whitespace (0x20), Base64Data (variable), EndOfLine (0x0D0A)
    
    # Choose a valid base64 encoded confidential message (no internal CR/LF, printable ASCII)
    # Use a simple example that is valid base64 and semantically reasonable
    base64_data = "dWJ1bnR1OnVidW50dQ=="  # Base64 of "ubuntu:ubuntu" (common login context)
    
    # Ensure no CR/LF in the base64 data (it has none)
    # All characters are from base64 alphabet: A-Z, a-z, 0-9, +, /, =
    
    # Assemble the request
    request = b"CONF" + b"\x20" + base64_data.encode() + b"\x0D\x0A"
    return request