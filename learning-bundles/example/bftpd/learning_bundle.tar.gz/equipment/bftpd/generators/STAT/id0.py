def generate() -> bytes:
    return b"STAT\r\n"