def generate() -> bytes:
    # Command code "CCC" in ASCII, 3 bytes
    command_code = b"CCC"
    # End of line: CRLF, 2 bytes
    eol = b"\r\n"
    # Concatenate in IR order: CommandCode, then EndOfLine
    return command_code + eol