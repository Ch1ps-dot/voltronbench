def generate() -> bytes:
    return b"PASS ubuntu\r\n"