def generate() -> bytes:
    # Build MDTM request: CommandCode + Whitespace + Pathname + EndOfLine
    # CommandCode: "MDTM" (4 bytes, ASCII)
    cmd = b"MDTM"
    # Whitespace: 0x20 (1 byte)
    space = b" "
    # Pathname: variable, choose a common file that may exist in the server's home directory
    # Use a typical path that might be present on the system
    pathname = b"/home/ubuntu/test.txt"
    # EndOfLine: 0x0D0A (2 bytes)
    eol = b"\r\n"
    return cmd + space + pathname + eol