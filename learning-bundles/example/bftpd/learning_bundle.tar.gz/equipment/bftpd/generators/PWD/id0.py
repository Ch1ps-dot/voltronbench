def generate() -> bytes:
    # Field: CommandCode (constant, 3B, value "PWD")
    command_code = b"PWD"
    # Field: EndOfLine (constant, 2B, value 0x0D0A)
    end_of_line = b"\r\n"
    # Concatenate in IR order
    return command_code + end_of_line