def generate() -> bytes:
    return b"SIZE test.txt\r\n"