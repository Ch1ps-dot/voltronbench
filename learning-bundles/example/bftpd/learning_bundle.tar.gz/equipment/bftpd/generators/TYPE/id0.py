def generate() -> bytes:
    return b"TYPE A\r\n"