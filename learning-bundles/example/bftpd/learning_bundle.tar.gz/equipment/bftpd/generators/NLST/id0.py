def generate() -> bytes:
    return b"NLST\r\n"