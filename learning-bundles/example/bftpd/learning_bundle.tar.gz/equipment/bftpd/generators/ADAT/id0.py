import struct
import base64
import secrets

def generate() -> bytes:
    # Build a valid ADAT command per RFC 2228
    # Command code (4 bytes) + space (1 byte) + base64 security data (variable) + CRLF (2 bytes)
    
    # Generate random base64-encoded security data (valid characters: A-Z, a-z, 0-9, +, /, =)
    # Use a random byte sequence that will be valid base64 after encoding
    raw_data = secrets.token_bytes(16)  # 16 random bytes -> 24 base64 characters (no padding needed)
    security_data = base64.b64encode(raw_data).decode('ascii')
    
    # Construct the request
    command = b"ADAT"  # constant 4-byte command code
    space = b" "       # 1-byte space separator
    data = security_data.encode('ascii')  # variable-length base64
    crlf = b"\r\n"     # 2-byte end-of-line marker
    
    return command + space + data + crlf