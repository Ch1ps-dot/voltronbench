def generate() -> bytes:
    # ABOR command: constant "ABOR" followed by CRLF
    command_code = b"ABOR"
    end_of_line = b"\r\n"
    return command_code + end_of_line