def generate():
    return b"MKD fuzz_dir\r\n"