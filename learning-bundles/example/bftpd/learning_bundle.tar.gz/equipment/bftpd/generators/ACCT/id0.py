def generate() -> bytes:
    # Command code (constant 4 bytes, uppercase)
    cmd = b"ACCT"
    # Whitespace (constant 1 byte, space)
    sep = b"\x20"
    # Account information: valid ASCII string (no CR/LF)
    # Use a common valid account name related to the SUT context
    account = b"ubuntu"
    # End-of-line (constant 2 bytes, CRLF)
    eol = b"\x0D\x0A"
    return cmd + sep + account + eol