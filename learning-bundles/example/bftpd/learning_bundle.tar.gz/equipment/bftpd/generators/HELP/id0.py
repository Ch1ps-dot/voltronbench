def generate() -> bytes:
    return b"HELP HELP\r\n"