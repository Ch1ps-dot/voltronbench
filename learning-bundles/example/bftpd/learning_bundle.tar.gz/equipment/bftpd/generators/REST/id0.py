def generate() -> bytes:
    # REST command: constant "REST" followed by space, marker, then CRLF
    command_code = b"REST"
    whitespace = b"\x20"  # ASCII space
    # Marker: valid for STREAM mode -> decimal digits, choose a common boundary value
    marker = b"0"  # minimal valid marker (one digit)
    end_of_line = b"\x0D\x0A"  # CRLF
    
    # Concatenate in field order: CommandCode, Whitespace, Marker, EndOfLine
    return command_code + whitespace + marker + end_of_line