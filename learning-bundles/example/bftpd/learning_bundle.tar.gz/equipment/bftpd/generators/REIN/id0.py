def generate() -> bytes:
    # REIN command: constant "REIN" followed by CRLF
    command_code = b"REIN"
    end_of_line = b"\r\n"
    return command_code + end_of_line