def generate() -> bytes:
    # Build the APPE command according to RFC 959
    command = b"APPE"  # CommandCode, constant 4 bytes
    whitespace = b"\x20"  # Single space separator
    # Pathname: choose a valid, common filename for state exploration
    # Use a simple ASCII printable path, no CR/LF
    pathname = b"testfile.txt"
    # EndOfLine: CRLF sequence (0x0D 0x0A)
    eol = b"\x0d\x0a"
    # Concatenate in IR order
    request = command + whitespace + pathname + eol
    return request