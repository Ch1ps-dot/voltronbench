def generate() -> bytes:
    # RNTO request: CommandCode + Whitespace + Pathname + EndOfLine
    # Constants
    command_code = b"RNTO"
    whitespace = b"\x20"
    end_of_line = b"\x0D\x0A"
    
    # Pathname: use a valid, simple pathname for state exploration
    # Choose a pathname that is ASCII printable, no CR/LF
    pathname = b"/home/ubuntu/test.txt"
    
    # Concatenate in order
    return command_code + whitespace + pathname + end_of_line