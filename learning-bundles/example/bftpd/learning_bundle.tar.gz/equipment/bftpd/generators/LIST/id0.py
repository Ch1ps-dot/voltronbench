def generate() -> bytes:
    return b"LIST\r\n"