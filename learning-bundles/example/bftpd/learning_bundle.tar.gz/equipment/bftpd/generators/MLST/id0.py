def generate() -> bytes:
    return b"MLST .\r\n"