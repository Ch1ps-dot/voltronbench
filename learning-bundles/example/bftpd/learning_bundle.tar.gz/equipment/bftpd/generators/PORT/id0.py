import struct

def generate() -> bytes:
    # Build the PORT command: "PORT h1,h2,h3,h4,p1,p2\r\n"
    # Use the SUT context: client is localhost, so we use 127,0,0,1 as host.
    # For port, use a common ephemeral port: 20*256+1 = 5121, so p1=20, p2=1.
    # All values are within valid decimal integer 0-255.
    
    host_octets = [127, 0, 0, 1]   # localhost
    port_octets = [20, 1]          # 20*256 + 1 = 5121, a valid data port
    
    # Concatenate all fields in IR order with constants
    fields = [
        b"PORT",           # CommandCode constant
        b" ",              # Whitespace constant
        str(host_octets[0]).encode(),
        b",",              # Comma1
        str(host_octets[1]).encode(),
        b",",              # Comma2
        str(host_octets[2]).encode(),
        b",",              # Comma3
        str(host_octets[3]).encode(),
        b",",              # Comma4
        str(port_octets[0]).encode(),
        b",",              # Comma5
        str(port_octets[1]).encode(),
        b"\r\n",           # EndOfLine
    ]
    
    return b"".join(fields)