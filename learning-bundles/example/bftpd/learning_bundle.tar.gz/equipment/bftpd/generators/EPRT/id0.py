def generate() -> bytes:
    # Choose a delimiter character that is printable ASCII; "|" is common and recommended
    delimiter = b"|"
    
    # NetProtocol: 1 for IPv4, 2 for IPv6. Use 1 (IPv4) for simplicity and common case
    net_protocol = b"1"
    
    # NetworkAddress: an IPv4 dotted-decimal string, e.g., 192.168.1.1
    network_address = b"192.168.1.1"
    
    # TCPPort: 21 is the default FTP control port, but for data connection we use a high port, e.g., 2000
    tcp_port = b"2000"
    
    # EndOfLine constant: CRLF
    eol = b"\r\n"
    
    # Build the request in the exact order of fields per the IR table
    # CommandCode constant: "EPRT"
    # Whitespace constant: 0x20 (space)
    # Delimiter1
    # NetProtocol
    # Delimiter2 (must match delimiter)
    # NetworkAddress
    # Delimiter3 (must match delimiter)
    # TCPPort
    # Delimiter4 (must match delimiter)
    # EndOfLine constant
    
    request = b"EPRT" + b" " + delimiter + net_protocol + delimiter + network_address + delimiter + tcp_port + delimiter + eol
    return request